from pathlib import Path
import hashlib, shutil, zipfile

project = Path.cwd()
server = project / '.local/graph-server'
mods = server / 'mods'
mods.mkdir(exist_ok=True)
cache = project.parent / 'core/.gradle-user-home/caches/modules-2/files-2.1'
curse = {'kubejs-238086': '5012072', 'rhino-416294': '6186971', 'jade-324717': '6855440',
         'applied-energistics-2-223794': '7148487', 'spark-361579': '4738952',
         'glodium-957920': '5006780', 'ex-pattern-provider-892005': '7144417', 'guideme-1173950': '7127447',
         'ftb-chunks-forge-314906': '5378090', 'ftb-library-forge-404465': '5567591',
         'ftb-teams-forge-404468': '5267190', 'ftb-ultimine-forge-386134': '5363345'}
files = []
def artifact(group, artifact, version):
    found = [p for p in (cache / group / artifact / version).glob('*/*.jar') if not any(s in p.name for s in ('-sources', '-javadoc', '-dev'))]
    assert len(found) == 1, (group, artifact, version, found)
    files.extend(found)
for name, version in curse.items(): artifact('curse.maven', name, version)
for group, name, version in [
    ('com.lowdragmc.ldlib', 'ldlib-forge-1.20.1', '1.0.29.b'),
    ('dev.architectury', 'architectury-forge', '9.1.12'),
    ('dev.toma.configuration', 'configuration-forge-1.20.1', '2.2.0'),
    ('com.teamresourceful.resourcefullib', 'resourcefullib-forge-1.20.1', '2.1.23'),
    ('com.teamresourceful.resourcefulconfig', 'resourcefulconfig-forge-1.20.1', '2.1.2'),
    ('earth.terrarium.botarium', 'botarium-forge-1.20.1', '2.3.3'),
    ('earth.terrarium.adastra', 'ad_astra-forge-1.20.1', '1.15.18'),
    ('org.moddingx', 'LibX', '1.20.1-5.0.1'),
    ('com.tterrag.registrate', 'Registrate', 'MC1.20-1.3.11'),
]: artifact(group, name, version)
files.extend(project / 'libs' / name for name in ['gtceu-1.20.1-1.4.4.jar', 'gtmthings-1.3.5.b.jar',
    'merequester-forge-1.20.1-1.1.5.jar', 'TravelAnchors-1.20.1-5.0.1.jar', 'wildcard_pattern-0.1.2-gtl.jar',
    'Re-Avaritia-forged-1.20.1-1.3.8.3.jar'])
files.extend((project / '.local/runtime-mods').glob('*.jar'))
files.append(project / 'build/libs/gtlcore-1.2.3.2-fix2-graph-test.jar')
for path in files:
    assert path.is_file(), path
    shutil.copy2(path, mods / path.name)
manifest = '\n'.join(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.name for path in sorted(mods.glob('*.jar')))
(server / 'mod-sha256.txt').write_text(manifest + '\n', encoding='utf-8')
for name in ('eula.txt', 'server.properties'):
    if not (server / name).exists(): shutil.copy2(project / 'run' / name, server / name)
config = server / 'config'
config.mkdir(exist_ok=True)
if not (config / 'gtlcore.yaml').exists():
    text = (project / 'run/config/gtlcore.yaml').read_text(encoding='utf-8')
    text = text.replace('ae2CraftingEngine: LEGACY', 'ae2CraftingEngine: GRAPH').replace('ae2GraphDiagnosticLogging: false', 'ae2GraphDiagnosticLogging: true')
    (config / 'gtlcore.yaml').write_text(text, encoding='utf-8')
print('Prepared', len(files), 'original server-compatible dependency jars in', server)
