from pathlib import Path
import hashlib,json,shutil,sys
r=Path.cwd();label=sys.argv[1];out=r/'.local/next-boundary-20261004'/label;out.mkdir()
source=r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core'
def hashes(p):return {f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in p.glob('*.java')}
h=hashes(source);shutil.copytree(source,out/'core');assert hashes(out/'core')==h==hashes(source)
(out/'source-hashes.json').write_text(json.dumps(h,indent=2))
s=(r/'.local/review-completion-20261004/run_large_final.py').read_text()
s=s.replace("out=r/'.local/review-completion-20261004'/sys.argv[1]","out=r/'.local/next-boundary-20261004'/sys.argv[1]")
s=s.replace("r/'.local/review-completion-20261004/final-source'",'r/'+repr(str((out/'core').relative_to(r)).replace('\\','/')))
s=s.replace("r/'.local/review-completion-20261004/broad-first/baseline'","r/'.local/next-boundary-20261004/boundary-final-r2-broad/current'")
(out/'large.py').write_text(s)
(out/'manifest.json').write_text(json.dumps(dict(label=label,files=len(h),source=str(out/'core'),baseline='865040bf',baseline_source='.local/next-boundary-20261004/boundary-final-r2/core',scope='solver only; no GT machines or server',build_gradle_sha256=hashlib.sha256((r/'build.gradle').read_bytes()).hexdigest()),indent=2))
print(out)
