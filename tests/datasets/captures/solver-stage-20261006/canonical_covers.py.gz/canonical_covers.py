from pathlib import Path
import subprocess,shutil,concurrent.futures,json
r=Path.cwd();a=r/'.local/solver-stage-20261006'
def run(rounds):
 label='stage1006-canonical-cover-'+str(rounds);source=a/(label+'-source');shutil.copytree(r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core',source)
 f=source/'CountCanonicalModel.java';s=f.read_text();s=s.replace('    List<ExactLinearProgram.Constraint> rows() {','''    void addCuts(List<ExactLinearProgram.Constraint> additions) {
        long extra = additions.stream().mapToLong(row -> 256L + 256L * row.terms().size()).sum();
        if (!budget.tryReserve(extra)) return;
        memory += extra;
        var all = new ArrayList<>(rows); all.addAll(additions); rows = List.copyOf(all);
    }
    List<ExactLinearProgram.Constraint> rows() {''');f.write_text(s)
 f=source/'CountLpSearch.java';s=f.read_text();code='''
            for (int round = 0; round < ROUNDS; round++) {
                var lo = canonical.lower(); var hi = canonical.upper();
                try (var proposal = CountLpLearning.solve(canonical.rows(), lo, hi, budget, Math.min(200000, budget.remainingWork() / 16))) {
                    if (proposal == null || proposal.point == null) break;
                    ExactRational[] point = new ExactRational[variables];
                    for (int i = 0; i < variables; i++) point[i] = new ExactRational(BigInteger.valueOf(Math.round(proposal.point[i] * 1000000)), BigInteger.valueOf(1000000));
                    try (var separation = new CountCoverCuts(canonical.rows(), lo, hi, point, budget)) {
                        while (!separation.step()) {}
                        if (separation.cuts().isEmpty()) break;
                        canonical.addCuts(separation.cuts());
                    }
                }
            }
            '''.replace('ROUNDS',str(rounds))
 s=s.replace('if (canonical == null) return null;', 'if (canonical == null) return null;'+code);f.write_text(s)
 with (a/(label+'.log')).open('wb')as log:p=subprocess.run(['python','.local/structural-stage-20261004/run.py',label,'--source',str(source),'--filter','lseu','--variations','2'],stdout=log,stderr=subprocess.STDOUT)
 out=r/'.local/structural-stage-20261004'/label/'results.jsonl';print(rounds,p.returncode,[(x['id'],x['status'],x['work'])for x in map(json.loads,out.read_text().splitlines())],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,[1,2,4]))
