from pathlib import Path
import subprocess,concurrent.futures,json,os
r=Path.cwd();a=r/'.local/solver-stage-20261006/engines-r5';a.mkdir();classes=r/'.local/next-boundary-20261004/stage1006-budget-r5/outer/classes'
cp=os.pathsep.join(map(str,[classes,r/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar']))
def job(mode):
 out=a/(mode+'.jsonl')
 with (a/(mode+'.log')).open('wb')as log:result=subprocess.run(['C:/Users/autumn/.jdks/corretto-20.0.2.1/bin/java.exe','-ea','-Xmx1g','-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.CountBenchmark',str(r/'.local/solver-stage-20261006/hard-unsat.json'),str(out),mode,'4000000','lseu','1'],stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CGSE_BENCH_WALL_MS='10000'))
 values=[json.loads(x)for x in out.read_text().splitlines()];print(mode,[(v['status'],v['work'])for v in values],result.returncode,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(job,['pb-retained','pb-lrb','lcg-retained','view-retained','quick']))
