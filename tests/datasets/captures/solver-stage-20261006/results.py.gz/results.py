from pathlib import Path
import sys,json
for name in sys.argv[1:]:
 p=Path(name)
 for line in p.read_text().splitlines():
  x=json.loads(line)
  if any(s in x.get('id','')for s in ('stein27','lseu-objective-1119','multiple_knapsack_sat-objective--396')):
   print(x['id'],x.get('variation'),x.get('status',x.get('result')),x['work'])
   if 'strategyMetrics'in x:print({k:v['chargedWork']for k,v in x['strategyMetrics'].items()})
   if 'stein27' in x['id']:
    d=x['diagnostics'];d=d.split(' | ')if isinstance(d,str)else d
    print([s for s in d if any(t in s for t in ('cardinality','count_structure','integer_counts@'))])
