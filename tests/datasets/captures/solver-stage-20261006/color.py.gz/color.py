import json,time
from pathlib import Path
c=next(x for x in json.loads(Path('.local/solver-stage-20261006/hard-unsat.json').read_text()) if x['id']=='scip/stein27_inf')
n=len(c['lower']);allbits=(1<<n)-1
rows=[]
for r in c['rows']:
 p=sum(1<<int(k) for k,v in r['terms'].items() if int(v)>0); m=sum(1<<int(k) for k,v in r['terms'].items() if int(v)<0)
 rows.append((p,m,int(r['upper'])+m.bit_count()))
rows.sort(key=lambda r:(r[0]|r[1]).bit_count())
nodes=prunes=work=0;start=time.perf_counter();stack=[(0,0)]
while stack:
 one,zero=stack.pop();nodes+=1
 while True:
  before=one|zero
  for p,m,k in rows:
   work+=1;fixed=(p&one).bit_count()+(m&zero).bit_count()
   if fixed>k:break
   if fixed==k:
    free=(p|m)&~(one|zero);one|=m&free;zero|=p&free
  else:
   if before!=one|zero:continue
   break
  break
 else:raise AssertionError()
 if fixed>k:continue
 free=allbits&~(one|zero)
 if not free:raise AssertionError('unexpected SAT')
 adj=[0]*n
 for p,m,k in rows:
  work+=1
  if k-(p&one).bit_count()-(m&zero).bit_count()!=1:continue
  group=m&free
  for v in range(n):
   if group>>v&1:adj[v]|=group&~(1<<v);work+=1
 # clique cover of the conflict graph bounds further zero choices.
 left=free;colors=0
 while left:
  colors+=1;rest=left
  while rest:
   v=(rest&-rest).bit_length()-1;bit=1<<v;left&=~bit;rest&=adj[v];work+=1
 if zero.bit_count()+colors<11:prunes+=1;continue
 score=[0]*n
 for p,m,k in rows:
  work+=1;slack=k-(p&one).bit_count()-(m&zero).bit_count();a=(p|m)&free
  if a.bit_count()<=slack:continue
  for v in range(n):
   if a>>v&1:score[v]+=4 if slack==1 else 1;work+=1
 v=max((v for v in range(n) if free>>v&1),key=lambda v:score[v]);bit=1<<v
 stack.append((one|bit,zero));stack.append((one,zero|bit))
print(dict(nodes=nodes,prunes=prunes,work=work,seconds=time.perf_counter()-start))
