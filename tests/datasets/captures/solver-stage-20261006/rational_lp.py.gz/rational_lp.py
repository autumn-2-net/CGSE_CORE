from pathlib import Path
import subprocess,shutil
r=Path.cwd();a=r/'.local/solver-stage-20261006';label='stage1006-rational-lp-r1';source=a/(label+'-source');shutil.copytree(r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core',source)
f=source/'CountLpLearning.java';s=f.read_text();s=s.replace('int span = Double.isFinite(minimumDual)', '''var rational = rationalWeights(numerical.dual(), source, originals, numerical.phaseOneInfeasible() ? -1 : objective, maximumDual);
            if (rational != null) cut = combine(rows, rational, low, high);
            if (cut != null) return new Result(point, cut, numerical.phaseOneInfeasible(), numerical.work(), budget, bytes);
            int span = Double.isFinite(minimumDual)''')
method='''
    private Map<Integer, BigInteger> rationalWeights(double[] dual, List<Integer> source, int originals, int objective, double scale) {
        Map<Integer, ExactRational> fractions = new TreeMap<>();
        BigInteger denominator = BigInteger.ONE;
        for (int i = 0; i <= originals; i++) {
            check();
            if (i == originals && objective < 0) break;
            double value = i == originals ? 1 : dual[i];
            if (!(value > 0) || !Double.isFinite(value)) continue;
            var fraction = fraction(value / scale);
            if (fraction == null) return null;
            if (fraction.signum() == 0) continue;
            denominator = denominator.divide(denominator.gcd(fraction.denominator())).multiply(fraction.denominator());
            if (denominator.bitLength() > 60) return null;
            fractions.merge(i == originals ? objective : source.get(i), fraction, ExactRational::add);
        }
        Map<Integer, BigInteger> weights = new TreeMap<>();
        for (var entry : fractions.entrySet()) {
            check();
            var value = entry.getValue();
            weights.put(entry.getKey(), value.numerator().multiply(denominator.divide(value.denominator())));
        }
        return weights;
    }

    private ExactRational fraction(double value) {
        if (!(value >= 0) || !Double.isFinite(value)) return null;
        long p0 = 0, q0 = 1, p1 = 1, q1 = 0;
        double rest = value;
        for (int i = 0; i < 24; i++) {
            check();
            double whole = Math.floor(rest);
            if (whole > 65536) return null;
            long a = (long) whole, p = a * p1 + p0, q = a * q1 + q0;
            if (q <= 0 || q > 65536) return null;
            if (Math.abs((double) p / q - value) <= 1e-9) return new ExactRational(BigInteger.valueOf(p), BigInteger.valueOf(q));
            double residual = rest - whole;
            if (!(residual > 0)) return null;
            p0 = p1; q0 = q1; p1 = p; q1 = q; rest = 1 / residual;
        }
        return null;
    }

'''
s=s.replace('    private BigInteger weight(double value,',method+'    private BigInteger weight(double value,');f.write_text(s)
p=subprocess.run(['python','.local/structural-stage-20261004/run.py',label,'--source',str(source),'--filter','lseu','--variations','4']);print(p.returncode)
