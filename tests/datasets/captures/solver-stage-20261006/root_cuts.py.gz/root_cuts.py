from pathlib import Path
import subprocess,shutil,concurrent.futures,json
r=Path.cwd();a=r/'.local/solver-stage-20261006'
def run(mode):
 label='stage1006-root-'+mode;source=a/(label+'-source');shutil.copytree(r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core',source)
 f=source/'CountLpSearch.java';s=f.read_text();code='''
            try (var proposal = CountLpLearning.solve(source, lower, upper, budget, Math.min(200000, budget.remainingWork() / 16))) {
                if (proposal != null && proposal.point != null) {
                    ExactRational[] point = new ExactRational[variables];
                    for (int i = 0; i < variables; i++) point[i] = new ExactRational(BigInteger.valueOf(Math.round(proposal.point[i] * 1000000)), BigInteger.valueOf(1000000));
                    CUTS
                }
            }
            '''
 cuts=''
 if mode in ('cover','both'):cuts+='''try (var separation = new CountCoverCuts(source, lower, upper, point, budget)) {
                        while (!separation.step()) {}
                        source.addAll(separation.cuts());
                    }'''
 if mode in ('round','both'):cuts+='''try (var separation = new CountRoundingCuts(source, lower, point, budget)) {
                        while (!separation.step()) {}
                        source.addAll(separation.cuts());
                    }'''
 code=code.replace('CUTS',cuts)
 s=s.replace('canonical = CountCanonicalModel.create(source, lower, upper, budget);',code+'canonical = CountCanonicalModel.create(source, lower, upper, budget);');f.write_text(s)
 with (a/(label+'.log')).open('wb')as log:p=subprocess.run(['python','.local/structural-stage-20261004/run.py',label,'--source',str(source),'--filter','lseu','--variations','2'],stdout=log,stderr=subprocess.STDOUT)
 out=r/'.local/structural-stage-20261004'/label/'results.jsonl';print(mode,p.returncode,[(x['id'],x['status'],x['work'])for x in map(json.loads,out.read_text().splitlines())],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,['cover','round','both']))
