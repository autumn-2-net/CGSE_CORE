from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,zipfile
r=Path.cwd();area=r/'.local/next-boundary-20261004';out=area/'solver-stage-20261007-final'
source=r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text('utf8'))
def lines(p):return [json.loads(s)for s in p.read_text('utf8').splitlines()]
manifest=read(out/'source-hashes.json')
assert {p.name:sha(p)for p in source.glob('*.java')}==manifest
assert sha(r/'build.gradle')=='a17e1b46f2642be5c470eb3c130e02606b194574fefe08c5cccf229af8b8f9c0'
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
production=[p for p in changed if p.startswith('src/main/java/')]
assert len(production)==11 and len(changed)==12,changed
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
subprocess.run(['git','diff','--check'],check=True)
jar=r/'build/libs/gtlcore-1.2.3.2-fix3.jar';dev=r/'build/devlibs/gtlcore-1.2.3.2-fix3-dev.jar'
classes=r/'build/classes/java/main';files=list((classes/'org/gtlcore/gtlcore/integration/ae2/graph/core').glob('*.class'))
with zipfile.ZipFile(dev)as z:
 for file in files:assert z.read(file.relative_to(classes).as_posix())==file.read_bytes(),file.name
with zipfile.ZipFile(jar)as z:
 assert all(file.relative_to(classes).as_posix()in z.namelist()for file in files)
 assert all(file.name not in z.namelist() for file in [Path('AGENTS.md'),Path('WitnessReuseProbe.class')])
# Loom rewrites class metadata during remapping. Compare disassembled production
# methods instead of incorrectly expecting byte-identical remapped class files.
names=[p.removeprefix('src/main/java/').removesuffix('.java').replace('/','.')for p in production]
javap='C:/Users/autumn/.jdks/corretto-20.0.2.1/bin/javap.exe'
disassembled=[]
def symbolic(text):
 result=[]
 for block in text.split('    Code:'):
  entries=re.findall(r'^\s*(\d+):\s+([a-z][a-z0-9_]*)\b',block,re.M)
  labels={int(offset):str(i)for i,(offset,op)in enumerate(entries)}
  def target(v):
   offset=int(v)
   if offset in labels:return 'L'+labels[offset]
   assert labels and offset>max(labels),offset
   return 'END'
  for line in block.splitlines():
   code,sep,comment=line.partition('//')
   code=re.sub(r'#\d+','#CP',code)
   match=re.match(r'^\s*(\d+):\s+([a-z][a-z0-9_]*)\b(.*)',code)
   if match:
    offset,op,operands=match.groups();op={'ldc_w':'ldc','goto_w':'goto'}.get(op,op)
    if op.startswith('if') or op in ('goto','jsr'):operands=target(operands.strip())
    code=target(offset)+': '+op+' '+operands
   elif re.match(r'^\s*(default|-?\d+):\s*-?\d+\s*$',code):
    key,offset=code.strip().split(':');code=key+': '+target(offset.strip())
   else:
    m=re.match(r'^\s*(\d+)\s+(\d+)\s+(\d+)\s+(.+)$',code)
    if m:code=' '.join([target(m[1]),target(m[2]),target(m[3]),m[4]])
   code=' '.join(code.split());comment=re.sub(r'#\d+','#CP',comment.strip())
   result.append(code+(' // '+comment if sep else ''))
 return '\n'.join(result)
for tag,file in [('dev',dev),('remapped',jar)]:
 text=subprocess.check_output([javap,'-classpath',str(file),'-p','-c','-s']+names,text=True,encoding='utf8')
 (out/(tag+'-methods.txt')).write_text(text,'utf8')
 disassembled.append(symbolic(text))
assert disassembled[0]==disassembled[1],'Core methods changed during remapping'
artifact=out/'gtlcore-1.2.3.2-fix3-cgse-20261007-test.jar'
assert not artifact.exists();shutil.copy2(jar,artifact)
artifact.with_suffix(artifact.suffix+'.sha256').write_text(sha(artifact)+'  '+artifact.name+'\n')
artifact_report=dict(file=str(artifact.relative_to(r)),sha256=sha(artifact),bytes=artifact.stat().st_size,dev_graph_classes_verified=len(files),remapped_core_classes_disassembled=len(names))
(out/'artifact.json').write_text(json.dumps(artifact_report,indent=2))
broad=read(area/'solver-stage-20261007-final-broad/comparison.json')
for profile in broad:
 assert not profile['regressions']and not profile['wrong']
 profile['work_reduction_percent']=100*(1-profile['current']['work']/profile['baseline']['work'])
 for version in ['baseline','current']:
  rows=lines(area/f'solver-stage-20261007-final-broad/{version}/large-{profile["profile"]}.jsonl')
  peaks=sorted(x['peak_bytes']for x in rows)
  profile[version]['peak_bytes']=max(peaks);profile[version]['p95_peak_bytes']=peaks[int(.95*(len(peaks)-1))]
matrix=read(r/'.local/structural-stage-20261004/solver-stage-20261007-final-boundary/summary.json')
assert matrix['failed']==0
matrix['baseline_work']=848204628;matrix['work_reduction_percent']=100*(1-matrix['work']/matrix['baseline_work'])
regression=read(out/'regression/summary.json')
probes=r/'.local/structural-stage-20261004/stage1007-final-probes'
new_reports={p.name:read(p)for p in probes.glob('*.json')if p.name!='source-hashes.json'}
assert read(probes/'source-hashes.json')==manifest
for filename in ['ConditionalColorProbe','PbImportProbe','RetainedStructureProbe','PbDecisionImportProbe','WitnessReuseProbe']:
 assert (probes/(filename+'.log')).exists()
outer=lines(out/'outer/outer-proof-scan.jsonl')
limit=[x for x in outer if x['result']=='SEARCH_LIMIT'];assert len(limit)==1 and limit[0]['id']=='scip/lseu-objective-1119'
larger=lines(out/'outer-lseu-20m/outer-proof-scan.jsonl')
baseline_larger=lines(area/'boundary-final-r2/stage1007-lseu-20m/outer-proof-scan.jsonl')
assert next(x for x in larger if '1119'in x['id'])['result']=='MISSING_INPUT'
assert next(x for x in baseline_larger if '1119'in x['id'])['result']=='SEARCH_LIMIT'
ab=read(out/'first-witness-ab/comparison.json');assert not any(x['regressions']or x['wrong']for x in ab['trials'])
report=dict(scope='CGSE solver only; no GT machine/server tests or deployment',baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_files=len(manifest),source_manifest_sha256=sha(out/'source-hashes.json'),production_files=production,preexisting_build_gradle_unchanged=True,committed=False,pushed=False,
 changes=['Conditional clique-cover bounds for cardinality branches; branch-local edges never exported as root facts.','Guarded, exact cross-view conflicts imported by retained PB/CDCL; live imports attach at root and participate in proof replay.','Cardinality and packing frontiers survive local cutoffs; structurally suitable searches run before generic enumeration.','Root workers do not duplicate owned structural/weighted-LP frontiers under the shared budget.','A bounded transactional tree witness reuses actual-stock source estimates without rewriting the original source frontier; workspace decline is optional and all accepted plans are verified.'],
 build=dict(passed=True,log='.local/structural-stage-20261004/stage1007-production-final-build.log',tasks=['spotlessApply','graphCoreTest','graphIntegrationTest','build'],upstream_tests_preserved=True),
 broad=broad,hard_matrix=matrix,specialized_regression=regression,new_probes=new_reports,new_probe_assertions=33394,
 outer_4m=dict(requests=len(outer),feasible=sum(x['result'].startswith('FEASIBLE')for x in outer),proven_missing=sum(x['result']=='MISSING_INPUT'for x in outer),search_limit=len(limit)),
 remaining_budget_boundary=dict(id=limit[0]['id'],work_limit=4_000_000,result=limit[0]['result'],at_20m_baseline=[{k:x[k]for k in ['id','result','work']}for x in baseline_larger],at_20m_current=[{k:x[k]for k in ['id','result','work']}for x in larger],note='Not claiming every instance resolves at every work limit; exhaustion remains UNKNOWN/SEARCH_LIMIT rather than a false missing-input proof.'),
 latency_ab=dict(trials=7,cases_per_trial=192,median_trials=ab['medianTrials'],method=ab['method'],interpretation='Small first-witness workload is effectively unchanged; gains are concentrated in broad sweeps and hard cases, not a claim of universal latency improvement.'),artifact=artifact_report)
(out/'completion.json').write_text(json.dumps(report,indent=2),'utf8')
print(json.dumps(dict(artifact=artifact_report,report=str((out/'completion.json').relative_to(r)),broad_requests=sum(x['current']['requests']for x in broad),hard_matrix=matrix,outer_4m=report['outer_4m'],latency_ab=ab['medianTrials']),indent=2))
