from pathlib import Path
import subprocess,shutil,json
r=Path.cwd();a=r/'.local/solver-stage-20261006';label='stage1006-boolean-lcg-r1';source=a/(label+'-source');shutil.copytree(r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core',source)
f=source/'CountLcg.java';s=f.read_text();s=s.replace('int prefix = trail.size();\n        var candidates', 'BigInteger booleanSlack = learnedRelaxation ? row.upper().subtract(sum) : null;\n        int prefix = trail.size();\n        var candidates')
s=s.replace('BigInteger endpoint = a.signum() > 0 ? low[id] : high[id];\n            BigInteger other', '''if (booleanSlack != null) {
                if (!low[id].equals(high[id]) && a.abs().compareTo(booleanSlack) > 0) {
                    candidates.add(new Literal(id, a.signum() < 0, a.signum() < 0 ? BigInteger.ONE : BigInteger.ZERO));
                    explanations.add(new LinearReason(row, id, a.abs().subtract(booleanSlack).subtract(BigInteger.ONE), prefix, rowId));
                }
                continue;
            }
            BigInteger endpoint = a.signum() > 0 ? low[id] : high[id];
            BigInteger other''');f.write_text(s)
p=subprocess.run(['python','.local/structural-stage-20261004/run.py',label,'--source',str(source),'--filter','lseu','--variations','4']);print(p.returncode)
