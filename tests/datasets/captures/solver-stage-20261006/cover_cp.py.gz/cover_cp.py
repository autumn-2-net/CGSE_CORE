from pathlib import Path
import subprocess,shutil,concurrent.futures,json
r=Path.cwd();a=r/'.local/solver-stage-20261006'
def run(mode):
 label='stage1006-cover-cp-'+mode;source=a/(label+'-source');shutil.copytree(a/'stage1006-canonical-cover-2-source',source)
 f=source/'CountLpSearch.java';s=f.read_text().replace('.learnedRelaxation();','.lockBranching();' if mode=='locks' else ';').replace('            if (!search.learnedRelaxationEnabled()) return null;','');f.write_text(s)
 with (a/(label+'.log')).open('wb')as log:p=subprocess.run(['python','.local/structural-stage-20261004/run.py',label,'--source',str(source),'--filter','lseu','--variations','2'],stdout=log,stderr=subprocess.STDOUT)
 out=r/'.local/structural-stage-20261004'/label/'results.jsonl';print(mode,p.returncode,[(x['id'],x['status'],x['work'])for x in map(json.loads,out.read_text().splitlines())],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,['locks','plain']))
