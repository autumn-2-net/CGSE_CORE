from pathlib import Path
import json,sys
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.local/next-boundary-20261004/boundary-final-r2/outer/outer-proof-scan.jsonl')
for line in p.read_text().splitlines():
 x=json.loads(line)
 if not any(s in x['id'] for s in ('stein27','lseu-objective-1119','multiple_knapsack_sat-objective--396')):continue
 print('\n',x['id'],x['result'],x['work'])
 print('metrics',x['strategyMetrics'])
 for s in x['diagnostics']:
  if len(sys.argv)>2 and not any(t in s for t in sys.argv[2].split(',')):continue
  if any(t in s for t in ('cardinality','bin_packing','count_compile','count_reduction','count_implications','count_hermite','count_count','count_structure','integer_counts','view','source_face','residue','count_portfolio','count_lp','count_partition','count_recovery')):print(s)
