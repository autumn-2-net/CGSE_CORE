from pathlib import Path
import subprocess,concurrent.futures,shutil,json
r=Path.cwd();base=r/'.local/solver-stage-20261006'
def run(gap):
 label='stage1006-cadence-'+str(gap)
 source=base/(label+'-source');shutil.copytree(r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core',source)
 f=source/'CountLcg.java';s=f.read_text();s=s.replace('(relaxationDecisions != decisions || relaxationConflicts != conflicts) && relax()', '(relaxationDecisions < 0 || decisions - relaxationDecisions >= '+str(gap)+' || conflicts - relaxationConflicts >= '+str(gap)+') && relax()');f.write_text(s)
 with (base/(label+'.log')).open('wb')as log:p=subprocess.run(['python','.local/structural-stage-20261004/run.py',label,'--source',str(source),'--filter','lseu','--variations','2'],stdout=log,stderr=subprocess.STDOUT)
 out=r/'.local/structural-stage-20261004'/label/'results.jsonl'
 print(gap,p.returncode,[(x['id'],x['variation'],x['status'],x['work'])for x in map(json.loads,out.read_text().splitlines())],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,[2,4,8]))
