from pathlib import Path
import sys,json,subprocess,os,shutil
r=Path.cwd();a=r/'.local/solver-stage-20261006';out=a/sys.argv[1];out.mkdir()
core=(r/sys.argv[2]) if len(sys.argv)>2 else r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core'
shutil.copytree(core,out/'core');classes=out/'classes';classes.mkdir()
source=(r/'.local/review-startup-20261004/LargeSweep.java').read_text().replace('public final class LargeSweep','public final class FocusedLowSweep')
source=source.replace('JsonObject row = new JsonObject();','budget.enableMetrics();\n        var stages = new LinkedHashSet<String>();\n        JsonObject row = new JsonObject();',1)
source=source.replace('while (!work.step()) {}','while (!work.step()) { stages.addAll(Arrays.asList(budget.diagnostics().split(" \\\\| "))); }')
source=source.replace('row.addProperty("diagnostics", budget.diagnostics());','row.addProperty("diagnostics", budget.diagnostics()); row.add("trace",JSON.toJsonTree(stages)); row.add("strategyMetrics",JSON.toJsonTree(budget.metrics().strategies()));')
(out/'FocusedLowSweep.java').write_text(source)
jdk=Path('C:/Users/autumn/.jdks/corretto-20.0.2.1/bin');gson=r/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'
cp=os.pathsep.join(map(str,[classes,gson]));args=['--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(classes)]+list(map(str,(out/'core').glob('*.java')))+[str(out/'FocusedLowSweep.java')]
fixture=(r/sys.argv[3]) if len(sys.argv)>3 else a/'low-budget.json'
(out/'javac.args').write_text('\n'.join('"'+x.replace('\\','/')+'"' for x in args))
subprocess.run([str(jdk/'javac.exe'),'@'+str(out/'javac.args')],check=True)
with (out/'run.log').open('wb')as log:subprocess.run([str(jdk/'java.exe'),'-ea','-Xmx1g','-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.FocusedLowSweep',str(r/'.local/miracle-cycle-20261002/audit-original-catalog.json'),str(fixture),str(out/'results.jsonl'),'1'],stdout=log,stderr=subprocess.STDOUT,check=True)
all=[json.loads(l)for l in (out/'results.jsonl').read_text().splitlines()];print(dict(total=len(all),failed=sum(not x['feasible']for x in all),work=sum(x['work']for x in all)))
for x in all:
 if not x['feasible']:print(x['group'],x['request'],x['result'],x['work']);print(x['strategyMetrics'])
