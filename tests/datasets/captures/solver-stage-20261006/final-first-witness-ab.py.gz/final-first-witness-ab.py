from pathlib import Path
import argparse, hashlib, json, math, os, shutil, statistics, subprocess

r=Path.cwd();area=r/'.local/next-boundary-20261004'
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--trials',type=int,default=7);args=p.parse_args()
a=area/args.label;out=a/'first-witness-ab';out.mkdir()
jdk=Path('C:/Users/autumn/.jdks/corretto-20.0.2.1/bin');gson=r/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'
fixture=r/'.local/new-stage-20261004/order-audit/policy-fixture.json';shutil.copy2(fixture,out/fixture.name)
probe=(r/'.local/new-stage-20261004/order-audit/PolicyFirstWitnessProbe.java').read_text('utf8')
old='for(int i=0;i<32;i++)solve(cases.get(i));'
assert old in probe
probe=probe.replace(old,'for(int warmup=0;warmup<2;warmup++)for(var c:cases)solve(c);')
(out/'PolicyFirstWitnessProbe.java').write_text(probe,'utf8')
helpers=[r/'.local/new-stage-20261004/order-audit/OrderRetryRegression.java',r/'.local/review-startup-20261004/LargeSweep.java',out/'PolicyFirstWitnessProbe.java']
versions={'baseline':r/'.local/next-boundary-20261004/boundary-final-r2/core','current':a/'core'}
for name,src in versions.items():
 folder=out/name;folder.mkdir();shutil.copytree(src,folder/'core');classes=folder/'classes';classes.mkdir()
 hashes={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in (folder/'core').glob('*.java')};(folder/'source-hashes.json').write_text(json.dumps(hashes,indent=2),'utf8')
 if name=='current':assert hashes==json.loads((a/'source-hashes.json').read_text('utf8'))
 cp=os.pathsep.join(map(str,[classes,gson]));options=['--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(classes)]+list(map(str,(folder/'core').glob('*.java')))+list(map(str,helpers))
 argfile=folder/'javac.args';argfile.write_text('\n'.join('"'+s.replace('\\','/')+'"' for s in options),'utf8')
 with (folder/'compile.log').open('wb') as log:subprocess.run([str(jdk/'javac.exe'),'@'+str(argfile)],stdout=log,stderr=subprocess.STDOUT,check=True)
for trial in range(args.trials):
 for name in (['baseline','current'] if trial%2==0 else ['current','baseline']):
  folder=out/name;dest=folder/f'trial-{trial}.jsonl';cp=os.pathsep.join(map(str,[folder/'classes',gson]));cmd=[str(jdk/'java.exe'),'-ea','-Xms512m','-Xmx1g','-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.PolicyFirstWitnessProbe',str(out/fixture.name),str(dest)]
  with (folder/f'trial-{trial}.log').open('wb') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
  print(name,trial,'done',flush=True)
def quantile(xs,q):
 xs=sorted(xs);i=(len(xs)-1)*q;lo=math.floor(i);return xs[lo]+(xs[min(lo+1,len(xs)-1)]-xs[lo])*(i-lo)
def stats(rows):
 solved=[row for row in rows.values() if row['verified']];ms=[x['firstNanos']/1e6 for x in solved]
 return dict(cases=len(rows),verified=len(solved),totalWork=sum(x['firstWork'] for x in solved),totalMillis=sum(ms),p50Millis=quantile(ms,.5),p95Millis=quantile(ms,.95),p99Millis=quantile(ms,.99),maxMillis=max(ms))
reports=[]
for trial in range(args.trials):
 data={name:{x['id']:x for x in map(json.loads,(out/name/f'trial-{trial}.jsonl').read_text('utf8').splitlines())} for name in versions};old,new=data['baseline'],data['current'];assert old.keys()==new.keys()
 reports.append(dict(trial=trial,baseline=stats(old),current=stats(new),regressions=[k for k in old if old[k]['verified'] and not new[k]['verified']],wrong=[k for k in new if old[k]['verified'] and new[k]['infeasible']],workChanges=[dict(id=k,before=old[k]['firstWork'],after=new[k]['firstWork']) for k in new if old[k]['verified'] and new[k]['verified'] and old[k]['firstWork']!=new[k]['firstWork']]))
summary={'source':str((a/'core').relative_to(r)),'baseline':str(versions['baseline'].relative_to(r)),'trials':reports,'medianTrials':{name:{key:statistics.median(x[name][key] for x in reports) for key in ['totalWork','totalMillis','p50Millis','p95Millis','p99Millis','maxMillis']} for name in versions},'method':'Serial paired A/B, alternating order, fresh JVMs with full 192-case workload warmed twice, explicit fixed heap; no concurrent validation or server during measurement. Elapsed results remain noisy and are not correctness assertions.'}
(out/'comparison.json').write_text(json.dumps(summary,indent=2),'utf8');print(json.dumps(summary['medianTrials'],indent=2))
if any(x['regressions'] or x['wrong'] for x in reports):raise SystemExit(1)
