from pathlib import Path
import subprocess,shutil,json
r=Path.cwd();a=r/'.local/solver-stage-20261006';label='stage1006-lp-light-r1';source=a/(label+'-source');shutil.copytree(r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core',source)
f=source/'CountLpSearch.java';s=f.read_text();s=s.replace('canonical = CountCanonicalModel.create(source, lower, upper, budget);','''try (var light = CountModelViews.create(source, lower, upper, budget)) {
                if (light != null) {
                    light.compileLight();
                    var available = light.available();
                    source = new ArrayList<>(available.get(available.size() - 1).rows());
                }
            }
            canonical = CountCanonicalModel.create(source, lower, upper, budget);''');f.write_text(s)
p=subprocess.run(['python','.local/structural-stage-20261004/run.py',label,'--source',str(source),'--filter','lseu','--variations','4']);print(p.returncode)
