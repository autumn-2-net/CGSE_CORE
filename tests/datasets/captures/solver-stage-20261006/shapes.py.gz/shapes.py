import json
from pathlib import Path
cases=json.loads(Path('.local/solver-stage-20261006/hard-unsat.json').read_text())
c=next(x for x in cases if 'lseu' in x['id']);n=len(c['lower'])
for i,r in enumerate(c['rows']): print(i,len(r['terms']),r)
for skip,r in enumerate(c['rows']):
 if len(r['terms'])<n//2:continue
 parent=list(range(n))
 def root(i):
  while parent[i]!=i:i=parent[i]
  return i
 for j,s in enumerate(c['rows']):
  if j==skip:continue
  ids=list(map(int,s['terms']))
  for k in ids[1:]:parent[root(k)]=root(ids[0])
 groups={}
 for i in range(n):groups.setdefault(root(i),[]).append(i)
 print('skip',skip,'components',list(groups.values()))
groups=json.loads(Path('.local/solver-stage-20261006/low-budget.json').read_text())
g=groups[0];print('LOW', {k:v for k,v in g.items() if k not in ('catalog','requests')});print(json.dumps(g['catalog'],indent=2))
