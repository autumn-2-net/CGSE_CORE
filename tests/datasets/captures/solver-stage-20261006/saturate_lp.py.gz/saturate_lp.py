from pathlib import Path
import shutil,subprocess
r=Path.cwd();a=r/'.local/solver-stage-20261006';out=a/'saturate-lp-source';shutil.copytree(r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core',out)
f=out/'CountLpSearch.java';s=f.read_text();s=s.replace('canonical = CountCanonicalModel.create(source, lower, upper, budget);','''
            var saturated = new ArrayList<ExactLinearProgram.Constraint>();
            for (var row : source) {
                BigInteger maximum = BigInteger.ZERO;
                for (var e : row.terms().entrySet()) { budget.check(); maximum=maximum.add(e.getValue().multiply(e.getValue().signum()>0?upper[e.getKey()]:lower[e.getKey()])); }
                BigInteger demand=maximum.subtract(row.upper());
                if(demand.signum()<=0)continue;
                var terms=new LinkedHashMap<Integer,BigInteger>();BigInteger rhs=demand.negate();boolean changed=false;
                for(var e:row.terms().entrySet()) { budget.check(); int i=e.getKey(); if(lower[i].equals(upper[i]))continue;
                    BigInteger cap=e.getValue().abs().min(demand);if(!cap.equals(e.getValue().abs()))changed=true;
                    terms.put(i,e.getValue().signum()>0?cap:cap.negate());if(e.getValue().signum()>0)rhs=rhs.add(cap);
                }
                if(changed)saturated.add(CountReduction.normalize(new ExactLinearProgram.Constraint(terms,rhs)));
            }
            source.addAll(saturated);
            canonical = CountCanonicalModel.create(source, lower, upper, budget);
''');f.write_text(s)
subprocess.run(['python','.local/structural-stage-20261004/run.py','stage1007-saturate-lp','--source',str(out),'--filter','lseu','--variations','2'],check=True)
