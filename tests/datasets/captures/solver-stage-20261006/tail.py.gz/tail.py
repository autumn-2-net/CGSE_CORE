from pathlib import Path
import json,sys
r=Path.cwd();label=sys.argv[1];a=r/'.local/next-boundary-20261004';current=[json.loads(x)for x in (a/label/'current/large-0.jsonl').read_text().splitlines()];old=[json.loads(x)for x in (a/'boundary-final-r2-broad/current/large-0.jsonl').read_text().splitlines()];base={(x['group'],json.dumps(x['request'],sort_keys=True)):x for x in old}
failed=[x for x in current if not x['feasible']];regressed=[(base[(x['group'],json.dumps(x['request'],sort_keys=True))],x)for x in failed];groups={x['group']for x in failed}
source=json.loads((r/'.local/review-startup-20261004/large-0.json').read_text());selected=[x for x in source if x['name']in groups] if 'name'in source[0]else[x for x in source if x.get('group',x.get('id'))in groups]
(r/'.local/solver-stage-20261006/new-low-budget.json').write_text(json.dumps(selected,indent=2));(r/'.local/solver-stage-20261006/new-tail.json').write_text(json.dumps(regressed,indent=2))
print('groups',groups,'selected',len(selected),'keys',list(source[0]))
for before,after in regressed:print(after['group'],after['request'],'old',before['result'],before['work'],'new',after['result'],after['work']);print(after['diagnostics'][-2200:])
