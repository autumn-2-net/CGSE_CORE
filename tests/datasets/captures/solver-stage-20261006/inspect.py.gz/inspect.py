from pathlib import Path
import collections, json

r=Path.cwd(); out=r/'.local/solver-stage-20261006'; out.mkdir(exist_ok=True)
cases=json.loads((r/'.local/solver-weighted-20261003/public-finite.json').read_text())
names=['scip/lseu-objective-1119','scip/stein27_inf','ortools/multiple_knapsack_sat-objective--396']
selected=[c for c in cases if c['id'] in names]
(out/'hard-unsat.json').write_text(json.dumps(selected,indent=2))
for c in selected:
 print(c['id'], 'vars',len(c['lower']),'rows',len(c['rows']),'widths',collections.Counter(str(int(b)-int(a)) for a,b in zip(c['lower'],c['upper'])))
 print('coefficients',collections.Counter(str(v) for row in c['rows'] for v in row['terms'].values()).most_common(10))
 print('row_sizes',collections.Counter(len(row['terms']) for row in c['rows']), 'bounds',collections.Counter(str(row['upper']) for row in c['rows']).most_common(10))
for line in (r/'.local/next-boundary-20261004/boundary-final-r2/outer/outer-proof-scan.jsonl').read_text().splitlines():
 x=json.loads(line)
 if x['id'] in names:
  print('\nTRACE',x['id'], x['result'],x['work'], 'metrics',x['strategyMetrics'])
  for d in x['diagnostics'][-20:]:print(d)
fail=[]
for line in (r/'.local/next-boundary-20261004/boundary-final-r2-broad/current/large-0.jsonl').read_text().splitlines():
 x=json.loads(line)
 if not x['feasible']:fail.append(x)
(out/'budget-failures.json').write_text(json.dumps(fail,indent=2))
print('\nLOW BUDGET',len(fail))
for x in fail: print(x['group'],x['request'],x['result'],x['work'])
groups=json.loads((r/'.local/review-startup-20261004/large-0.json').read_text())
ids={x['group'] for x in fail};chosen=[x for x in groups if x['id'] in ids]
(out/'low-budget.json').write_text(json.dumps(chosen,indent=2))
print('failed_groups',len(chosen))
