import json,time
from pathlib import Path
c=next(c for c in json.loads(Path('.local/solver-stage-20261006/hard-unsat.json').read_text()) if 'lseu' in c['id'])
n=len(c['lower']);rs=[({int(i):int(a)for i,a in r['terms'].items()},int(r['upper']))for r in c['rows']]
groups=[];used=set()
for a,b in rs:
 if b==1 and len(a)>1 and set(a.values())=={1} and not used.intersection(a):groups.append(list(a));used.update(a)
groups += [[i]for i in range(n)if i not in used]
rows=[]
for a,b in rs:
 terms=[]
 for gi,g in enumerate(groups):
  vals=[0]+[a.get(i,0)for i in g]
  if not any(vals):continue
  mins=[0]*(1<<len(vals))
  for mask in range(1,len(mins)):
   bit=mask&-mask;mins[mask]=min(vals[bit.bit_length()-1],mins[mask^bit])if mask^bit else vals[bit.bit_length()-1]
  allow=[0]*(len(mins))
  terms.append((gi,vals,mins))
 rows.append((terms,b))
scores=[1]*len(rows);visits=pruned=ops=0;t=time.time();limit=300000
stack=[[(1<<(len(g)+1))-1 for g in groups]]
while stack:
 dom=stack.pop();visits+=1
 if visits>limit or time.time()-t>45:break
 changed=True;failed=False
 while changed and not failed:
  changed=False
  for rid,(terms,bound)in enumerate(rows):
   base=sum(mins[dom[g]]for g,v,mins in terms);ops+=len(terms)
   if base>bound:failed=True;scores[rid]+=1;break
   slack=bound-base
   for g,vals,mins in terms:
    if dom[g]&(dom[g]-1)==0:continue
    allow=sum(1<<k for k,v in enumerate(vals)if v<=slack+mins[dom[g]])
    next=dom[g]&allow;ops+=1
    if not next:failed=True;scores[rid]+=1;break
    if next!=dom[g]:dom[g]=next;changed=True
 if failed:pruned+=1;continue
 if all(x&(x-1)==0 for x in dom):print('SAT',dom);break
 wg=[0.]*len(groups)
 for rid,(terms,bound) in enumerate(rows):
  free=[g for g,v,mins in terms if dom[g]&(dom[g]-1)]
  for g in free:wg[g]+=scores[rid]/max(1,len(free))
 chosen=max((i for i,x in enumerate(dom)if x&(x-1)),key=lambda i:wg[i]/dom[i].bit_count())
 vals=[k for k in range(len(groups[chosen])+1)if dom[chosen]>>k&1]
 for k in vals:
  nxt=dom.copy();nxt[chosen]=1<<k;stack.append(nxt)
else:print('UNSAT')
print('nodes',visits,'pruned',pruned,'ops',ops,'seconds',time.time()-t,'remaining',len(stack),'groups',len(groups))
