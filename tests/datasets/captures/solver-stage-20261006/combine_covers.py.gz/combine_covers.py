from pathlib import Path
import subprocess,shutil,json
r=Path.cwd();a=r/'.local/solver-stage-20261006';label='stage1006-cover-rational';source=a/(label+'-source');shutil.copytree(a/'stage1006-canonical-cover-2-source',source);shutil.copy2(a/'stage1006-rational-lp-r1-source/CountLpLearning.java',source/'CountLpLearning.java')
p=subprocess.run(['python','.local/structural-stage-20261004/run.py',label,'--source',str(source),'--filter','lseu','--variations','4']);print(p.returncode)
