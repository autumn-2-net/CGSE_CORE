import copy, hashlib, json, pathlib, random
ROOT = pathlib.Path.cwd()
OUT = ROOT / '.local/solver-stability-review-20261002'
base = json.loads((ROOT / '.local/pruned-search-20261002/counterexample-998.json').read_text())[0]
groups = []
for order in range(6):
    g = copy.deepcopy(base)
    g['id'] = 'counter998-order-' + str(order)
    if order == 1:
        g['catalog']['recipes'].reverse()
        for values in g['catalog']['producers'].values(): values.reverse()
    elif order >= 2:
        rng = random.Random(31000 + order)
        rng.shuffle(g['catalog']['recipes'])
        for values in g['catalog']['producers'].values(): rng.shuffle(values)
    g['requests'] = [{'amount': str(n)} for n in (998, 999, 1000)]
    groups.append(g)
groups += json.loads((ROOT / '.local/pruned-search-20261002/jvm-boundaries.json').read_text())
for g in groups:
    # These fixtures have one output and no cycles/reusable/configuration slots.
    # A forward optimistic supply bound sums all producer upper bounds without
    # subtracting shared consumption. Therefore it cannot remove a feasible plan.
    rs = g['catalog']['recipes']
    supply = {k: int(v) for k, v in g['stock'].items()}
    remaining = list(rs); ordered = []; upper = {}
    produced = {k for r in rs for k in r['outputs']}
    for r in rs:
        assert len(r['outputs']) == 1 and r['slots']
        for s in r['slots']:
            assert not s.get('configuration', False) and not s.get('reusable', False)
            if s['key'] not in produced: supply.setdefault(s['key'], 0)
    while remaining:
        ready = [r for r in remaining if all(s['key'] in supply for s in r['slots'])]
        assert ready, 'not an acyclic fixture'
        # Process all producers of each currently available output together.
        levels = {next(iter(r['outputs'])) for r in ready}
        levels = {k for k in levels if all(r in ready for r in remaining if k in r['outputs'])}
        assert levels
        ready = [r for r in ready if next(iter(r['outputs'])) in levels]
        gains = {}
        for r in ready:
            inputs = {}
            for s in r['slots']: inputs[s['key']] = inputs.get(s['key'], 0) + int(s['amount'])
            n = min(supply[k] // v for k, v in inputs.items())
            upper[r['id']] = str(n)
            for k, v in r['outputs'].items(): gains[k] = gains.get(k, 0) + int(v) * n
            ordered.append(r['id']); remaining.remove(r)
        for k, v in gains.items(): supply[k] = supply.get(k, 0) + v
    assert max(map(int, upper.values())) < 2**45
    g['count_upper'] = upper
    g['topological_order'] = ordered
    g['timeout'] = 5000
    for request in g['requests']: request['cold'] = True
(OUT / 'cases.json').write_text(json.dumps(groups, indent=2), encoding='utf8')
sources = list((ROOT / 'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core').glob('*.java'))
(OUT / 'source-hashes.json').write_text(json.dumps({str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}, indent=2))
print('groups', len(groups), 'requests', sum(len(g['requests']) for g in groups), 'max_count_bound', max(int(n) for g in groups for n in g['count_upper'].values()))
