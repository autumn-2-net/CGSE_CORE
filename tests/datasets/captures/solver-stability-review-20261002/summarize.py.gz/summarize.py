import collections,hashlib,json,pathlib,statistics,subprocess
R=pathlib.Path.cwd();P=R/'.local/solver-stability-review-20261002'
def read(name):return [json.loads(s) for s in (P/name).read_text().splitlines()]
paired=read('paired.jsonl');limited=read('cap-262144/results.jsonl');early=read('cap-early-262144/results.jsonl');views=read('view-sweep.jsonl')
def stats(rows,engine):
    times=[x[engine]['ms'] for x in rows]
    return dict(runs=len(rows),verified=sum(x[engine]['verified'] for x in rows),statuses=dict(collections.Counter(x[engine]['result'] for x in rows)),median_ms=statistics.median(times),minimum_ms=min(times),maximum_ms=max(times))
hashes=json.loads((P/'source-hashes.json').read_text());changed=[name for name,sha in hashes.items() if hashlib.sha256((R/name).read_bytes()).hexdigest()!=sha]
assert not changed,changed
assert len(paired)==132 and all(x[e]['verified'] for x in paired for e in ['cgse','cp_sat','scip'])
assert len(early)==66 and all(x['cgse']['verified'] for x in early)
report={
 'date':'2026-10-02',
 'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'scope':'本轮调查与局部实验；生产源码未变。此前四个核心修复及 build.gradle 本地改动原样保留；未提交或推送。',
 'production_files_unchanged_since_snapshot':len(hashes),
 'method':{
   'inputs':'随机裁剪回归中已知可行的 12 个困难 DAG 目录，加 998 反例的原序、逆序及 4 次固定种子洗牌。洗牌包含配方目录与同级 producer 候选顺序。18 组，66 个数量/顺序组合，各重复两次。',
   'cgse':'从本轮工作区源码重新编译；新建编译器/冷缓存；单线程；5 秒、20,000,000 内部工作单位、128 MiB 内部记账预算；Java heap 2 GiB。',
   'native':'OR-Tools 9.15.6755 CP-SAT；SCIP 10.0.0 / SoPlex 8.0.0。单线程、5 秒求解上限。未设置与 CGSE 等价的原生内存/工作量上限。无最优性目标，OPTIMAL 只表示可行性求解结束。',
   'semantics':'冻结相同库存、目标及所有配方。全部为无环、单输出、无配置/可复用输入的实例。前向乐观供应上界有限且安全，最大次数上界 82779；不是人为裁掉解的试探界。',
   'validation':'三种求解器的每个成功结果均用独立 BigInteger 拓扑顺序库存回放，逐配方检查输入库存非负及最终净新增目标。CGSE 还运行原计划执行验证。',
   'timing_limits':'CGSE 计完整核心规划；原生计模型构造+求解。夹具安全次数上界在计时前生成；独立回放在计时外。原生库加载/JVM 启动不计；5 次目标 1 的预热。没有运行 Minecraft、Forge、机器或全服。',
   'compatibility':'原 JDK 20 自带旧 MSVC 运行库在首次 CP-SAT 调用崩溃，排除该启动失败记录；正式三引擎使用之前已有的隔离 Java 20 review-jre（新版 MSVC 副本），未改系统/JDK/游戏。',
   'exclusions':'catalog-order-only.jsonl 为初次仅洗牌全目录、未洗牌显式 producer 索引的补充实验，不计入正式配方优先级洗牌统计。',
 },
 'baseline':{e:stats(paired,e) for e in ['cgse','cp_sat','scip']},
 'counter_998_family':{e:stats([x for x in paired if x['id'].startswith('counter998')],e) for e in ['cgse','cp_sat','scip']},
 'isolated_ablations':{
   'cap_only':stats(limited,'cgse'),
   'cap_and_early_count_scout':stats(early,'cgse'),
   'changes':'仅本地类覆盖：CountDomainSearch 的四处 65536 局部上限表达式改为 262144；第二个实验另把 GraphPlanningWork 中昂贵数量检查前的次数搜索准入从 hasLargeChoices 放宽至 readyForHeavyAnalysis，保留次数尝试 524288 额度和原前置分析回退。没有加入新的求解算法。',
   'meaning':'验证调度与局部额度的因果贡献，不是推荐直接发布两个常量替换。样本均可行且无环，未覆盖负例/大循环；只改上限时一个接近期限的案例超过 5 秒，取消时间上限后的定工作量复测两边都能解，不能把该一次超时当成确定的逻辑退化。',
 },
 'root_cause_evidence':[
   {'finding':'有用的局部整数搜索被固定额度截断后，其活动状态被销毁；其他搜索获得大量后续预算。','evidence':'CountDomainSearch 宽域走 CountLcg，上限 65536；998 反例的相同模型单独 LCG 在约 170681 工作单位完成；完整流程只记录 count_cdcl=65537。直接 LCG 的四次原始/约简试验均回放有效。','code':['CountDomainSearch.java:50','CountLcg.java:153','CountDomainSearch.java:122']},
   {'finding':'昂贵前置数量分析压在便宜可行性搜索之前。','evidence':'分阶段计时中 counter998 原流程第二轮 QuantityAnalysis 阶段约 1636ms，扩大 LCG 配额后仍为 1526ms，而次数阶段降至约 49ms。将已有次数搜索前移的局部实验把 66 案例中位数降到约 45ms。','code':['GraphPlanningWork.java:157','GraphPlanningWork.java:379','QuantityAnalysis.java:186']},
   {'finding':'统一 check 计数不能代表同等成本；不同基础操作耗时差异与局部算法硬上限共同决定预算。','evidence':'PlanningBudget.check 每次统一加一；LCG 字面/行扫描与 BigInteger 有理数消元均使用此入口。倍率本身不能修复提前截断、状态丢弃或前置分析顺序。','code':['PlanningBudget.java:106','CountLcg.java:401','ExactLinearProgram.java']},
   {'finding':'顺序变动仍会明显改变预算消耗，即使本次修复后结果均成功。','evidence':'998 家族原序约 349.8 万工作、29.6MiB；逆序约 959.2 万工作、73.6MiB；第 5 组洗牌约 95.5 万工作、6.7MiB。数学实例等价，有限预算搜索成本不等价。'},
   {'finding':'模型恢复已有，通用多视图选择尚未统一。','evidence':'CountReduction.expand 保存仿射恢复；CountMapping 映射行/冲突；CountRecovery 将宏展开并保留原域；CountRepairPortfolio 比较加割前后的松弛点。普通 CountDomainSearch 默认仍接约简 rows，恢复答案不自动使每个算法能选择原始模型。','code':['CountReduction.java','CountMapping.java','CountRecovery.java:248','CountRepairPortfolio.java','IntegerCountBranch.java:637']}
 ],
 'view_experiment':{
   'cases':len(views),
   'both_solved':sum(x['original']['verified'] and x['reduced']['verified'] for x in views),
   'only_original':sum(x['original']['verified'] and not x['reduced']['verified'] for x in views),
   'only_reduced':sum(not x['original']['verified'] and x['reduced']['verified'] for x in views),
   'neither_within_local_limit':sum(not x['original']['verified'] and not x['reduced']['verified'] for x in views),
   'boundary':'原始/约简都直接使用现有 LCG，局部 2,000,000 工作上限；包含各自构造成本。没有找到原始能解但约简不能解的当前反例，不能宣称这批失败由压缩错误导致。'
 },
 'primary_sources':[
   {'url':'https://github.com/google/or-tools/blob/stable/ortools/sat/sat_solver.cc','fact':'deterministic_time 按基本操作加权，权重包括 1、2、4、8、20，估计操作复杂度；并非所有操作等价。'},
   {'url':'https://github.com/google/or-tools/blob/stable/ortools/sat/subsolver.cc','fact':'按子求解器的选择分数安排任务，平衡实时时间或确定性时间。'},
   {'url':'https://github.com/google/or-tools/blob/stable/ortools/sat/subsolver.h','fact':'选择分数纳入已分配任务、成本和在途任务；数据少时抑制同类大量并发。'},
   {'url':'https://github.com/google/or-tools/blob/stable/ortools/sat/cp_model_lns.cc','fact':'邻域选择使用 UCB 及单位确定性时间目标改善；这是已有解之后的 LNS 机制，不能原样当作寻找第一个解的奖励。'},
   {'url':'https://github.com/scipopt/scip/blob/master/src/scip/heur_rins.c','fact':'RINS 根据总搜索节点、历史成功/调用比、启动成本与已用节点分配本次子问题额度。'},
   {'url':'https://github.com/scipopt/scip/blob/master/src/scip/heur_scheduler.c','fact':'另有自适应 LNS/diving 调度插件，但当前源码默认 HEUR_FREQ=-1；不能把默认对照性能归功于该插件。'},
   {'url':'https://github.com/google/or-tools/blob/stable/ortools/sat/cp_model_presolve.h','fact':'presolve 保留 mapping model 及 postsolve_mapping；连接原始与约简变量，恢复解。'},
   {'url':'https://github.com/google/or-tools/blob/stable/ortools/sat/cp_model_postsolve.h','fact':'按映射约束逆序恢复原变量；本文件不是默认并行运行原始模型和约简模型的证明。'}
 ],
 'recommended_design':[
   '把取消/墙钟/内存硬限制与工作成本记账分离；按操作类别、稀疏项数与大整数位宽估算成本，用确定性定点权重保留可复现性，实测耗时用于校准。',
   '可行性优先的小额侦察；公平发放时间片，局部暂停保留 trail/学习/前沿；有进展续算，长期无收益降频。优先级可借鉴 SCIP，不要将历史失败学成不可行证明。',
   '保留不可变原始目录/模型与变换记录，按需提供原始、轻度约简和结构化压缩视图；避免每个策略无条件复制全模型。',
   '恢复映射记录配方计数、仿射等式、宏程序、初始需求/种子/返还及适用假设；明确等价、松弛、限制域三种变换。',
   '成功候选统一恢复并按原配方验证；只有作用域成立、可验证的冲突可跨视图共享；局部 UNKNOWN、超时和受限宏视图无解都不能禁用整个原模型。',
   '视图消融与调度修改必须覆盖循环启动、纯无损环、线性多来源、同级顺序洗牌、数量邻界、目录裁剪/恢复、无解证书与冷/热缓存后再并入生产。'
 ],
 'artifacts':['paired.jsonl','kernel.jsonl','phase-current.jsonl','phase-cap-262144.jsonl','cap-262144/results.jsonl','cap-early-262144/results.jsonl','view-sweep.jsonl','source-hashes.json'],
 'build_gradle_sha256':hashlib.sha256((R/'build.gradle').read_bytes()).hexdigest()
}
(P/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'baseline':report['baseline'],'ablation':report['isolated_ablations']['cap_and_early_count_scout'],'views':report['view_experiment'],'unchanged_sources':len(hashes),'build_gradle_sha256':report['build_gradle_sha256']},ensure_ascii=False))
