import os, pathlib, subprocess, sys
R=pathlib.Path.cwd(); P=R/'.local/solver-stability-review-20261002'
J=pathlib.Path(r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin')
jars=list((R/'.local/cp-sat-repro-20260925/windows-jars').glob('*.jar'))
jars.append(R/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar')
cp=os.pathsep.join(map(str,[P/'classes',*jars]))
if len(sys.argv)==1 or sys.argv[1]=='compile':
    (P/'classes').mkdir(exist_ok=True)
    sources=list((R/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core').glob('*.java'))
    sources += [R/'.local/quantity-regression-20261002/QuantitySweep.java',P/'StabilityProbe.java']
    args=['--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(P/'classes'),*map(str,sources)]
    (P/'javac.args').write_text('\n'.join('"'+s.replace('\\','/')+'"' for s in args))
    subprocess.run([str(J/'javac.exe'),'@'+str(P/'javac.args')],check=True)
    print('Compiled current production core with local probes')
else:
    mode=sys.argv[1]
    if mode=='kernel':
        subprocess.run([str(J/'javac.exe'),'-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(P/'classes'),str(P/'KernelProbe.java')],check=True)
    input_file = P/('cases.json' if mode=='paired' else 'profile-cases.json')
    with (P/(mode+'.log')).open('w',encoding='utf8') as log:
        runtime=R/'.local/cp-sat-repro-20260925/review-jre/bin/java.exe'
        main='KernelProbe' if mode=='kernel' else 'StabilityProbe'
        subprocess.run([str(runtime),'-ea','-Xmx2G','-XX:ErrorFile='+str(P/'hs_err_pid%p.log'),'-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.'+main,str(input_file),str(P/(mode+'.jsonl')),'2' if mode=='paired' else '1',mode],stdout=log,stderr=subprocess.STDOUT,check=True)
    print('Finished',mode)
