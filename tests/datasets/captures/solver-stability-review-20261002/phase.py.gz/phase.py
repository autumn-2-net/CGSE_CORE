import json,os,pathlib,subprocess
R=pathlib.Path.cwd();P=R/'.local/solver-stability-review-20261002'
J=pathlib.Path(r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin')
jars=list((R/'.local/cp-sat-repro-20260925/windows-jars').glob('*.jar'))
jars.append(R/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar')
cp=os.pathsep.join(map(str,[P/'classes',*jars]))
gs=json.loads((P/'cases.json').read_text());selected=[]
for case_id,amount in [('counter998-order-0',998),('cut-dag-374-90',9998)]:
    g=next(g for g in gs if g['id']==case_id);g['requests']=[{'amount':str(amount)}];selected.append(g)
(P/'phase-cases.json').write_text(json.dumps(selected))
subprocess.run([str(J/'javac.exe'),'--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(P/'classes'),str(P/'PhaseProbe.java')],check=True)
runtime=R/'.local/cp-sat-repro-20260925/review-jre/bin/java.exe'
for mode in ['current','cap-262144']:
    classpath=cp if mode=='current' else str(P/mode/'classes')+os.pathsep+cp
    with (P/('phase-'+mode+'.log')).open('w',encoding='utf8') as log:
        subprocess.run([str(runtime),'-ea','-Xmx2G','-cp',classpath,'org.gtlcore.gtlcore.integration.ae2.graph.core.PhaseProbe',str(P/'phase-cases.json'),str(P/('phase-'+mode+'.jsonl'))],stdout=log,stderr=subprocess.STDOUT,check=True)
    print('Phase trace finished',mode,flush=True)
