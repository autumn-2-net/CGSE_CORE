import os,pathlib,subprocess
R=pathlib.Path.cwd();P=R/'.local/solver-stability-review-20261002'
J=pathlib.Path(r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin')
jars=list((R/'.local/cp-sat-repro-20260925/windows-jars').glob('*.jar'))
jars.append(R/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar')
cp=os.pathsep.join(map(str,[P/'classes',*jars]))
subprocess.run([str(J/'javac.exe'),'--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(P/'classes'),str(P/'ViewSweep.java')],check=True)
with (P/'view-sweep.log').open('w',encoding='utf8') as log:
    subprocess.run([str(J/'java.exe'),'-ea','-Xmx2G','-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.ViewSweep',str(P/'cases.json'),str(P/'view-sweep.jsonl')],stdout=log,stderr=subprocess.STDOUT,check=True)
print('Finished 66 original/reduced comparisons')
