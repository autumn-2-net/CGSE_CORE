import json,os,pathlib,subprocess,sys
R=pathlib.Path.cwd();P=R/'.local/solver-stability-review-20261002'
J=pathlib.Path(r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin')
variant=sys.argv[1] if len(sys.argv)>1 else '262144'
V=P/('cap-'+variant);V.mkdir(exist_ok=True);(V/'classes').mkdir(exist_ok=True)
cap=variant.removeprefix('early-')
source=(R/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core/CountDomainSearch.java').read_text()
assert source.count('Math.min(65536, allowance)')==4
# A diagnostic ablation only: four local ceiling expressions, no product edits.
source=source.replace('Math.min(65536, allowance)','Math.min('+cap+', allowance)')
(V/'CountDomainSearch.java').write_text(source)
jars=list((R/'.local/cp-sat-repro-20260925/windows-jars').glob('*.jar'))
jars.append(R/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar')
cp=os.pathsep.join(map(str,[V/'classes',P/'classes',*jars]))
sources=[V/'CountDomainSearch.java']
if variant.startswith('early-'):
    planning=(R/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core/GraphPlanningWork.java').read_text()
    assert planning.count('!countAttempted && quantities.hasLargeChoices()')==1
    planning=planning.replace('!countAttempted && quantities.hasLargeChoices()','!countAttempted && quantities.readyForHeavyAnalysis()')
    (V/'GraphPlanningWork.java').write_text(planning)
    sources.append(V/'GraphPlanningWork.java')
subprocess.run([str(J/'javac.exe'),'--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(V/'classes'),*map(str,sources)],check=True)
runtime=R/'.local/cp-sat-repro-20260925/review-jre/bin/java.exe'
with (V/'run.log').open('w',encoding='utf8') as log:
    subprocess.run([str(runtime),'-ea','-Xmx2G','-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.StabilityProbe',str(P/'cases.json'),str(V/'results.jsonl'),'1','paired'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('Finished cap-only ablation',variant)
