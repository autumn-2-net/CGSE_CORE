from pathlib import Path
import zipfile,json
root=Path('D:/java_proj/gtl_core/core/.gradle-user-home/caches/modules-2/files-2.1')
projects=[('curse.maven','applied-energistics-2-223794'),('curse.maven','ex-pattern-provider-892005'),('curse.maven','applied-energistics-2-wireless-terminals-459929'),('com.gregtechceu.gtceu','gtceu-1.20.1')]
files=[]
for group,project in projects:
    files.extend((root/group/project).glob('**/*.jar'))
files.extend([Path('libs/gtmthings-1.3.5.b.jar'),Path('libs/gtceu-1.20.1-1.4.4.jar'),Path('libs/wildcard_pattern-0.1.2-gtl.jar')])
files.extend(Path('.local/runtime-mods').glob('*.jar'))
targets=[b'appeng/crafting/execution/CraftingCpuLogic',b'appeng/crafting/CraftingCalculation',b'appeng/me/service/CraftingService',b'appeng/helpers/patternprovider/PatternProviderLogic']
for path in files:
    if 'sources' in path.name: continue
    with zipfile.ZipFile(path) as jar:
        print('\nJAR',path.name)
        if 'applied-energistics-2-223794' in path.name:
            print(jar.read('META-INF/mods.toml').decode())
        for name in jar.namelist():
            if name.endswith('.json') and 'mixin' in name.lower():
                try: config=json.loads(jar.read(name))
                except Exception: continue
                package=config.get('package','').replace('.','/')
                for cl in config.get('mixins',[])+config.get('client',[])+config.get('server',[]):
                    entry=package+'/'+cl.replace('.','/')+'.class'
                    if entry not in jar.namelist(): continue
                    data=jar.read(entry)
                    matches=[t.decode() for t in targets if t in data]
                    if matches: print('MIXIN',entry,','.join(matches))
