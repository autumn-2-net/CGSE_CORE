from pathlib import Path
import hashlib, io, json, urllib.request, zipfile

area = Path(__file__).resolve().parent
def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'GTLCore-local-repro/1.0'})
    with urllib.request.urlopen(req, timeout=30) as response:
        return response.read()

url = 'https://mediafilez.forgecdn.net/files/7190/965/mae2-2.0.0-beta.f.jar'
data = get(url)
with zipfile.ZipFile(io.BytesIO(data)) as jar:
    assert jar.testzip() is None
    assert 'version = "2.0.0-beta.f"' in jar.read('META-INF/mods.toml').decode('utf8')
digest = hashlib.sha256(data).hexdigest()
(area / 'mae2-2.0.0-beta.f.jar').write_bytes(data)
(area / 'mae2-download.json').write_text(json.dumps({'source': 'https://www.curseforge.com/minecraft/mc-mods/modern-ae2-additions/files/7190965', 'url': url, 'sha256': digest}, indent=2), 'utf8')
print('Verified version and ZIP CRCs: mae2-2.0.0-beta.f.jar', 'bytes', len(data), 'SHA-256', digest)
