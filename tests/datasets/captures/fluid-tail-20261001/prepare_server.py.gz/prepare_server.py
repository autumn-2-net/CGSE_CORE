from pathlib import Path
import gzip, hashlib, json, os, re, shutil, zipfile

root = Path.cwd().resolve()
area = root / '.local/fluid-tail-20261001'
baseline = root / '.local/pattern-buffer-review-20260930/server'
server = area / 'server'
assert server.resolve().is_relative_to(root)
server.mkdir(exist_ok=True)
def link_copy(src, dest):
    try:
        os.link(src, dest)
    except OSError:
        shutil.copy2(src, dest)
    return dest

if not (server / 'libraries').exists():
    shutil.copytree(baseline / 'libraries', server / 'libraries', copy_function=link_copy)
for folder in ('config', 'defaultconfigs', 'kubejs'):
    if not (server / folder).exists():
        shutil.copytree(baseline / folder, server / folder,
                        ignore=shutil.ignore_patterns('zz_local_*', '*.log'))
if not (server / 'world').exists():
    shutil.copytree(area / 'world-original', server / 'world')

mods = server / 'mods'
mods.mkdir(exist_ok=True)
excluded = ('gtlcore-', 'gtladditions-', 'mae2-', 'kubejs-forge-', 'kotlinforforge-')
for jar in (baseline / 'mods').glob('*.jar'):
    if jar.name.startswith(excluded):
        continue
    dest = mods / jar.name
    if not dest.exists(): link_copy(jar, dest)
extras = [
    root / 'build/libs/gtlcore-1.2.3.2-fix3.jar',
    Path(r'C:\Users\autumn\Downloads\gtladditions-3.2.8Custom_SubSpace-fix2.jar'),
    area / 'mae2-2.0.0-beta.f.jar',
    Path(r'C:\Users\autumn\Downloads\GTLL\GTMAdvancedHatch-0.1.9-hotfix2.jar'),
    Path(r'C:\Users\autumn\Downloads\server-1.1.5\mods\kubejs-forge-2001.6.5-build.16.jar'),
    Path(r'C:\Users\autumn\Downloads\server-1.1.5\mods\kotlinforforge-4.11.0-all.jar'),
]
for jar in extras:
    shutil.copy2(jar, mods / jar.name)
shutil.copy2(root / 'build/libs/gtlcore-1.2.3.2-fix3.jar', area / 'baseline-gtlcore.jar')
manifest = []
for jar in mods.glob('*.jar'):
    with zipfile.ZipFile(jar) as zipped:
        toml = zipped.read('META-INF/mods.toml').decode('utf8', errors='replace') if 'META-INF/mods.toml' in zipped.namelist() else ''
    manifest.append({'file': jar.name, 'sha256': hashlib.sha256(jar.read_bytes()).hexdigest(),
                     'mod_ids': re.findall(r'\[\[mods\]\][\s\S]*?modId\s*=\s*[\"\']([^\"\']+)', toml)})
(area / 'runtime-mods.json').write_text(json.dumps(manifest, indent=2), 'utf8')

props = (baseline / 'server.properties').read_text('utf8')
for key, value in {'server-ip': '127.0.0.1', 'server-port': '25577', 'level-name': 'world',
                   'online-mode': 'false', 'enable-rcon': 'false', 'enable-query': 'false',
                   'view-distance': '3', 'simulation-distance': '3', 'max-tick-time': '-1'}.items():
    props = re.sub(r'(?m)^' + re.escape(key) + '=.*$', key + '=' + value, props)
(server / 'server.properties').write_text(props, 'utf8')
(server / 'eula.txt').write_text('eula=true\n', 'utf8')
runner = (root / '.local/pattern-buffer-review-20260930/live.py').read_text('utf8')
runner = runner.replace("area=root/'.local/pattern-buffer-review-20260930'", "area=root/'.local/fluid-tail-20261001'")
runner = runner.replace('25576', '25577').replace('[Buffer Live]', '[Fluid Tail]')
runner = runner.replace("['forceload add 80 224 160 272']", "['execute in kubejs:flat run forceload add 16 -32 80 64', 'execute in kubejs:flat run fluidinspect', 'fluidmath']")
(area / 'live.py').write_text(runner, 'utf8')
print('Prepared isolated saved world with matching SubSpace add, AE2, MAE2, GTCEu, KubeJS, Kotlin and Forge versions.')
