from pathlib import Path
import os, socket, subprocess, threading, time, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

root=Path.cwd().resolve()
area=root/'.local/fluid-tail-20261001'
server=area/'server'
assert server.resolve().is_relative_to(root)
with socket.socket() as s:
    assert s.connect_ex(('127.0.0.1',25577))!=0, 'Test port occupied'
commands=area/'commands.txt'
commands.write_text('',encoding='utf8')
log=area/(sys.argv[1] if len(sys.argv)>1 else 'live-forge.log')
ready=threading.Event()
java=Path(r'C:\Users\autumn\AppData\Roaming\.hmcl\java\windows-x86_64\mojang-java-runtime-delta\bin\java.exe')
out=log.open('w',encoding='utf8')
p=subprocess.Popen([str(java),'-Xms512M','-Xmx5G','-Dfile.encoding=UTF-8',
                    '-Djava.io.tmpdir='+str(root/'.local/tmp/server'),
                    '@libraries/net/minecraftforge/forge/1.20.1-47.4.16/win_args.txt','nogui'],
                   cwd=server,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                   text=True,encoding='utf8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
print('Isolated server PID',p.pid,flush=True)
def read():
    for line in p.stdout:
        out.write(line);out.flush()
        if 'Done (' in line:ready.set()
        if any(k in line for k in ['[Fluid Tail]','Done (','Mod loading error','Exception in thread']):print(line.rstrip(),flush=True)
t=threading.Thread(target=read,daemon=True);t.start()
try:
    started=time.monotonic()
    while not ready.wait(1):
        if p.poll() is not None:raise RuntimeError('Server exited '+str(p.returncode))
        if time.monotonic()-started>360:raise TimeoutError('Server startup')
    for command in ['execute in kubejs:flat run forceload add 16 -32 80 64', 'execute in kubejs:flat run fluidinspect', 'fluidmath']:
        p.stdin.write(command+'\n');p.stdin.flush()
    offset=0
    while p.poll() is None and time.monotonic()-started<1800:
        lines=commands.read_text('utf-8-sig').splitlines()
        for command in lines[offset:]:
            if command.strip():
                print('COMMAND',command,flush=True);p.stdin.write(command+'\n');p.stdin.flush()
        offset=len(lines)
        time.sleep(.5)
finally:
    if p.poll() is None:
        p.stdin.write('stop\n');p.stdin.flush()
        try:p.wait(timeout=45)
        except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=15)
    t.join(timeout=5);out.close()
    print('Forge exit',p.returncode,flush=True)
