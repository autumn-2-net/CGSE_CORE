from pathlib import Path
import subprocess, zipfile
root=Path.cwd().resolve();area=root/'.local/fluid-tail-20261001';server=area/'server'
classes=area/'probe-classes';classes.mkdir(exist_ok=True)
paths=list((server/'mods').glob('*.jar'))+list((server/'libraries').rglob('*.jar'))
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',';'.join(str(p).replace('\\','/') for p in paths),'-d',str(classes),str(area/'FluidTailProbe.java')]
(area/'probe-javac.args').write_text('\n'.join('"'+a.replace('\\','/')+'"' for a in args),'utf8')
subprocess.run([r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin\javac.exe','@'+str(area/'probe-javac.args')],check=True)
with zipfile.ZipFile(server/'mods/local-fluid-probe.jar','w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('META-INF/mods.toml','modLoader="javafml"\nloaderVersion="[47,)"\nlicense="All Rights Reserved"\n[[mods]]\nmodId="localfluidprobe"\nversion="0.0.0"\ndisplayName="Local Fluid Tail Probe"\n')
    for p in classes.rglob('*.class'):z.write(p,str(p.relative_to(classes)).replace('\\','/'))
print('Compiled local native fluid probe')
