from pathlib import Path
from zipfile import ZipFile
from collections import Counter
import gzip, hashlib, json, shutil, sys, zlib

sys.stdout.reconfigure(encoding='utf8')
root = Path.cwd().resolve()
area = root / '.local/fluid-tail-20261001'
archive = next(Path(r'C:\Users\autumn\Downloads').glob('10-1*.zip'))
world = area / 'world-original'
world.mkdir(parents=True, exist_ok=True)
with ZipFile(archive) as zipped:
    for entry in zipped.infolist():
        assert entry.filename.startswith('world/')
        name = entry.filename[len('world/'):]
        if not name or name == 'session.lock':
            continue
        dest = (world / name).resolve()
        assert dest.is_relative_to(world.resolve())
        if entry.is_dir():
            dest.mkdir(parents=True, exist_ok=True)
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            with zipped.open(entry) as src, dest.open('wb') as out:
                shutil.copyfileobj(src, out)

scope = {'__file__': str(root / '.local/save-cycle-fixture/inspect_save.py')}
exec((root / '.local/save-cycle-fixture/inspect_save.py').read_text('utf8').split('world = BASE/')[0], scope)
NBT = scope['NBT']
level = NBT(gzip.decompress((world / 'level.dat').read_bytes())).root()['Data']
print('ARCHIVE sha256', hashlib.sha256(archive.read_bytes()).hexdigest())
print('WORLD', level.get('LevelName'), 'PLAYER', level.get('Player', {}).get('Pos'), 'DIMENSION', level.get('Player', {}).get('Dimension'))
entities = []
for region in world.rglob('*.mca'):
    if region.parent.name != 'region':
        continue
    blob = region.read_bytes()
    for index in range(1024):
        offset = int.from_bytes(blob[index*4:index*4+3], 'big') * 4096
        if not offset:
            continue
        length = int.from_bytes(blob[offset:offset+4], 'big')
        method = blob[offset+4]
        data = blob[offset+5:offset+4+length]
        if method == 2:
            data = zlib.decompress(data)
        elif method == 1:
            data = gzip.decompress(data)
        elif method != 3:
            raise ValueError((region, method))
        for entry in NBT(data).root().get('block_entities', []):
            entities.append({'region': str(region.relative_to(world)), 'nbt': entry})

(area / 'block-entities.json').write_text(json.dumps(entities, ensure_ascii=False, indent=2), 'utf8')
print('ENTITIES', len(entities), Counter(e['nbt'].get('id') for e in entities).most_common(25))
for entry in entities:
    n = entry['nbt']
    kind = n.get('id', '')
    if any(s in kind for s in ('brewing', 'pattern_buffer', 'crafting_storage', 'crafting_unit', 'crafting_cpu')):
        print('BLOCK',entry['region'],kind,tuple(n.get(k) for k in ('x','y','z')), 'fields', ','.join(n.keys()))
        if 'brewing' in kind:
            print('BREWING', json.dumps(n, ensure_ascii=False)[:5000])
print('SAVED', area / 'block-entities.json')
