import json
from pathlib import Path
import subprocess

def git(*args):
    return subprocess.check_output(['git', *args]).decode('utf-8')

def parse(raw):
    pairs = json.loads(raw, object_pairs_hook=list)
    assert len(pairs) == len(dict(pairs)), 'Duplicate translation key'
    return dict(pairs)

base = git('merge-base', 'HEAD', 'origin/gtl-1431-skyblock').strip()
missing = object()
for lang in ['zh_cn', 'en_us']:
    path = 'src/main/resources/assets/gtlcore/lang/' + lang + '.json'
    ancestor = parse(git('show', base + ':' + path))
    ours = parse(git('show', 'HEAD:' + path))
    theirs = parse(git('show', 'origin/gtl-1431-skyblock:' + path))
    merged = parse(Path(path).read_text(encoding='utf-8'))
    for key in set(ancestor) | set(ours) | set(theirs):
        before = ancestor.get(key, missing)
        old = ours.get(key, missing)
        upstream = theirs.get(key, missing)
        if upstream != before and old != before:
            assert upstream == old, 'Unreviewed shared key edit: ' + key
        expected = upstream if upstream != before else old
        assert merged.get(key, missing) == expected, 'Lost translation: ' + key
    assert '1024' in merged['config.gtlcore.option.ae2GraphPlannerMemoryMiB.comment']
    print(lang, 'three-way key/value preservation and duplicate check passed:', len(merged), 'keys')
