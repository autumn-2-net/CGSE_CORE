import concurrent.futures
import json
import os
import pathlib
import subprocess

ROOT = pathlib.Path.cwd().resolve()
P = ROOT / '.local/pruned-search-20261002'
java = r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin\java.exe'
cp = os.pathsep.join(str(ROOT / p) for p in ['.local/pruned-search-20261002/final-classes',
    '.local/quantity-regression-20261002/classes', 'build/classes/java/main',
    '.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'])
jobs = [('dag-cuts', P / 'dag-cuts.json'), ('near-998', P / 'near-998.json')]
jobs += [(f'archive-cuts-{i}', P / f'archive-cuts-{i}.json') for i in range(5)]
jobs += [(name, P.parent / 'linear-search-20261002' / f'{name}.json')
         for name in ['all-linear', 'random-dag', 'hard-boundaries', 'prior-cases']]
jobs += [(f'jvm-{i}', P / 'jvm-boundaries.json') for i in range(5)]

def run(job):
    name, source = job
    with (P / f'fixed-{name}.log').open('w', encoding='utf8') as log:
        subprocess.run([java, '-ea', '-Xmx2G', '-cp', cp,
                        'org.gtlcore.gtlcore.integration.ae2.graph.core.QuantitySweep',
                        str(ROOT / '.local/miracle-cycle-20261002/audit-original-catalog.json'), str(source),
                        str(P / f'fixed-{name}.jsonl'), '1'], stdout=log, stderr=subprocess.STDOUT, check=True)
    rows = [json.loads(s) for s in (P / f'fixed-{name}.jsonl').read_text('utf8').splitlines()]
    failed = [r for r in rows if r['result'] == 'ERROR' or 'known_feasible_max' in r
              and int(r['request']['amount']) <= int(r['known_feasible_max']) and not r['feasible']]
    print('Finished', name, 'requests', len(rows), 'funded failures', len(failed), flush=True)
    return dict(name=name, requests=len(rows), failures=failed)

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    result = list(pool.map(run, jobs))
(P / 'fixed-regressions.json').write_text(json.dumps(result, indent=2), 'utf8')
if any(r['failures'] for r in result):
    raise SystemExit('Regression failed; see fixed-regressions.json')
