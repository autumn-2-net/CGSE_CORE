import concurrent.futures
import json
import os
import pathlib
import subprocess

ROOT = pathlib.Path.cwd().resolve()
P = ROOT / '.local/pruned-search-20261002'
spec = json.loads((P / 'archive-shards.json').read_text('utf8'))
java = r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin\java.exe'
cp = os.pathsep.join(str(ROOT / p) for p in ['.local/quantity-regression-20261002/classes', 'build/classes/java/main',
    '.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'])

def run(i):
    with (P / f'archive-cuts-{i}.log').open('w', encoding='utf8') as log:
        subprocess.run([java, '-ea', '-Xmx2G', '-cp', cp,
                        'org.gtlcore.gtlcore.integration.ae2.graph.core.QuantitySweep',
                        str(ROOT / '.local/miracle-cycle-20261002/audit-original-catalog.json'),
                        str(P / f'archive-cuts-{i}.json'), str(P / f'archive-cuts-{i}.jsonl'), '1'],
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    print('Archive shard finished', i, flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run, range(spec['shards'])))
