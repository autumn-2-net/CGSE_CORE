import collections
import json
import pathlib
import random
import shutil

P = pathlib.Path(__file__).resolve().parent
ROOT = P.parent.parent
OLD = P.parent / 'linear-search-20261002'
SAVE = P.parent / 'miracle-cycle-20261002'

def read(path):
    return json.loads(path.read_text(encoding='utf8'))

def write(name, value):
    (P / name).write_text(json.dumps(value, separators=(',', ':')), encoding='utf8')

# Independent exact-integer DAG witnesses; cuts keep every good producer.
original = read(OLD / 'random-dag.json')
groups = []
for source in original:
    if not source['id'].endswith('-order-0'):
        continue
    sample = int(source['id'].split('-')[1])
    for rate in (0.0, 0.1, 0.35, 0.65, 0.9):
        seed = 728194 + sample * 151 + int(rate * 100)
        rng = random.Random(seed)
        chosen = {r['id'] for r in source['catalog']['recipes'] if r['id'].startswith('good-') or rng.random() < rate}
        recipes = [r for r in source['catalog']['recipes'] if r['id'] in chosen]
        rng.shuffle(recipes)
        producers = {k: [r for r in values if r in chosen] for k, values in source['catalog']['producers'].items()}
        for values in producers.values():
            rng.shuffle(values)
        maximum = int(source['known_feasible_max'])
        requests = [dict(amount=str(n), phase='pinned-witness', cold=True) for n in sorted({1, maximum, max(1, maximum - 1)})]
        group = dict(source, id=f'cut-dag-{sample}-{int(rate*100)}', kind='pinned-exact-dag',
                     requests=requests, cut_seed=seed, retained_alternatives=rate,
                     catalog=dict(recipes=recipes, producers=producers))
        groups.append(group)
write('dag-cuts.json', groups)

# Native pair comparison uses the real registered pattern decoder. Select linear,
# SCC and deep requests before results are known; each pair sees identical inputs.
funded = read(OLD / 'all-linear.json')
rng = random.Random(810702)
ranked = sorted(funded, key=lambda g: len(g['catalog']['recipes']), reverse=True)
selected = ranked[:16] + rng.sample(ranked[16:], 48)
cases = []
for i, g in enumerate(selected):
    maximum = int(g['known_feasible_max'])
    for amount in sorted({1, maximum}):
        cases.append(dict(id=g['id']+'-'+str(amount), kind='linear', target=g['target'], amount=str(amount),
                          stock=g['stock'], verify_cache=i in (0, 17, 33)))
structure = read(SAVE / 'audit-structure.json')
for i, cycle in enumerate(structure['cycles']):
    targets = cycle['target_keys']
    target = targets[i % len(targets)]
    for amount in ((144, 2000000) if 'ae2:f' in target else (1, 1000)):
        cases.append(dict(id=f'cycle-{i}-{amount}', kind='cycle', target=target, amount=str(amount), verify_cache=i in (0, 12, 24)))
for i, g in enumerate(read(P.parent / 'quantity-regression-20261002/deep-native.json')):
    if i % 3 == 0:
        cases.append(dict(id=g['id']+'-1', kind='deep', target=g['target'], amount='1', stock=g['stock'], verify_cache=i in (0, 12)))
orders = [dict(name='full-baseline', seed=0, retain=1),
          dict(name='random-75', seed=719731, retain=.75),
          dict(name='random-50', seed=821419, retain=.5),
          dict(name='random-25', seed=193427, retain=.25),
          dict(name='random-10', seed=273819, retain=.1),
          dict(name='empty', seed=0, retain=0),
          dict(name='full-restored', seed=0, retain=1),
          dict(name='pinned-25', seed=153731, retain=.25, pin=True),
          dict(name='pinned-only', seed=319171, retain=0, pin=True),
          dict(name='full-reversed', seed=-1, retain=1),
          dict(name='full-shuffled', seed=414713, retain=1),
          dict(name='full-restored-again', seed=0, retain=1)]
write('native-spec.json', dict(orders=orders, cases=cases))

for name in ('NetworkAudit.java', 'NativeDriver.java', 'RandomOrderAudit.java'):
    text = (OLD / name).read_text('utf8').replace('local.linearaudit', 'local.prunedaudit')
    text = text.replace('local/linear-search-20261002', 'local/pruned-search-20261002').replace('local/ae-audit', 'local/pruned-search-20261002')
    text = text.replace('locallinearaudit', 'localprunedaudit').replace('linear_search_audit', 'pruned_search_audit')
    text = text.replace('local.linear.spec', 'local.pruned.spec').replace('[Linear Search]', '[Pruned Search]')
    text = text.replace('paired-stable.jsonl', 'paired.jsonl').replace('target-closure.zip', 'compatible-source.zip')
    (P / name).write_text(text, 'utf8')
shutil.copy2(SAVE / 'server/logs/ae-dump/ae-dump-muqjcnc6-60.zip', P / 'compatible-source.zip')
text = (OLD / 'run_native.py').read_text('utf8')
for a, b in [('linear-search-20261002', 'pruned-search-20261002'), ('locallinearaudit', 'localprunedaudit'),
             ('local-linear-search-probe', 'local-pruned-search-probe'), ('linear_search_audit', 'pruned_search_audit'),
             ('local.linear.spec', 'local.pruned.spec'), ('[Linear Search]', '[Pruned Search]')]:
    text = text.replace(a, b)
text = text.replace('>1800', '>3600')
(P / 'run_native.py').write_text(text, 'utf8')
print('Prepared DAG groups', len(groups), 'requests', sum(len(g['requests']) for g in groups),
      'native cases', len(cases), 'profiles', len(orders))
