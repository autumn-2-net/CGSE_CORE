import collections
import json
import pathlib
import random
import sys

P = pathlib.Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text('utf8'))

def write(name, value):
    (P / name).write_text(json.dumps(value, separators=(',', ':')), 'utf8')

if len(sys.argv) == 1:
    candidates = read(P.parent / 'linear-search-20261002/all-linear.json')
    ranked = sorted(candidates, key=lambda g: len(g['catalog']['recipes']), reverse=True)
    chosen = ranked[:64] + random.Random(812619).sample(ranked[64:], 128)
    chosen += read(P.parent / 'quantity-regression-20261002/deep-native.json')
    groups = []
    for g in chosen:
        amount = int(g['known_feasible_max'])
        groups.append(dict(g, requests=[dict(amount=str(amount), phase='baseline')], dump=True, fallback=False))
    global_catalog = read(P.parent / 'miracle-cycle-20261002/audit-original-catalog.json')
    by_id = {r['id']: r for r in global_catalog['recipes']}
    def closure(target):
        pending = [target]; seen = set(); included = set(); producers = {}
        while pending:
            key = pending.pop()
            if key in seen: continue
            seen.add(key)
            ids = global_catalog['producers'].get(key, [])
            if ids: producers[key] = ids
            for rid in ids:
                if rid not in included:
                    included.add(rid)
                    pending.extend(s['key'] for s in by_id[rid]['slots'])
        return dict(recipes=[r for r in global_catalog['recipes'] if r['id'] in included], producers=producers,
                    external=global_catalog['external'], parallelism=4096, max_extra_copies=64)
    structure = read(P.parent / 'miracle-cycle-20261002/audit-structure.json')
    for i, target in enumerate(structure['cycle_targets']):
        amount = 2000000 if 'ae2:f' in target else 1000
        groups.append(dict(id=f'original-cycle-{i}', kind='original-cycle', target=target,
                           stock=global_catalog['stock'], catalog=closure(target), dump=True,
                           requests=[dict(amount=str(amount), phase='baseline')]))
    write('archived-baseline.json', groups)
    print('Original archive baseline groups', len(groups))
else:
    sources = {g['id']: g for g in read(P / 'archived-baseline.json')}
    rows = [json.loads(line) for line in (P / 'archived-baseline.jsonl').read_text('utf8').splitlines()]
    groups = []
    for i, row in enumerate(sorted(rows, key=lambda r: r['group'])):
        if not row['feasible']: continue
        source = sources[row['group']]
        catalog = source['catalog']
        witness_bindings = {r.get('binding',r['id']) for r in catalog['recipes'] if r['id'] in row['counts']}
        amount = int(row['request']['amount'])
        for rate in (0, .1, .35, .75):
            rng = random.Random(321927 + i * 173 + int(rate * 100))
            bindings = sorted({r.get('binding',r['id']) for r in catalog['recipes']})
            keep = {b for b in bindings if b in witness_bindings or rng.random() < rate}
            recipes = [r for r in catalog['recipes'] if r.get('binding',r['id']) in keep]
            retained = {r['id'] for r in recipes}
            producers = {key: [rid for rid in ids if rid in retained] for key, ids in catalog['producers'].items()}
            producers = {key: ids for key, ids in producers.items() if ids}
            # Source order remains the archived provider order. Native suite handles
            # equal-priority shuffling; do not guess absent priorities here.
            requests = [dict(amount=str(n), phase='pinned-archive', cold=True) for n in sorted({1, amount, max(1,amount-1)})]
            groups.append(dict(id=f'archive-cut-{i}-{int(rate*100)}', kind='pinned-original-archive', target=source['target'],
                               stock=source['stock'], known_feasible_max=str(amount), requests=requests,
                               catalog=dict(catalog, recipes=recipes, producers=producers),
                               baseline_group=source['id'], pinned_bindings=sorted(witness_bindings),
                               work=20000000, memory=128<<20))
    # Separate modest shards to avoid having thousands of complete stock maps resident.
    for i in range(0, len(groups), 256):
        write(f'archive-cuts-{i//256}.json', groups[i:i+256])
    write('archive-shards.json', dict(groups=len(groups), requests=sum(len(g['requests']) for g in groups),
                                     shards=(len(groups)+255)//256,
                                     baseline_results=dict(collections.Counter(r['result'] for r in rows))))
    print((P / 'archive-shards.json').read_text('utf8'))
