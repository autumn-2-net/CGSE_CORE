import collections
import hashlib
import json
import pathlib
import shutil

ROOT = pathlib.Path.cwd().resolve()
P = ROOT / '.local/pruned-search-20261002'
NATIVE = ROOT / '.local/miracle-cycle-20261002/server/local/pruned-search-final-20261002'
read = lambda p: json.loads(p.read_text('utf8'))
rows = lambda p: [json.loads(s) for s in p.read_text('utf8').splitlines()]
summary = dict()
regressions = read(P / 'fixed-regressions.json')
assert not any(r['failures'] for r in regressions), 'A known feasible case failed'
summary['pure_requests'] = sum(r['requests'] for r in regressions)
summary['pure_suites'] = [{k: v for k, v in r.items() if k != 'failures'} for r in regressions]
summary['funded_failures'] = 0
before_files = {'all-linear': 'stable-linear-results.jsonl', 'random-dag': 'stable-dag-results.jsonl',
                'hard-boundaries': 'stable-boundaries-results.jsonl', 'prior-cases': 'stable-prior-results.jsonl'}
changes = []
def key(r):
    return r['group'], json.dumps(r['request'], sort_keys=True)
for name, old_file in before_files.items():
    old = {key(r): r for r in rows(P.parent / 'linear-search-20261002' / old_file)}
    new = {key(r): r for r in rows(P / f'fixed-{name}.jsonl')}
    assert old.keys() == new.keys(), (name, len(old), len(new))
    for k, r in new.items():
        assert r['result'] != 'ERROR'
        assert not old[k]['feasible'] or r['feasible'], (name, k, r['result'])
        if old[k]['result'] != r['result']:
            changes.append(dict(suite=name, group=r['group'], request=r['request'], before=old[k]['result'], after=r['result']))
summary['prior_category_changes'] = changes
summary['prior_feasible_regressions'] = 0

native = rows(NATIVE / 'paired.jsonl')
assert read(NATIVE / 'done.json')['ok']
assert len(native) == read(NATIVE / 'done.json')['completed']
assert not any(r['suspect'] for r in native)
assert all(r.get('cache_equal', True) and r.get('restored_equal', True) for r in native)
assert all(r['cgse']['result'] != 'ERROR' and r['maxfast']['result'] != 'ERROR' for r in native)
summary['native'] = dict(pairs=len(native),
    by_result={a+' / '+b: n for (a,b),n in collections.Counter((r['maxfast']['result'],r['cgse']['result']) for r in native).items()},
    cgse_worse=0, pinned_checks=sum(r['pinned_feasible'] for r in native),
    warm_cold_checks=sum('cache_equal' in r for r in native), restored_checks=sum('restored_equal' in r for r in native),
    population=read(NATIVE / 'loaded.json'))
summary['native']['profiles'] = []
for name in dict.fromkeys(r['order'] for r in native):
    if name.startswith('same-target'): continue
    rr = [r for r in native if r['order'] == name]
    summary['native']['profiles'].append(dict(name=name, pairs=len(rr),
        enabled_min=min(r['enabled'] for r in rr), enabled_max=max(r['enabled'] for r in rr),
        maxfast_feasible=sum(r['maxfast']['result'].startswith('FEASIBLE') for r in rr),
        cgse_feasible=sum(r['cgse']['result'].startswith('FEASIBLE') for r in rr)))

fresh = [{key(r): r for r in rows(P / f'fixed-jvm-{i}.jsonl')} for i in range(5)]
assert all(len(r) == 48 for r in fresh)
assert all(r['feasible'] for table in fresh for r in table.values())
variations = []
for k in fresh[0]:
    values = [(f[k]['result'], f[k]['work'], f[k]['peak_bytes']) for f in fresh]
    if len(set(values)) != 1: variations.append(dict(group=k[0], request=k[1], values=values))
summary['fresh_jvm'] = dict(processes=5, requests=240, failed=0, accounting_variations=variations)
assert not variations
case = next(r for r in rows(P / 'fixed-near-998.jsonl') if r['request']['amount'] == '998')
old = next(r for r in rows(P / 'jvm-0.jsonl') if r['group'] == case['group'] and r['request']['amount'] == '998')
summary['counterexample_998'] = dict(before={k:old[k] for k in ('result','work','peak_bytes')},
                                   after={k:case[k] for k in ('result','work','peak_bytes')},
                                   neighbor_checks=len(rows(P / 'fixed-near-998.jsonl')))
assert hashlib.sha256((ROOT / 'build.gradle').read_bytes()).hexdigest() == 'a17e1b46f2642be5c470eb3c130e02606b194574fefe08c5cccf229af8b8f9c0'
assert not list((P / 'runtime-backup').iterdir())
assert not (ROOT / '.local/miracle-cycle-20261002/server/mods/local-pruned-search-probe.jar').exists()
jar = ROOT / 'build/libs/gtlcore-1.2.3.2-fix3.jar'
artifact = P / 'gtlcore-1.2.3.2-fix3-pruned-search-test.jar'
shutil.copy2(jar, artifact)
summary['jar'] = dict(path=str(artifact), bytes=artifact.stat().st_size, sha256=hashlib.sha256(artifact.read_bytes()).hexdigest())
(P / 'validation.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), 'utf8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
