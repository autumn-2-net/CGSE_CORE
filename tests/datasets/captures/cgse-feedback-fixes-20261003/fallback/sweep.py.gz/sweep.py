import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import sys

root=Path.cwd()
base=root/'.local/cgse-feedback-fixes-20261003/fallback'
label=sys.argv[1]
area=base/label
area.mkdir(exist_ok=True)
classes=area/'classes';classes.mkdir(exist_ok=True)
java=Path('C:/Users/autumn/.jdks/corretto-20.0.2.1/bin')
previous=root/'.local/solver-strengthening-20261003/verified/classes'
gson=root/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'
cp=os.pathsep.join(map(str,[classes,previous,root/'build/classes/java/main',root/'build/classes/java/test',gson]))
sources=list((root/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core').glob('*.java'))+[base/'FallbackSweep.java']
argfile=area/'javac.args'
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(classes)]+list(map(str,sources))
argfile.write_text('\n'.join('"'+s.replace('\\','/')+'"' for s in args),encoding='utf-8')
subprocess.run([str(java/'javac.exe'),'@'+str(argfile)],check=True)
def run(name):
    output=area/(name+'.jsonl')
    with (area/(name+'.log')).open('wb') as log:
        subprocess.run([str(java/'java.exe'),'-ea','-Xmx1G','-cp',cp,
                        'org.gtlcore.gtlcore.integration.ae2.graph.core.FallbackSweep',
                        str(root/'.local/linear-search-20261002'/(name+'.json')),str(output)],
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    print(name,(area/(name+'.log')).read_text('utf-8').strip(),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run,['all-linear','random-dag','hard-boundaries']))
