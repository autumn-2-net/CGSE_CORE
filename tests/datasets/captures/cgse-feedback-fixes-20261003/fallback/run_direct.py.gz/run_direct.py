from pathlib import Path
import subprocess,sys
area=Path(__file__).resolve().parent
root=area.parents[2]
variant=sys.argv[1] if len(sys.argv)>1 else 'fixed'
jdk=Path('C:/Users/autumn/.jdks/corretto-20.0.2.1/bin')
out=area/('direct-'+variant);out.mkdir(exist_ok=True)
sources=list((root/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core').glob('*.java'))
if variant=='baseline':
    copied=out/'GraphFallback.java';copied.write_text((area/'GraphFallback.baseline.java').read_text(),encoding='utf8')
    sources=[p for p in sources if p.name!='GraphFallback.java']+[copied]
sources+=[area/'FallbackDirectProbe.java',root/'src/test/java/org/gtlcore/gtlcore/integration/ae2/graph/GraphFallbackTest.java']
args=area/('direct-'+variant+'-compile.args')
args.write_text('\n'.join(['-proc:none','-encoding','UTF-8','-d','"'+out.as_posix()+'"']+['"'+p.as_posix()+'"' for p in sources]),encoding='utf8')
with (area/('direct-'+variant+'-compile.log')).open('w',encoding='utf8') as log:
    result=subprocess.run([str(jdk/'javac.exe'),'@'+str(args)],stdout=log,stderr=subprocess.STDOUT)
if result.returncode:print((area/('direct-'+variant+'-compile.log')).read_text());raise SystemExit(result.returncode)
main=sys.argv[2] if len(sys.argv)>2 else 'org.gtlcore.gtlcore.integration.ae2.graph.core.FallbackDirectProbe'
logpath=area/('direct-'+variant+'-'+main.rsplit('.',1)[-1]+'.log')
with logpath.open('w',encoding='utf8') as log:
    result=subprocess.run([str(jdk/'java.exe'),'-ea','-Dbaseline='+str(variant=='baseline').lower(),'-cp',str(out),main],stdout=log,stderr=subprocess.STDOUT)
print(logpath.read_text());raise SystemExit(result.returncode)
