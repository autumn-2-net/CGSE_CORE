from pathlib import Path
import os,json,subprocess,statistics
r=Path.cwd();a=r/'.local/new-stage-20261004/order-audit';classes=r/'.local/new-stage-20261004/broad-verified-r1/current/classes';gson=r/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar';jdk=Path('C:/Users/autumn/.jdks/corretto-20.0.2.1/bin')
groups=json.loads((r/'.local/review-startup-20261004/large-1.json').read_text());byid={x['id']:x for x in groups};picked=[]
for line in (r/'.local/new-stage-20261004/broad-verified-r1/current/large-1.jsonl').open():
 row=json.loads(line)
 if 'integer_counts_first' in row.get('diagnostics','') and row['group'] in byid:
  g=byid.pop(row['group']);g['requests']=[row['request']];picked.append(g)
 if len(picked)==64:break
fixture=a/'policy-fixture.json';fixture.write_text(json.dumps(picked));base=a/'policy-bench-base';new=a/'policy-bench-new';base.mkdir(exist_ok=True);new.mkdir(exist_ok=True)
cp=os.pathsep.join(map(str,[classes,gson,a]));subprocess.run([str(jdk/'javac.exe'),'--release','17','-proc:none','-cp',cp,'-d',str(base),str(a/'PolicyFirstWitnessProbe.java')],check=True)
subprocess.run([str(jdk/'javac.exe'),'--release','17','-proc:none','-cp',str(classes),'-d',str(new),str(r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core/CountPortfolioPolicy.java')],check=True)
for trial in range(3):
 for version in (['baseline','current'] if trial%2==0 else ['current','baseline']):
  parts=[new,base,classes,gson,a] if version=='current' else [base,classes,gson,a]
  dest=a/f'policy-first-{version}-{trial}.jsonl'
  subprocess.run([str(jdk/'java.exe'),'-Xmx1g','-cp',os.pathsep.join(map(str,parts)),'org.gtlcore.gtlcore.integration.ae2.graph.core.PolicyFirstWitnessProbe',str(fixture),str(dest)],check=True)
  print(version,trial,'done',flush=True)
def rows(v,t):return {r['id']:r for r in map(json.loads,(a/f'policy-first-{v}-{t}.jsonl').read_text().splitlines())}
reports=[]
for t in range(3):
 old,newr=rows('baseline',t),rows('current',t);common=[k for k in old if old[k]['verified'] and newr[k]['verified']]
 stat=lambda rr:dict(solved=sum(x['verified'] for x in rr.values()),firstWork=sum(rr[k]['firstWork'] for k in common),firstMillis=sum(rr[k]['firstNanos']/1e6 for k in common),p50Millis=statistics.median(rr[k]['firstNanos']/1e6 for k in common))
 reports.append(dict(trial=t,cases=len(old),matched=len(common),baseline=stat(old),current=stat(newr),regressions=[k for k in old if old[k]['verified'] and not newr[k]['verified']],improved=[k for k in old if newr[k]['verified'] and not old[k]['verified']],changedWork=[dict(id=k,before=old[k]['firstWork'],after=newr[k]['firstWork']) for k in common if old[k]['firstWork']!=newr[k]['firstWork']]))
(a/'policy-first-comparison.json').write_text(json.dumps(reports,indent=2));print(json.dumps(reports),flush=True)
