from pathlib import Path
import subprocess,os,json,statistics,math
r=Path.cwd();a=r/'.local/new-stage-20261004/order-audit';old=r/'.local/structural-stage-20261004/next-stage-final-matrix-3';new=r/'.local/structural-stage-20261004/next-stage-final-matrix-4';gson=r/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar';jdk=Path('C:/Users/autumn/.jdks/corretto-20.0.2.1/bin');dest=a/'matrix-attribution';dest.mkdir(exist_ok=True)
harness=dest/'harness';harness.mkdir(exist_ok=True);subprocess.run([str(jdk/'javac.exe'),'--release','17','-proc:none','-cp',os.pathsep.join(map(str,[old/'classes',gson])),'-d',str(harness),str(a/'MatrixAttributionProbe.java')],check=True)
variants={'baseline':[],'efficiency':['CountPortfolioPolicy.java'],'mode':['IntegerCountBranch.java','IntegerCountSearch.java'],'all':[]}
for label,files in variants.items():
 folder=dest/label;folder.mkdir(exist_ok=True)
 if files:subprocess.run([str(jdk/'javac.exe'),'--release','17','-proc:none','-cp',str(new/'classes'),'-d',str(folder)]+[str(new/'core'/name) for name in files],check=True)
 cp=os.pathsep.join(map(str,[folder,harness,(new if label=='all' else old)/'classes',gson]));subprocess.run([str(jdk/'java.exe'),'-Xmx1g','-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.MatrixAttributionProbe',str(new/'cases.json'),str(folder/'results.json')],check=True);print(label,'done',flush=True)
rows={name:json.loads((dest/name/'results.json').read_text()) for name in variants};(dest/'comparison.json').write_text(json.dumps(rows,indent=2));print([{name:[x['work'] for x in values] for name,values in rows.items()}],flush=True)
def quantile(xs,q):
 ys=sorted(xs);return ys[math.ceil(len(ys)*q)-1]
tails=[]
for trial in range(3):
 row={'trial':trial}
 for label in ['baseline','current']:
  records=[json.loads(x) for x in (a/f'policy-first-{label}-{trial}.jsonl').read_text().splitlines()];ms=[x['firstNanos']/1e6 for x in records if x['verified']];row[label]={'count':len(ms),'p50':quantile(ms,.50),'p95':quantile(ms,.95),'p99':quantile(ms,.99),'max':max(ms)}
 tails.append(row)
(dest/'first-verified-tail.json').write_text(json.dumps(tails,indent=2));print(json.dumps(tails),flush=True)
