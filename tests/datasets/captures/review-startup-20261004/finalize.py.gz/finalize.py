from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile

r=Path.cwd(); a=r/'.local/review-startup-20261004'; t=r/'.local/structural-stage-20261004'
s=r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core'
def hashes(folder): return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.java')}
def read(folder,name): return json.loads((folder/name).read_text('utf-8'))
current=hashes(s); baseline=hashes(a/'baseline')
assert current==hashes(t/'startup-final-matrix/core')==hashes(t/'startup-final-boundaries/core')==hashes(a/'large-final/current/core')
assert hashlib.sha256((r/'build.gradle').read_bytes()).hexdigest()=='a17e1b46f2642be5c470eb3c130e02606b194574fefe08c5cccf229af8b8f9c0'
changed=[k for k,v in current.items() if baseline.get(k)!=v]
assert set(changed)=={'CountModelViews.java','CountPortfolioPolicy.java','CountSeparator.java','CountViewSearch.java','GraphCompiler.java','GraphPlanningWork.java','MissingStockAnalysis.java','MissingStockIndex.java','QuantityAnalysis.java'},changed
build=(t/'startup-policy-stride-final-build.log').read_text(errors='replace')
assert 'BUILD SUCCESSFUL' in build and '> Task :graphCoreTest' in build and '> Task :graphIntegrationTest' in build
public=read(t/'startup-final-matrix','summary.json'); assert public['total']==464 and not public['failed']
corpus=read(t/'startup-final-corpus','report.json'); assert sum(x['requests'] for x in corpus)==35207 and not any(x['failures'] for x in corpus)
large=read(a/'large-final','comparison.json'); assert sum(x['current']['requests'] for x in large)==77364 and not any(x['wrong'] or x['regressions'] for x in large)
assert all(x[2]==0 for x in read(a/'large-final','jobs.json'))
# Whole-request accounting includes retained compilation/result structures. It
# has no reservedBytes()==0 postcondition; the local harness field called these
# "leaks", which alone does not establish an object leak or regression.
for x in large:
    x['baseline_nonzero_accounting']=x.pop('baseline_leaks')
    x['current_nonzero_accounting']=x.pop('current_leaks')
old=read(t/'startup-comparison-baseline','startup-comparison.json'); new=read(t/'startup-final-matrix','startup-comparison.json')
assert old['work']==new['work']==600000 and new['interruptedGraphOwnerLeak']==new['interruptedQuantityOwnerLeak']==0
policy=read(t/'startup-final-matrix','policy-stride-probe.json'); startup=read(t/'startup-final-matrix','startup-probe.json')
assert policy['separatorCases']==48 and policy['mitmCases']==48 and policy['admissionGuards']==60 and policy['policyScenarios']==2000
assert startup['oracleAnalyses']==80001 and startup['concurrentRequests']==96
boundaries={p.stem:json.loads(p.read_text()) for p in (t/'startup-final-boundaries').glob('*.json') if p.name not in ['source-hashes.json']}
comparison={'baseline':old,'current':new,'allocation_reduction_percent':100*(1-new['allocatedBytes']/old['allocatedBytes']),'peak_reduction_percent':100*(1-new['peakBytes']/old['peakBytes'])}
main_rows=[json.loads(line) for line in (t/'startup-final-matrix/results.jsonl').read_text().splitlines()]
prior_rows=[x for x in main_rows if x['variation']<4]
public_previous_subset={'requests':len(prior_rows),'work':sum(x['work'] for x in prior_rows)}
old_work=sum(x['baseline']['work'] for x in large); new_work=sum(x['current']['work'] for x in large)
shutil.copytree(s,a/'verified-source')
jar=a/'gtlcore-1.2.3.2-fix3-cgse-startup-scheduling-test.jar'; shutil.copy2(r/'build/libs/gtlcore-1.2.3.2-fix3.jar',jar)
prefix='org/gtlcore/gtlcore/integration/ae2/graph/core/'
with zipfile.ZipFile(jar) as archive:
    for clazz,marker in [('MissingStockIndex','belongsTo'),('MissingStockAnalysis','indexedWaking'),('CountPortfolioPolicy','candidateEfficiency'),('CountViewSearch','count_stride_scout'),('CountModelViews','reduced'),('CountScheduleContinuations','same_branch_scope')]:
        assert marker.encode() in archive.read(prefix+clazz+'.class')
    for name in ['StartupProbe','StartupComparison','PolicyStrideProbe','LargeSweep','StrideProbe','ConflictProbe','ContinuationProbe','ContinuationBoundaryProbe','CountBenchmark']:
        assert prefix+name+'.class' not in archive.namelist()
sha=hashlib.sha256(jar.read_bytes()).hexdigest(); jar.with_suffix('.jar.sha256').write_text(sha+'  '+jar.name+'\n')
report={
    'base_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'changed_this_round':changed,'source_sha256':current,'preexisting_build_gradle_preserved':True,'committed_or_pushed':False,
    'implemented':[
        'Request-local candidate family feedback uses measured search/restore and downstream execution/validation cost; verified yield is separate from censored UNKNOWN observations, with mandatory exploration and aging retained.',
        'A bounded immutable all-source consumer index is retained by the exact compiler catalog after observed reuse; each analysis still computes fresh inventory, exclusion and startup reachability state.',
        'MissingStockAnalysis now owns its temporary budget reservation until close; completion, cancellation and both graph/quantity-analysis owners release it.',
        'One bounded candidate-only Separator or meet-in-the-middle attempt is added only if a retained stride view newly passes the specialist domain/admission gate compared with the actual reduced-model rows and domains, including deduplicated views.',
        'Stride candidates pass the existing inverse and original-row checks plus the normal execution/stock verifier; specialist cutoffs and local contradictions are not exported as infeasibility.',
        'Prior uncommitted fixed-count scheduling continuation changes are preserved and revalidated.'
    ],
    'checks':{
        'core_ae_integration_and_remapped_build':'passed',
        'public_main_16_permutations':public,
        'public_original_4_permutation_subset':public_previous_subset,
        'complete_request_corpus':{'requests':35207,'failures':0,'families':corpus},
        'large_order_pruning_quantity_budget_comparison':large,
        'large_work_delta_percent':100*(new_work/old_work-1),
        'frontend_oracle_and_scopes':startup,
        'policy_and_stride_admission':policy,
        'frontend_chain_microbenchmark':comparison,
        'stride_conflicts_continuations':boundaries
    },
    'remaining_review_work':[
        'Shared packed input/output indices for additional compiler and SCC passes; this round reuses startup consumer incidence only.',
        'CountRecovery macro discovery/compilation reuse with request and transformation scope checks.',
        'General linear constraint transfer across equivalent views; current portable pool covers root bounds and small scoped conflicts.',
        'Global candidate deduplication and mode-specific scheduling feedback; current continuation and feedback scopes remain local.',
        'Native sparse CP atoms or symbolic-state algorithms only after a demonstrated failing family.'
    ],
    'limitations':[
        'No live Minecraft client exercise in this round; this artifact was built and tested through the core and AE integration harnesses.',
        'The 77,364 requests derive from 384 independent funded DAG templates, four recipe-order permutations, three alternative-pruning profiles, quantity boundaries, warm/cold runs and three budget profiles, not 77,364 independent topologies.',
        'Both versions retain eight SEARCH_LIMIT results at the smallest 250,000-work/16-MiB budget; the higher-budget profiles solve all funded requests.',
        'The larger request sweep slightly increases total charged work; no overall latency or throughput improvement is claimed.',
        'The 2,000-recipe chain microbenchmark measures warm-query allocation and temporary reservation, not representative game frame time.',
        'The 48+48 targeted specialist tests isolate the new scout after real reduction to verify the route and inverse; they do not claim a natural portfolio speedup.',
        'Separator structural table limits and MITM memory/work limits still apply after the new stride admission gate.',
        'Common model compilation costs are not yet fully attributed per candidate source; the new feedback covers measured search, restoration and downstream work.',
        'Whole-request accounting includes retained compiled/result structures, so nonzero accounting after close is recorded but is not a JVM object-leak assertion. Temporary startup index/analysis lifecycle probes require zero outstanding reservations.',
        'These translated finite solver cases do not establish parity with general CP-SAT or SCIP.'
    ],
    'artifact':{'path':str(jar),'sha256':sha,'bytes':jar.stat().st_size}
}
(a/'final-report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'changed_this_round':changed,'main':public,'full_requests':112571,'large_work_delta_percent':report['checks']['large_work_delta_percent'],'frontend_microbenchmark':comparison,'artifact':report['artifact']},indent=2))
