from pathlib import Path
import concurrent.futures,hashlib,json,os,shutil,subprocess,sys
r=Path.cwd();a=r/'.local/review-startup-20261004';out=a/sys.argv[1];out.mkdir();jdk=Path('C:/Users/autumn/.jdks/corretto-20.0.2.1/bin');gson=r/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'
sources={'baseline':a/'baseline','current':r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core'}
for name,source in sources.items():
    folder=out/name;folder.mkdir();core=folder/'core';shutil.copytree(source,core);classes=folder/'classes';classes.mkdir()
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in core.glob('*.java')};(folder/'source-hashes.json').write_text(json.dumps(hashes,indent=2))
    cp=os.pathsep.join(map(str,[classes,gson]));args=['--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(classes)]+list(map(str,core.glob('*.java')))+[str(a/'LargeSweep.java')]
    argfile=folder/'javac.args';argfile.write_text('\n'.join('"'+v.replace('\\','/')+'"' for v in args));subprocess.run([str(jdk/'javac.exe'),'@'+str(argfile)],check=True)
def job(pair):
    name,profile=pair;folder=out/name;cp=os.pathsep.join(map(str,[folder/'classes',gson]));dest=folder/f'large-{profile}.jsonl'
    with (folder/f'large-{profile}.log').open('wb') as log:
        completed=subprocess.run([str(jdk/'java.exe'),'-ea','-Xmx2g','-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.LargeSweep',str(r/'.local/miracle-cycle-20261002/audit-original-catalog.json'),str(a/f'large-{profile}.json'),str(dest),'1'],stdout=log,stderr=subprocess.STDOUT)
    print(name,profile,'exit',completed.returncode,flush=True);return name,profile,completed.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    statuses=list(pool.map(job,[(name,p) for p in range(3) for name in sources]))
comparisons=[]
for profile in range(3):
    def read(name):
        counts={};records={}
        for line in (out/name/f'large-{profile}.jsonl').read_text().splitlines():
            row=json.loads(line);key=(row['group'],row['request']['phase'],row['request']['amount']);ordinal=counts.get(key,0);counts[key]=ordinal+1;records[key+(ordinal,)]=row
        return records
    before,after=read('baseline'),read('current');assert before.keys()==after.keys()
    regressions=[];wrong=[];improved=[];old_leaks=[];new_leaks=[]
    for key,row in after.items():
        old=before[key]
        if row['result'] in ['ERROR','MISSING_INPUT','MISSING_SEED','INFEASIBLE']:wrong.append(row)
        if old['feasible'] and not row['feasible']:regressions.append(row)
        if row['feasible'] and not old['feasible']:improved.append(key)
        if old.get('reserved_after_close',0):old_leaks.append(key)
        if row.get('reserved_after_close',0):new_leaks.append(key)
    def stats(values):
        return dict(requests=len(values),solved=sum(x['feasible'] for x in values.values()),work=sum(x['work'] for x in values.values()),statuses={s:sum(x['result']==s for x in values.values()) for s in {x['result'] for x in values.values()}})
    report=dict(profile=profile,baseline=stats(before),current=stats(after),regressions=regressions,wrong=wrong,improved=improved,baseline_leaks=len(old_leaks),current_leaks=len(new_leaks));comparisons.append(report)
    print(json.dumps({k:v for k,v in report.items() if k not in ['regressions','wrong','improved']}),flush=True)
(out/'comparison.json').write_text(json.dumps(comparisons,indent=2));(out/'jobs.json').write_text(json.dumps(statuses))
if any(row['regressions'] or row['wrong'] for row in comparisons) or any(x[2] for x in statuses):raise SystemExit(1)
