from pathlib import Path
import json,random,hashlib
r=Path.cwd();a=r/'.local/review-startup-20261004'
source=json.loads((r/'.local/linear-search-20261002/random-dag.json').read_text())
base=[g for g in source if g['id'].endswith('-order-0')]
profiles=[(250_000,16),(2_000_000,32),(20_000_000,128)]
summary=[]
for profile,(work,mib) in enumerate(profiles):
    groups=[]
    for sample,original in enumerate(base):
        maximum=int(original['known_feasible_max'])
        values=sorted({1,max(1,maximum//100),max(1,maximum//10),max(1,maximum-1),maximum})
        requests=[dict(amount=str(n),phase='quantity-boundary',cold=False) for n in values]
        requests += [dict(amount=str(maximum),phase='reused-catalog',cold=False),dict(amount=str(maximum),phase='fresh-catalog',cold=True)]
        for cut in (0,35,100):
            for order in range(4):
                seed=131071+sample*65537+cut*509+order*1009
                rng=random.Random(seed)
                rs=[v for v in original['catalog']['recipes'] if v['id'].startswith('good-') or rng.randrange(100)<cut]
                rng.shuffle(rs);ids={v['id'] for v in rs}
                producers={k:[v for v in choices if v in ids] for k,choices in original['catalog']['producers'].items()}
                for choices in producers.values():rng.shuffle(choices)
                g=dict(original,id=f'large-{sample}-cut{cut}-order{order}-budget{profile}',kind='independent-dag-witness-budget-and-order-sweep',catalog=dict(recipes=rs,producers=producers),work=work,memory=mib<<20,requests=requests,random_seed=seed)
                groups.append(g)
    path=a/f'large-{profile}.json';path.write_text(json.dumps(groups,separators=(',',':')))
    summary.append(dict(profile=profile,groups=len(groups),requests=sum(len(g['requests']) for g in groups),work=work,memory=mib<<20,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(a/'large-manifest.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
# Keep the known independent witness, but never count a budget cutoff as UNSAT.
s=(r/'.local/quantity-regression-20261002/QuantitySweep.java').read_text()
s=s.replace('public final class QuantitySweep','public final class LargeSweep').replace('completed % 10 == 0','completed % 250 == 0')
s=s.replace('row.addProperty("ms", (System.nanoTime() - started) / 1e6);','row.addProperty("reserved_after_close", budget.reservedBytes());\n        row.addProperty("ms", (System.nanoTime() - started) / 1e6);')
(a/'LargeSweep.java').write_text(s)
