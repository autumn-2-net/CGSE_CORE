from pathlib import Path
import subprocess,re
root=Path.cwd()
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
files=sorted(set(p for p in changed+new if p.endswith('.java')))
for name in files:
    path=root/name
    text=path.read_text(encoding='utf-8')
    # Convert newly added qualified type references to ordinary imports. Do not
    # touch strings, comments, or existing import lines.
    candidates=set(re.findall(r'(?:org\.gtlcore\.gtlcore\.integration\.ae2\.graph(?:\.core)?|java\.math|java\.util(?:\.concurrent)?|net\.minecraft\.world\.level|appeng\.api\.networking\.crafting)\.[A-Z][A-Za-z0-9]+',text))
    additions=[]
    for full in sorted(candidates):
        if full.endswith('.AEKey'): continue
        short=full.rsplit('.',1)[1]
        imported=re.findall(r'^import ([\w.]+);$',text,re.M)
        if any(i.rsplit('.',1)[1]==short and i!=full for i in imported): continue
        lines=text.splitlines(True)
        replaced=False
        for i,line in enumerate(lines):
            if line.lstrip().startswith(('package ','import ','//','*')): continue
            if full in line:
                lines[i]=line.replace(full,short); replaced=True
        if replaced:
            text=''.join(lines)
            if full not in imported: additions.append(full)
    if additions:
        match=re.search(r'^package [\w.]+;\n',text,re.M)
        text=text[:match.end()]+'\n'+''.join('import '+i+';\n' for i in additions)+text[match.end():]
    path.write_text(text,encoding='utf-8')
Path('.local/graph-format-targets.txt').write_text('\n'.join(files)+'\n',encoding='utf-8')
# Remove the now-reusable validation task from local build overrides.
build=Path('build.gradle')
text=build.read_text(encoding='utf-8')
text=text.split('// Local validation tasks only; not part of the source patch.')[0].rstrip()+'\n'
text+='\n// Local formatting scope; not part of the source patch.\nspotless.java { target file(".local/graph-format-targets.txt").readLines() }\n'
build.write_text(text,encoding='utf-8')
