from pathlib import Path
from collections import defaultdict,Counter
import json,sys,re
sys.stdout.reconfigure(encoding='utf8',errors='replace');sys.setrecursionlimit(30000)
area=Path(__file__).resolve().parent;p=area/'server/local/ae-audit/catalog.json'
j=json.loads(p.read_text('utf8'));recipes=j['recipes'];targets=set(j['targets']);stock={k:int(v) for k,v in j['stock'].items()}
adj=defaultdict(set);radj=defaultdict(set);outputs=defaultdict(list)
for r in recipes:
    for out,num in r['outputs'].items():
        adj[out];outputs[out].append(int(num))
        for slot in r['slots']:
            if slot['configuration'] or slot['reusable']:continue
            k=slot['key'];adj[out].add(k);adj[k];radj[k].add(out)
visited=set();finish=[]
def dfs(v):
    if v in visited:return
    visited.add(v)
    for w in sorted(adj[v]):dfs(w)
    finish.append(v)
for v in list(adj):dfs(v)
visited.clear();comps=[]
def collect(v,c):
    if v in visited:return
    visited.add(v);c.append(v)
    for w in sorted(radj[v]):collect(w,c)
for v in reversed(finish):
    if v not in visited:
        c=[];collect(v,c);comps.append(sorted(c))
cycles=[c for c in comps if len(c)>1 or c[0] in adj[c[0]]];cycles.sort(key=lambda c:(-len(c),c))
cyclic={k for c in cycles for k in c};dependent=set(cyclic);queue=list(cyclic)
for k in queue:
    for v in radj[k]:
        if v not in dependent:dependent.add(v);queue.append(v)
linear=sorted(targets-dependent);cycle_targets=sorted(targets&cyclic)
def short(k):
    m=re.search(r'id:"([^\"]+)',k);return m.group(1) if m else k
summary=dict(recipes=len(recipes),targets=len(targets),stock=len(stock),cycles=[dict(keys=[short(k) for k in c],target_keys=[k for k in c if k in targets]) for c in cycles],linear_targets=linear,cycle_targets=cycle_targets,dependent_targets=sorted(targets&dependent))
(area/'audit-structure.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),'utf8')
print('STRUCTURE',{k:len(v) if isinstance(v,list) else v for k,v in summary.items()})
for i,c in enumerate(cycles):print('CYCLE',i,len(c),[short(k) for k in c])
def cases(keys,kind):
    out=[]
    for i,k in enumerate(keys):
        unit=min(outputs.get(k,[1]));amounts=sorted({unit,1000 if 'ae2:i' in k else 2_000_000})
        for a in amounts:out.append(dict(id=f'{kind}-{i}-{a}',target=k,amount=str(a),work=3_000_000,timeout=5000))
    return out
for name,keys in [('linear',linear),('cycle',cycle_targets),('dependent',sorted(targets-cyclic-set(linear)))]:
    out=cases(keys,name);(area/f'audit-{name}-cases.json').write_text(json.dumps(out,ensure_ascii=False),'utf8');print(name,'cases',len(out))
all_targets=sorted(targets)
(area/'audit-all-targets.json').write_text(json.dumps(all_targets,ensure_ascii=False),'utf8')
