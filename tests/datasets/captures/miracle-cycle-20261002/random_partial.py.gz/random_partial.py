import json
from pathlib import Path
area=Path(__file__).resolve().parent;out=area/'server/local/random-order'
def key(kind,name):return '{"#c":"ae2:'+kind+'",id:"'+name+'"}'
crystal=key('i','gtlcore:miracle_crystal');gas=key('f','gtceu:miracle_gas');fluid=key('f','gtceu:miracle');matter=key('f','gtceu:primordialmatter')
cases=[]
for amount in (1,999,1000,2000,1000000,2000000,2147483647,1000000000000):
 for starting_gas in (0,10000,100000):
  liquid_runs=(amount+999)//1000
  gas_runs=max(0,(liquid_runs*100000-starting_gas+89999)//90000)
  stock={crystal:str(gas_runs+1),gas:str(starting_gas),matter:str(gas_runs*100000)}
  c=dict(id=f'partial-{amount}-{starting_gas}-funded',target=fluid,amount=str(amount),stock=stock,verify_cache=True,expected_feasible=True)
  cases.append(c)
  if gas_runs:
   short=dict(stock);short[matter]=str(gas_runs*100000-1)
   cases.append(dict(c,id=c['id'].replace('funded','short'),stock=short,expected_feasible=False))
  cases.append(dict(c,id=c['id'].replace('funded','restored')))
orders=json.loads((out/'cases.json').read_text('utf8'))['orders']
spec=dict(orders=orders,cases=cases)
(out/'partial.json').write_text(json.dumps(spec),'utf8')
print('Native partial-path boundary suite',len(cases),'x',len(orders),'=',len(cases)*len(orders))
