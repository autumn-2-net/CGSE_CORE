from pathlib import Path
from collections import Counter
import json,sys,re
sys.stdout.reconfigure(encoding='utf8',errors='replace')
area=Path(__file__).resolve().parent;d=area/'server/local/ae-audit'
def short(k):
    m=re.search(r'id:"([^\"]+)',k);return m.group(1) if m else k
for arg in sys.argv[1:] or ['cycles-initial','linear-initial']:
    p=d/(arg+'.jsonl')
    if not p.exists():continue
    rows=[json.loads(line) for line in p.read_text('utf8').splitlines() if line]
    print(arg,len(rows),Counter((r.get('maxfast',{}).get('result'),r.get('cgse',{}).get('result')) for r in rows),'generations',Counter((r.get('generation_before'),r.get('generation_after')) for r in rows))
    for r in rows:
        legacy=r.get('maxfast',{});graph=r.get('cgse',{})
        if legacy.get('result')=='FEASIBLE' and graph.get('result') not in ('FEASIBLE','FEASIBLE_NOT_PROVEN_OPTIMAL') or arg.startswith('cycles') and graph.get('result') not in ('FEASIBLE','FEASIBLE_NOT_PROVEN_OPTIMAL') or 'error' in r:
            print(r['id'],short(r.get('target','')),r.get('amount'),legacy.get('result'),graph.get('result'),'missing',[(short(k),v) for k,v in graph.get('missing',{}).items()],'error',r.get('error',graph.get('error')))
    bad=[r for r in rows if r.get('maxfast',{}).get('result')=='FEASIBLE' and r.get('cgse',{}).get('result') not in ('FEASIBLE','FEASIBLE_NOT_PROVEN_OPTIMAL')]
    (area/(arg+'-differences.json')).write_text(json.dumps(bad,ensure_ascii=False,indent=2),'utf8')
