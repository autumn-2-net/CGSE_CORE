from pathlib import Path
from collections import Counter
import json,hashlib
area=Path(__file__).resolve().parent;d=area/'server/local/ae-audit';feasible={'FEASIBLE','FEASIBLE_NOT_PROVEN_OPTIMAL'}
original=json.loads((area/'audit-original-catalog.json').read_text('utf8'));current=json.loads((d/'catalog.json').read_text('utf8'))
oldrecipes={r['id']:r for r in original['recipes']};newrecipes={r['id']:r for r in current['recipes']};assert oldrecipes==newrecipes
cases={}
for f in ['cycle','linear','dependent','formal','tight']:
 for c in json.loads((area/f'audit-{f}-cases.json').read_text('utf8')):cases[c['id']]=c
summary={};checks=0;rows_all=[]
for name,expected in [('cycles-initial',196),('linear-initial',6364),('dependent-initial',4906),('formal-first',2),('formal-rest',42),('linear-tight',1200)]:
 rows=[json.loads(s) for s in (d/(name+'.jsonl')).read_text('utf8').splitlines()];assert len(rows)==expected,(name,len(rows))
 for r in rows:
  assert not r.get('error'),r
  assert r['generation_before']==r['generation_after'],r['id']
  g=r['cgse'];c=cases[r['id']];stock=c.get('stock',original['stock']);external=set(original['external'])
  if g['result'] in feasible:
   assert not g['missing'],r['id']
   for k,v in g['initial'].items():assert int(v)>=0 and (k in external or int(v)<=int(stock.get(k,0))),(r['id'],k,v,stock.get(k))
   checks+=1
  for v in g.get('missing',{}).values():assert int(v)>0,(r['id'],v)
 counts=Counter((r['maxfast']['result'],r['cgse']['result']) for r in rows)
 summary[name]={'cases':len(rows),'status_pairs':[{'maxfast':a,'cgse':b,'cases':n} for (a,b),n in counts.items()]}
 rows_all+=rows
formal=[r for r in rows_all if r['id'].startswith('formal-')]
assert all(r['cgse']['result'] in feasible for r in formal)
initial_limits={r['id'] for r in rows_all if not r['id'].startswith('formal-') and r['maxfast']['result']=='FEASIBLE' and r['cgse']['result'] not in feasible}
assert initial_limits=={r['id'].removeprefix('formal-') for r in formal},initial_limits
full_order_changed=sum(original['producers'].get(k)!=v for k,v in current['producers'].items())
result={'environment':'Isolated copied Miracle save, native Forge and actual saved registered patterns; frozen inventory for each paired preview. No jobs submitted.',
 'catalog_recipes':len(oldrecipes),'craftable_targets':len(original['targets']),'resource_cycles':33,'pure_linear_targets':3182,
 'total_paired_previews':len(rows_all),'results':summary,'independent_inventory_bounds_checked':checks,
 'cgse_missing_when_maxfast_feasible':0,'cgse_unresolved_when_maxfast_feasible_at_formal_budget':0,
 'formal_limits':{'work':2000000000,'memory_mib':1024,'max_observed_work':max(r['cgse']['work'] for r in formal),'max_observed_memory_bytes':max(r['cgse']['peak_bytes'] for r in formal),'max_observed_ms':max(r['cgse']['ms'] for r in formal)},
 'restart':{'same_recipe_contents':True,'producer_lists_with_changed_order':full_order_changed,'note':'Same-priority ordering can change after reload; no claim that this reproduces the other player report.'},
 'limits':['Unknown screenshot report is from a different, unavailable save and is not reproduced.','This validates planning and exact inventory witnesses, not physical machine-job completion.','44 large dependent orders exceeded the deliberately reduced 3M-work screening budget; all passed the formal 2B-work/1GiB check.','Some complex orders still take seconds, slower than MaxFast.'],
 'new_production_changes_during_audit':False,'committed':False,'pushed':False}
(area/'network-audit-findings.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
print('PASS paired previews',len(rows_all),'feasible plans independently within stock',checks,'false missing vs MaxFast',0,'unresolved formal comparisons',0)
