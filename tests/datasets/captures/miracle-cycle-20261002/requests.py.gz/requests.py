from pathlib import Path
import json,time,shutil,sys
area=Path(__file__).resolve().parent;bridge=area/'server/local/ae-probe'
def request(name,op='preview',amount='1000',**args):
    (bridge/'request.json').write_text(json.dumps(dict(id=name,op=op,amount=amount,item='gtlcore:miracle_crystal',**args)),'utf8')
    started=time.monotonic();wall=time.time()
    with (area/'commands.txt').open('a',encoding='utf8') as out:out.write('execute in kubejs:void run gc_probe\n')
    while time.monotonic()-started<180:
        try:r=json.loads((bridge/'response.json').read_text('utf8'))
        except (OSError,ValueError):r={}
        if r.get('id')==name:
            shutil.copy2(bridge/'response.json',area/(name+'.json'))
            if not r.get('ok'):raise RuntimeError(r)
            print('RESULT',name,'result',r.get('result'),'work',r.get('work'),'peak',r.get('peak_bytes'),'missing',r.get('missing'),flush=True)
            return r
        if r.get('ok') is False and (bridge/'response.json').stat().st_mtime>=wall:raise RuntimeError(r)
        time.sleep(.2)
    raise TimeoutError(name)
if __name__=='__main__':
    if len(sys.argv)>1:request(sys.argv[1],sys.argv[2],sys.argv[3] if len(sys.argv)>3 else '1000')
    else:
        log=area/'native-miracle.log';start=time.monotonic()
        while not log.exists() or 'Done (' not in log.read_text('utf8',errors='replace'):
            if time.monotonic()-start>300:raise TimeoutError('Startup')
            time.sleep(.5)
        time.sleep(20)
        request('native1000')
        request('native_long',amount=str(2**63-1))
        request('snapshot','capture')
