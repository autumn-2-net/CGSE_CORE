from pathlib import Path
import subprocess, zipfile
root=Path.cwd().resolve();area=root/'.local/miracle-cycle-20261002';server=area/'server'
classes=area/'probe-classes'
cp=list((server/'mods').glob('*.jar'))+list((server/'libraries').rglob('*.jar'))
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',';'.join(str(p) for p in cp),'-d',str(classes),str(area/'NativeProbe.java'),str(area/'NetworkAudit.java'),str(area/'RandomOrderAudit.java')]
(area/'random-javac.args').write_text('\n'.join('"'+x.replace('\\','/')+'"' for x in args),'utf8')
subprocess.run([r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin\javac.exe','@'+str(area/'random-javac.args')],check=True)
with zipfile.ZipFile(server/'mods/local-miracle-probe.jar','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('META-INF/mods.toml','modLoader="javafml"\nloaderVersion="[47,)"\nlicense="All Rights Reserved"\n[[mods]]\nmodId="localmiracleprobe"\nversion="0.0.0"\ndisplayName="Local exact AE snapshot probe"\n')
 for p in classes.rglob('*.class'):z.write(p,p.relative_to(classes).as_posix())
live=(area/'live_audit.py').read_text('utf8').replace("area/'audit_probe.js'","area/'random_probe.js'").replace("['[Network Audit]'","['[Random Order]','[Network Audit]'")
(area/'live_random.py').write_text(live,'utf8')
cfg=server/'config/aedump-common.toml';cfg.write_text(cfg.read_text('utf8').replace('enabled = true','enabled = false'),'utf8')
print('Compiled local random-order helper; dump overhead disabled only in copied test server.')
