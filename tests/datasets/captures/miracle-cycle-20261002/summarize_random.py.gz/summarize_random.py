from pathlib import Path
import collections,hashlib,json,subprocess
area=Path(__file__).resolve().parent;root=area.parent.parent;out=area/'server/local/random-order'
fields=('result','missing','initial','seeds','recipe_count','plan_hash')
def load(name):return [json.loads(x) for x in (out/name).read_text('utf8').splitlines() if x]
def feasible(row,engine='cgse'):return row[engine]['result'].startswith('FEASIBLE')
summary={};allrows=[]
for name in ('cases','partial'):
 spec=json.loads((out/(name+'.json')).read_text('utf8'));rows=load(name+'.jsonl')
 expected={(o['name'],c['id']) for o in spec['orders'] for c in spec['cases']}
 actual=[(r['order'],r['id']) for r in rows]
 assert len(actual)==len(expected) and set(actual)==expected,(name,len(actual),len(expected))
 groups=collections.defaultdict(list)
 for r in rows:groups[r['id']].append(r)
 order_changes={engine:[k for k,g in groups.items() if len({feasible(r,engine) for r in g})>1] for engine in ('cgse','maxfast')}
 false_missing=[(r['order'],r['id']) for r in rows if feasible(r,'maxfast') and not feasible(r)]
 unresolved=[(r['order'],r['id'],r[e]['result']) for r in rows for e in ('cgse','maxfast') if r[e]['result']=='ERROR' or r[e]['result']=='TIMEOUT' or r[e]['result'].endswith('LIMIT')]
 cache=[r for r in rows if 'warm' in r]
 badcache=[(r['order'],r['id']) for r in cache if any(r['warm'].get(f)!=r['cold'].get(f) for f in fields)]
 assert not false_missing and not unresolved and not badcache
 assert not any(order_changes.values())
 if name=='partial':
  oracle={c['id']:c['expected_feasible'] for c in spec['cases']}
  assert all(feasible(r)==oracle[r['id']] and feasible(r,'maxfast')==oracle[r['id']] for r in rows),'Known inventory boundary failed'
 summary[name]={
  'paired_previews':len(rows),'distinct_cases':len(groups),'orders':[o['name'] for o in spec['orders']],
  'results':dict(collections.Counter(r['maxfast']['result']+' / '+r['cgse']['result'] for r in rows)),
  'false_missing_vs_maxfast':false_missing,'unresolved':unresolved,'order_feasibility_changes':order_changes,
  'warm_cold_checks':len(cache),'warm_cold_mismatches':badcache,'screening_limit_retries':sum('cgse_screen' in r for r in rows),
  'cgse_feasible_verified':sum(feasible(r) for r in rows),
 }
 allrows+=rows
orders=load('orders.jsonl')[2:9]
summary['source']={
 'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'archive':'ae-dump-muqjcnc6-60.zip','archive_sha256':hashlib.sha256((area/'server/logs/ae-dump/ae-dump-muqjcnc6-60.zip').read_bytes()).hexdigest(),
 'production_jar_sha256':hashlib.sha256((area/'server/mods/gtlcore-1.2.3.2-fix3.jar').read_bytes()).hexdigest(),
 'input':json.loads((out/'loaded.json').read_text('utf8')),
 'changed_primary_producer_lists':{r['order']:r['changed_producer_lists'] for r in orders},
 'configuration':'MAX_FAST compared with CGSE, PRESERVE, primary producer discovery as saved; all stock frozen to dump extractable_inventory. 3M screening work, limits retried at 2B work / 1GiB. Warm/cold both use 2B. No task submission.',
}
summary['total_paired_previews']=len(allrows)
summary['total_warm_cold_checks']=sum('warm' in r for r in allrows)
summary['notes']=[
 'Each feasible CGSE witness was checked for executable prefixes, exact target net demand, legal long initial reservation, and initial amounts bounded by the fixed inventory.',
 'FEASIBLE_NOT_PROVEN_OPTIMAL is feasible; not treated as missing.',
 'Do not compare detailed missing plan hashes across different work budgets. Same-budget warm/cold comparisons cover all targeted cache cases.',
 'Finite randomized planning regression; does not prove all ordering possibilities or physical machine execution.',
 'Tests, copied server, raw archive, helper mod and this report remain local and are not in the commit.',
]
(area/'random-order-regression.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),'utf8')
print(json.dumps(summary,indent=2,ensure_ascii=False))
