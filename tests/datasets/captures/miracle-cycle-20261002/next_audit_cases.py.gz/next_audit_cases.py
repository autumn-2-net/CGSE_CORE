from pathlib import Path
import json,shutil,random
area=Path(__file__).resolve().parent;d=area/'server/local/ae-audit'
rows=[json.loads(s) for s in (d/'dependent-initial.jsonl').read_text('utf8').splitlines()]
assert len(rows)==4906,len(rows)
shutil.copy2(d/'catalog.json',area/'audit-original-catalog.json')
stock=json.loads((d/'catalog.json').read_text('utf8'))['stock']
bad=[r for r in rows if r['maxfast']['result']=='FEASIBLE' and r['cgse']['result'] not in ('FEASIBLE','FEASIBLE_NOT_PROVEN_OPTIMAL')]
cases=[dict(id='formal-'+r['id'],target=r['target'],amount=r['amount'],stock=stock,work=2_000_000_000,timeout=60000,dump=True) for r in bad]
(area/'audit-formal-cases.json').write_text(json.dumps(cases),'utf8')
linear=[json.loads(s) for s in (d/'linear-initial.jsonl').read_text('utf8').splitlines()]
pool={r['target']:r for r in linear if r['maxfast']['result']=='FEASIBLE' and r['maxfast']['recipes']>1 and r['maxfast']['initial'] and all(int(n)>0 for n in r['maxfast']['initial'].values())}
pool=sorted(pool.values(),key=lambda r:(r['maxfast']['recipes'],r['target']))
random.Random(20261002).shuffle(pool);pool=pool[:400]
cases=[]
for i,r in enumerate(pool):
    inv=r['maxfast']['initial'];reduced=dict(inv)
    candidates=[k for k in inv if 'virtual_ingredient' not in k]
    if not candidates:continue
    k=min(candidates,key=lambda k:int(inv[k]));reduced[k]=str(int(inv[k])-1)
    for phase,s in [('funded',inv),('one-short',reduced),('restored',inv)]:
        cases.append(dict(id=f'tight-{i}-{phase}',target=r['target'],amount=r['amount'],stock=s,work=20_000_000,timeout=5000))
(area/'audit-tight-cases.json').write_text(json.dumps(cases),'utf8')
print('Formal limit retests',len(bad),'exact-stock linear cases',len(cases))
