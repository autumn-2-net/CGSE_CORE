import json,random,zipfile,sys,collections
from pathlib import Path
sys.stdout.reconfigure(encoding='utf8')
area=Path(__file__).resolve().parent
out=area/'server/local/random-order';out.mkdir(parents=True,exist_ok=True)
rng=random.Random(20261002)
with zipfile.ZipFile(area/'server/logs/ae-dump/ae-dump-muqjcnc6-60.zip') as z:
 network=json.loads(z.read('network.json'))
 resources={v['id']:v for v in map(json.loads,z.read('resources.jsonl').decode().splitlines())}
 multi=[resources[k]['snbt'] for k,v in network['producer_order'].items() if len(v)>1]
cases=[];seen=set()
def add(c):
 c={k:v for k,v in c.items() if k not in ('timeout','work')}
 if 'stock' not in c:
  sig=(c['target'],c['amount'])
  if sig in seen:return
  seen.add(sig)
 cases.append(c)
# Targeted small-cycle amounts, including the previously inconsistent item and fluids.
for typ,item in [('i','gtlcore:miracle_crystal'),('f','gtceu:miracle'),('f','gtceu:miracle_gas')]:
 for amount in (1,1000,9223372036854775807):
  add(dict(id=f'miracle-{item}-{amount}',target='{"#c":"ae2:'+typ+'",id:"'+item+'"}',amount=str(amount),verify_cache=True))
# All physical cycle members at the prior audit's two amounts.
for c in json.loads((area/'audit-cycle-cases.json').read_text('utf8')):add(c)
# Every output with multiple equal-priority primary producers.
for i,target in enumerate(multi):
 for amount in (1000,2000000):add(dict(id=f'alternative-{i}-{amount}',target=target,amount=str(amount),verify_cache=i<8))
# Broad pure linear targets, including fluid and item requests, deterministic sample.
linear=json.loads((area/'audit-linear-cases.json').read_text('utf8'))
targets=list(dict.fromkeys(c['target'] for c in linear));sample=set(rng.sample(targets,128))
for c in linear:
 if c['target'] in sample:add(c)
# Same inventory exactly funded, one unit short, and then restored.
tight=json.loads((area/'audit-tight-cases.json').read_text('utf8'))
group=rng.sample(range(len(tight)//3),64)
for i in group:
 for c in tight[i*3:i*3+3]:
  c['verify_cache']=i in group[:4]
  add(c)
orders=[dict(name='baseline',seed=0),dict(name='reversed',seed=-1)]+[dict(name=f'random-{s}',seed=s) for s in (20261002,731031,991117,424242)]+[dict(name='restored',seed=0)]
spec=dict(orders=orders,cases=cases)
(out/'cases.json').write_text(json.dumps(spec,ensure_ascii=False),'utf8')
smoke=dict(orders=[dict(name='smoke-base',seed=0),dict(name='smoke-random',seed=20261002)],cases=[cases[1],dict(id='linear-copper',target='{"#c":"ae2:i",id:"gtceu:double_copper_plate"}',amount='1000',stock={'{"#c":"ae2:i",id:"gtceu:copper_dust"}':'2000'},verify_cache=True)])
(out/'smoke.json').write_text(json.dumps(smoke),'utf8')
print('Random-order suite:',len(cases),'cases x',len(orders),'orders =',len(cases)*len(orders),'paired previews')
print('Categories',dict(collections.Counter(c['id'].split('-')[0] for c in cases)))
print('Extra warm/cold checks',sum(c.get('verify_cache',False) for c in cases)*len(orders))
