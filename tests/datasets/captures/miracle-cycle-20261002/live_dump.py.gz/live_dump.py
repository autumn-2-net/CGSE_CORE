from pathlib import Path
import json, re, shutil, socket, subprocess, threading, time, sys
sys.stdout.reconfigure(encoding='utf8',errors='replace')
root=Path.cwd().resolve(); area=root/'.local/miracle-cycle-20261002';server=area/'server'
assert server.is_relative_to(root)
with socket.socket() as sock: assert sock.connect_ex(('127.0.0.1',25580))!=0,'Port occupied'
shutil.copy2(area/'aedump_probe.js',server/'kubejs/server_scripts/zz_local_green_probe.js')
(server/'local/ae-probe').mkdir(parents=True,exist_ok=True)
cfg=server/'config/gtlcore.yaml'
cfg.write_text(cfg.read_text('utf8').replace('ae2GraphDiagnosticLogging: false','ae2GraphDiagnosticLogging: true'),'utf8')
commands=area/'commands.txt';commands.write_text('','utf8')
ready=threading.Event();out=(area/(sys.argv[1] if len(sys.argv)>1 else 'native-original.log')).open('w',encoding='utf8')
java=r'C:\Users\autumn\AppData\Roaming\.hmcl\java\windows-x86_64\mojang-java-runtime-delta\bin\java.exe'
p=subprocess.Popen([java,'-Xms512M','-Xmx6G','-Dfile.encoding=UTF-8','@libraries/net/minecraftforge/forge/1.20.1-47.4.16/win_args.txt','nogui'],cwd=server,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
print('Isolated actual-pack server PID',p.pid,flush=True)
def reader():
    for line in p.stdout:
        out.write(line);out.flush()
        if 'Done (' in line:ready.set()
        if any(s in line for s in ['[AE Dump]' ,'[Green Probe]','Done (','Mod loading error','Exception in thread']):print(line.rstrip(),flush=True)
t=threading.Thread(target=reader,daemon=True);t.start()
def command(c):p.stdin.write(c+'\n');p.stdin.flush()
try:
    start=time.monotonic()
    while not ready.wait(1):
        if p.poll() is not None:raise RuntimeError('Server exit '+str(p.returncode))
        if time.monotonic()-start>360:raise TimeoutError('Startup')
    # Restore loading of saved networks; this changes only the isolated copied world.
    chunks=json.loads((area/'chunks.json').read_text('utf8'))
    for c in chunks:
        if 'kubejs' not in c['region'] or 'void' not in c['region']:continue
        command('execute in kubejs:void run forceload add '+str(c['x']*16)+' '+str(c['z']*16))
    print('Sent chunk loading requests',len(chunks),flush=True)
    offset=0
    while p.poll() is None and time.monotonic()-start<2400:
        lines=commands.read_text('utf-8-sig').splitlines()
        for c in lines[offset:]:
            if c.strip():print('COMMAND',c,flush=True);command(c)
        offset=len(lines);time.sleep(.5)
finally:
    if p.poll() is None:
        command('stop')
        try:p.wait(timeout=45)
        except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=15)
    t.join(timeout=5);out.close();print('Server exit',p.returncode,flush=True)
