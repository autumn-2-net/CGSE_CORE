from pathlib import Path
import collections,json
area=Path(__file__).resolve().parent
removed=collections.Counter()
def key(value):
    if not value.startswith('{"#c":"ae2:'):return value
    fields=[];start=1;depth=0;quote=None;escape=False
    for i,c in enumerate(value[1:-1],1):
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in ['"',"'"]:quote=c
        elif c in '{[':depth+=1
        elif c in '}]':depth-=1
        elif c==',' and depth==0:fields.append(value[start:i]);start=i+1
    fields.append(value[start:-1]);keep=[]
    for f in fields:
        name=f.split(':',1)[0].strip('"')
        if name in ['#c','id','tag']:keep.append(f)
        else:
            assert name in ['real','#'],(name,value)
            removed[name]+=1
    return '{'+','.join(keep)+'}'
def transform(value):
    if isinstance(value,dict):
        out={key(k):transform(v) for k,v in value.items()};assert len(out)==len(value),'Key alias collision';return out
    if isinstance(value,list):return [transform(v) for v in value]
    if isinstance(value,str):return key(value)
    return value
for name in ['snapshot','fluid_snapshot','early-fluid-snapshot','fixed_fluid_snapshot']:
    source=json.loads((area/(name+'.json')).read_text('utf8'));normal=transform(source)
    (area/('normalized-'+name+'.json')).write_text(json.dumps(normal,ensure_ascii=False),'utf8')
    if 'compiled_selected' in normal:
        recipes={r['id']:r for r in normal['recipes']};queue=collections.deque([normal['target']]);seen=set();selected={}
        while queue:
            k=queue.popleft()
            if k in seen:continue
            seen.add(k);ids=normal['producers'].get(k,[])
            if ids:selected[k]=ids[0];queue.extend(s['key'] for s in recipes[ids[0]]['slots'])
        assert selected==normal['compiled_selected'],'Normalized replay differs from native compilation'
        print(name,'Native and replay selected keys match exactly:',len(selected))
print('Removed persisted amounts from key identity only',dict(removed))
