from pathlib import Path
import json,sys,time
area=Path(__file__).resolve().parent;bridge=area/'server/local/ae-probe';outdir=area/'server/local/ae-audit'
def send(req):
    (bridge/'request.json').write_text(json.dumps(req,ensure_ascii=False),'utf8')
    with (area/'commands.txt').open('a',encoding='utf8') as out:out.write('execute in kubejs:void run gc_audit\n')
    print('SENT',req['id'])
if sys.argv[1]=='prepare':send(dict(id='prepare',op='prepare'))
elif sys.argv[1]=='batch':
    path=Path(sys.argv[2]);send(dict(id=sys.argv[3],op='batch',cases=json.loads(path.read_text('utf8')),output=sys.argv[3]+'.jsonl'))
elif sys.argv[1]=='status':
    r=json.loads((bridge/'response.json').read_text('utf8'));print({k:v for k,v in r.items() if k not in ('recipes','stock','producers','targets','external')})
    for p in outdir.glob('*.jsonl'):
        rows=[json.loads(line) for line in p.read_text('utf8').splitlines() if line]
        from collections import Counter
        counts=Counter((x.get('maxfast',{}).get('result'),x.get('cgse',{}).get('result')) for x in rows)
        print(p.name,len(rows),dict(counts));print('last',rows[-1]['id'] if rows else '')
