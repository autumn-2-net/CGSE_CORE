from pathlib import Path
import subprocess,sys,os
area=Path(__file__).resolve().parent;repo=area.parent.parent
classes=area/'replay-classes';classes.mkdir(exist_ok=True)
original=area/'original-gtlcore.jar'
cp=os.pathsep.join([str(original),str(classes)]+[str(p) for p in (area/'server/libraries/com/google/code/gson').rglob('*.jar')])
java=Path(r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin')
if not sys.argv[1:] or sys.argv[1]=='compile':
    subprocess.run([str(java/'javac.exe'),'--release','17','-proc:none','-cp',cp,'-d',str(classes),str(area/'ReplayMiracle.java')],check=True)
    print('Compiled original-JAR replay');sys.exit(0)
args=['-ea','-Xmx3G']
for flag in ['work','memory','parallel']:
    if flag.upper() in os.environ:args.append('-D'+flag+'='+os.environ[flag.upper()])
if os.environ.get('CURRENT')=='1':cp=os.pathsep.join([str(repo/'build/classes/java/main'),cp])
if os.environ.get('DBG')=='1':cp=os.pathsep.join([str(repo/'.local/cgse-debug-20261002/build/classes/java/main'),cp])
if os.environ.get('EXPERIMENT')=='1':cp=os.pathsep.join([str(area/'experimental-classes'),cp])
args+=['-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.ReplayMiracle']+sys.argv[1:]
raise SystemExit(subprocess.run([str(java/'java.exe')]+args).returncode)
