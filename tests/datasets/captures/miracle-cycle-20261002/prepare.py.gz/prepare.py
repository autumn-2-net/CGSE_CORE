from pathlib import Path
import collections,gzip,hashlib,json,os,re,shutil,sys,tomllib,zipfile,zlib
sys.stdout.reconfigure(encoding='utf8')
root=Path.cwd().resolve();area=root/'.local/miracle-cycle-20261002';server=area/'server'
pack=Path('C:/Users/autumn/Desktop/CXXGTL/s33/.minecraft/versions/GregTech Leisure4234234234')
baseline=root/'.local/green-cell-20261002/server'
area.mkdir(parents=True,exist_ok=True);server.mkdir(exist_ok=True)
assert server.resolve().is_relative_to(root)
allowed=set();mods={};manifest=[]
for f in (baseline/'mods').glob('*.jar'):
    with zipfile.ZipFile(f) as z:
        if 'META-INF/mods.toml' in z.namelist():
            data=tomllib.loads(z.read('META-INF/mods.toml').decode('utf8'))
            allowed.update(m['modId'] for m in data.get('mods',[]))
allowed.add('extendedae_plus_gtladd')
for f in (pack/'mods').glob('*.jar'):
    with zipfile.ZipFile(f) as z:
        if 'META-INF/mods.toml' not in z.namelist():continue
        data=tomllib.loads(z.read('META-INF/mods.toml').decode('utf8'))
    for m in data.get('mods',[]):mods[m['modId']]=(f,data)
pending=list(allowed);chosen=set()
while pending:
    k=pending.pop()
    if k in chosen or k not in mods:continue
    f,data=mods[k];chosen.add(k)
    for dep in data.get('dependencies',{}).get(k,[]):
        if dep.get('mandatory') and dep.get('side')!='CLIENT':pending.append(dep['modId'])
(server/'mods').mkdir(exist_ok=True)
for f in {mods[k][0] for k in chosen}:
    shutil.copy2(f,server/'mods'/f.name)
    manifest.append(dict(file=f.name,ids=[k for k in chosen if mods[k][0]==f],sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
(area/'mods.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf8')
def link(src,dst):
    try:os.link(src,dst)
    except OSError:shutil.copy2(src,dst)
    return dst
if not (server/'libraries').exists():shutil.copytree(baseline/'libraries',server/'libraries',copy_function=link)
for name in ['config','defaultconfigs','kubejs']:
    if not (server/name).exists():shutil.copytree(pack/name,server/name)
world=next(w for w in (pack/'saves').iterdir() if (w/'level.dat').is_file())
def stable_copy(src,dst):
    for trial in range(4):
        before=Path(src).stat();shutil.copy2(src,dst);after=Path(src).stat()
        if before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns:return dst
    raise RuntimeError('World file changed during read: '+str(src))
if not (server/'world').exists():shutil.copytree(world,server/'world',copy_function=stable_copy,ignore=shutil.ignore_patterns('session.lock'))
print('Copied actual world and',len(manifest),'server mods',flush=True)
(area/'source.json').write_text(json.dumps(dict(world=str(world),core_sha256=hashlib.sha256((pack/'mods/gtlcore-1.2.3.2-fix3.jar').read_bytes()).hexdigest()),ensure_ascii=False,indent=2),'utf8')
props=(baseline/'server.properties').read_text('utf8')
for key,value in {'server-port':'25580','level-name':'world'}.items():props=re.sub(r'(?m)^'+key+'=.*$',key+'='+value,props)
(server/'server.properties').write_text(props,'utf8');(server/'eula.txt').write_text('eula=true\n','utf8')
scope={'__file__':str(root/'.local/save-cycle-fixture/inspect_save.py')}
exec((root/'.local/save-cycle-fixture/inspect_save.py').read_text('utf8').split('world = BASE/')[0],scope);NBT=scope['NBT']
level=NBT(gzip.decompress((server/'world/level.dat').read_bytes())).root()['Data']
print('Player',level.get('Player',{}).get('Pos'),level.get('Player',{}).get('Dimension'),flush=True)
entities=[];chunks=[]
region_dir=server/'world/dimensions/kubejs/void/region'
for region in region_dir.glob('*.mca'):
    blob=region.read_bytes()
    for i in range(1024):
        offset=int.from_bytes(blob[i*4:i*4+3],'big')*4096
        if not offset:continue
        length=int.from_bytes(blob[offset:offset+4],'big');method=blob[offset+4];data=blob[offset+5:offset+4+length]
        data=zlib.decompress(data) if method==2 else gzip.decompress(data) if method==1 else data
        # Skip empty generated chunks before materializing terrain arrays.
        if not any(s in data for s in [b'patternInventory',b'gtlcoreGraphJob',b'ae2:cable_bus',b'expatternprovider:ex_drive',b'extendedae_plus:']):continue
        chunk=NBT(data).root();es=chunk.get('block_entities',[])
        if es:chunks.append(dict(region=str(region.relative_to(server/'world')),x=chunk['xPos'],z=chunk['zPos']))
        for n in es:
            entities.append(dict(region=str(region.relative_to(server/'world')),nbt=n))
(area/'entities.json').write_text(json.dumps(entities,ensure_ascii=False),'utf8');(area/'chunks.json').write_text(json.dumps(chunks),'utf8')
patterns=[]
def walk(v,path):
    if isinstance(v,dict):
        if 'id' in v and 'pattern' in str(v['id']) and 'tag' in v:patterns.append(dict(path=path,stack=v))
        for k,n in v.items():walk(n,path+'/'+k)
    elif isinstance(v,list):
        for i,n in enumerate(v):walk(n,path+'/'+str(i))
for e in entities:
    n=e['nbt'];walk(n,n['id']+'@'+','.join(str(n.get(k)) for k in ['x','y','z']))
(area/'patterns.json').write_text(json.dumps(patterns,ensure_ascii=False),'utf8')
print('Entities',len(entities),'chunks',len(chunks),'patterns',len(patterns),flush=True)
for p in patterns:
    if 'miracle' in json.dumps(p['stack']):
        tag=p['stack'].get('tag',{});print('MIRACLE',p['path'],{k:[a for a in tag.get(k,[]) if a] for k in ['in','out']},flush=True)
present={e['nbt']['id'].split(':')[0] for e in entities}
missing=present-chosen-{'minecraft'}
print('Saved entity namespaces omitted',missing,flush=True)
for k in missing:
    if k in mods:
        f,data=mods[k];shutil.copy2(f,server/'mods'/f.name);print('Added saved entity mod',k,flush=True)
