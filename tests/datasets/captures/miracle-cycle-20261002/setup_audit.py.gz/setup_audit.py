from pathlib import Path
import subprocess,zipfile,shutil
root=Path.cwd().resolve();area=root/'.local/miracle-cycle-20261002';server=area/'server'
assert server.is_relative_to(root)
core=list((server/'mods').glob('gtlcore*.jar'));assert len(core)==1,core
shutil.copy2(area/'dist/gtlcore-1.2.3.2-fix3-cgse-miracle-fix-20261002.jar',core[0])
classes=area/'probe-classes'
cp=list((server/'mods').glob('*.jar'))+list((server/'libraries').rglob('*.jar'))
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',';'.join(str(p) for p in cp),'-d',str(classes),str(area/'NativeProbe.java'),str(area/'NetworkAudit.java')]
(area/'audit-javac.args').write_text('\n'.join('"'+x.replace('\\','/')+'"' for x in args),'utf8')
subprocess.run([r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin\javac.exe','@'+str(area/'audit-javac.args')],check=True)
with zipfile.ZipFile(server/'mods/local-miracle-probe.jar','w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('META-INF/mods.toml','modLoader="javafml"\nloaderVersion="[47,)"\nlicense="All Rights Reserved"\n[[mods]]\nmodId="localmiracleprobe"\nversion="0.0.0"\ndisplayName="Local exact AE snapshot probe"\n')
    for p in classes.rglob('*.class'):z.write(p,p.relative_to(classes).as_posix())
live=(area/'live.py').read_text('utf8').replace("area/'probe.js'","area/'audit_probe.js'").replace("'gc_probe'","'gc_audit'").replace("['[Green Probe]'","['[Network Audit]','[Green Probe]'").replace('start<2400','start<5400')
(area/'live_audit.py').write_text(live,'utf8')
print('Compiled local native audit helper; actual fixed production JAR installed only in copied server.')
