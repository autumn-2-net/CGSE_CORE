from pathlib import Path
import json,sys,collections
sys.stdout.reconfigure(encoding='utf8')
area=Path(__file__).resolve().parent;bridge=area/'server/local/ae-probe';out=area/'server/local/random-order'
if sys.argv[1]=='status':
 print('response',json.loads((bridge/'response.json').read_text('utf8')))
 for f in out.glob('*.jsonl'):
  if f.name=='orders.jsonl':continue
  rows=[json.loads(line) for line in f.read_text('utf8').splitlines() if line]
  print(f.name,len(rows),'last',[(r['order'],r['id']) for r in rows[-1:]])
  print('results',dict(collections.Counter((r['maxfast']['result'],r['cgse']['result']) for r in rows)))
  bad=[r for r in rows if ('warm' in r and any(r['warm'].get(k)!=r['cold'].get(k) for k in ('result','missing','initial','seeds','recipe_count','plan_hash'))) or r['cgse']['result']=='ERROR' or r['maxfast']['result']=='FEASIBLE' and not r['cgse']['result'].startswith('FEASIBLE')]
  print('flagged',[(r['order'],r['id'],r['cgse']['result'],r.get('cache_equal'),r['cgse'].get('error')) for r in bad][:20])
else:
 if sys.argv[1]=='load':req=dict(id='load-random',op='load',file='logs/ae-dump/ae-dump-muqjcnc6-60.zip')
 else:req=dict(id=sys.argv[2],op='batch',file='local/random-order/'+sys.argv[2]+'.json',output=sys.argv[2]+'.jsonl')
 (bridge/'request.json').write_text(json.dumps(req),'utf8')
 with (area/'commands.txt').open('a',encoding='utf8') as f:f.write('execute in kubejs:void run gc_random\n')
 print('SENT',req)
