from pathlib import Path
import subprocess,zipfile
root=Path.cwd().resolve();area=root/'.local/miracle-cycle-20261002';server=area/'server'
classes=area/'probe-classes';classes.mkdir(exist_ok=True)
cp=list((server/'mods').glob('*.jar'))+list((server/'libraries').rglob('*.jar'))
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',';'.join(str(p) for p in cp),'-d',str(classes),str(area/'NativeProbe.java')]
(area/'javac.args').write_text('\n'.join('"'+x.replace('\\','/')+'"' for x in args),'utf8')
subprocess.run([r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin\javac.exe','@'+str(area/'javac.args')],check=True)
with zipfile.ZipFile(server/'mods/local-miracle-probe.jar','w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('META-INF/mods.toml','modLoader="javafml"\nloaderVersion="[47,)"\nlicense="All Rights Reserved"\n[[mods]]\nmodId="localmiracleprobe"\nversion="0.0.0"\ndisplayName="Local exact AE snapshot probe"\n')
    for p in classes.rglob('*.class'):z.write(p,p.relative_to(classes).as_posix())
source=(root/'.local/green-cell-20261002/probe.js').read_text('utf8').replace('new Pos(99,80,-145)','new Pos(-2339,64,3444)')
source=source.replace("} else if (req.op == 'preview') {", "} else if (req.op == 'preview' || req.op == 'capture') {")
source=source.replace('var future = crafting.beginCraftingCalculation', "var future = req.op == 'capture' ? Java.loadClass('local.cgseprobe.NativeProbe').capture(level,grid,source,key) : crafting.beginCraftingCalculation")
source=source.replace('future:future,id:req.id,ticks:0','future:future,id:req.id,ticks:0,op:String(req.op)')
source=source.replace('var plan=s.future.get();var missing=[];', '''var plan=s.future.get();
            var info=s.op=='capture' ? String(plan) : String(Java.loadClass('local.cgseprobe.NativeProbe').describe(plan,s.future));
            var result=JSON.parse(info);result.id=s.id;if(s.op=='capture')result.ok=true;
            JsonIO.write('local/ae-probe/response.json',result);
            console.info('[Green Probe] completed '+s.id+' result='+result.result+' recipes='+(result.recipes?result.recipes.length:result.selected.length));
            global.greenProbePending=false;return;
            var missing=[];''')
source=source.replace("if (req.op == 'inspect') {", """if (req.op == 'keycache') {
                var k=Java.loadClass('appeng.api.stacks.AEItemKey')['of(net.minecraft.world.item.ItemStack)'](Item.of('minecraft:stick','{cgseProbe:"cache"}'));
                var fp=Java.loadClass('org.gtlcore.gtlcore.integration.ae2.graph.PatternFingerprint');
                var before=String(fp.key(k));var serialized=k.toTagGeneric();
                serialized.putLong('real',123456789);serialized.putLong('#',37);
                var after=String(fp.key(k));
                JsonIO.write('local/ae-probe/response.json',{id:req.id,ok:true,before:before,after:after,unchanged:before==after});
                console.info('[Green Probe] key cache unchanged='+(before==after));
            } else if (req.op == 'inspect') {""")
(area/'probe.js').write_text(source,'utf8')
runner=(root/'.local/green-cell-20261002/live.py').read_text('utf8').replace('.local/green-cell-20261002','.local/miracle-cycle-20261002').replace('25579','25580').replace("'flat' not in c['region']","'void' not in c['region']").replace('execute in kubejs:flat','execute in kubejs:void').replace("'Exception in thread','Graph Crafting'","'Exception in thread'")
(area/'live.py').write_text(runner,'utf8')
print('Exact Java snapshot/plan probe compiled')
