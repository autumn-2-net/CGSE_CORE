from pathlib import Path
import collections, gzip, hashlib, json, os, re, shutil, sys, zipfile, zlib

sys.stdout.reconfigure(encoding='utf8')
root = Path.cwd().resolve()
area = root / '.local/green-cell-20261002'
server = area / 'server'
pack = Path('C:/Users/autumn/Desktop/CXXGTL/s33/.minecraft/versions/GregTech Leisure312312312')
baseline = root / '.local/pattern-buffer-review-20260930/server'
server.mkdir(parents=True, exist_ok=True)
assert server.is_relative_to(root)

def mod_ids(p):
    with zipfile.ZipFile(p) as z:
        if 'META-INF/mods.toml' not in z.namelist(): return set()
        return set(re.findall(r'\[\[mods\]\][\s\S]*?modId\s*=\s*[\"\']([^\"\']+)', z.read('META-INF/mods.toml').decode('utf8', errors='replace')))

allowed = {'kotlinforforge', 'gtladditions'}
for p in (baseline/'mods').glob('*.jar'): allowed |= mod_ids(p)
manifest = []
(server/'mods').mkdir(exist_ok=True)
for p in (pack/'mods').glob('*.jar'):
    ids = mod_ids(p)
    if not (ids & allowed) and not p.name.startswith('kotlinforforge-'): continue
    shutil.copy2(p, server/'mods'/p.name)
    manifest.append(dict(file=p.name, ids=sorted(ids), sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(area/'mods.json').write_text(json.dumps(manifest, indent=2), 'utf8')
print('Actual instance server mods', len(manifest), flush=True)

def link(src,dst):
    try: os.link(src,dst)
    except OSError: shutil.copy2(src,dst)
    return dst

if not (server/'libraries').exists(): shutil.copytree(baseline/'libraries', server/'libraries', copy_function=link)
for name in ['config','defaultconfigs','kubejs']:
    if not (server/name).exists(): shutil.copytree(pack/name, server/name)
backups = list((pack/'backups').glob('*.zip'))
archive = max(backups,key=lambda p:p.stat().st_mtime)
world=server/'world'
if not world.exists():
    world.mkdir()
    with zipfile.ZipFile(archive) as z:
        level = next(n for n in z.namelist() if n.endswith('/level.dat'))
        prefix=level[:-len('level.dat')]
        for e in z.infolist():
            if not e.filename.startswith(prefix): continue
            name=e.filename[len(prefix):]
            if not name or name=='session.lock': continue
            dest=(world/name).resolve()
            assert dest.is_relative_to(world.resolve())
            if e.is_dir(): dest.mkdir(parents=True,exist_ok=True)
            else:
                dest.parent.mkdir(parents=True,exist_ok=True)
                with z.open(e) as src, dest.open('wb') as out: shutil.copyfileobj(src,out)
    (area/'backup.json').write_text(json.dumps(dict(file=str(archive), sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),indent=2),'utf8')
print('Restored',archive.name,flush=True)
props=(baseline/'server.properties').read_text('utf8')
for key,value in {'server-ip':'127.0.0.1','server-port':'25579','level-name':'world','online-mode':'false','enable-rcon':'false','enable-query':'false','view-distance':'2','simulation-distance':'2','max-tick-time':'-1','max-players':'1'}.items():
    props,n=re.subn(r'(?m)^'+re.escape(key)+'=.*$',key+'='+value,props)
    if not n:props+='\n'+key+'='+value+'\n'
(server/'server.properties').write_text(props,'utf8')
(server/'eula.txt').write_text('eula=true\n','utf8')

scope={'__file__':str(root/'.local/save-cycle-fixture/inspect_save.py')}
exec((root/'.local/save-cycle-fixture/inspect_save.py').read_text('utf8').split('world = BASE/')[0],scope)
NBT=scope['NBT']
level=NBT(gzip.decompress((world/'level.dat').read_bytes())).root()['Data']
print('Player',level.get('Player',{}).get('Pos'),level.get('Player',{}).get('Dimension'),flush=True)
entities=[];chunks=[]
for region in world.rglob('*.mca'):
    if region.parent.name!='region':continue
    blob=region.read_bytes()
    for i in range(1024):
        offset=int.from_bytes(blob[i*4:i*4+3],'big')*4096
        if not offset:continue
        length=int.from_bytes(blob[offset:offset+4],'big');method=blob[offset+4]
        data=blob[offset+5:offset+4+length]
        if method==2:data=zlib.decompress(data)
        elif method==1:data=gzip.decompress(data)
        elif method!=3:raise ValueError(method)
        chunk=NBT(data).root();es=chunk.get('block_entities',[])
        if es: chunks.append(dict(region=str(region.relative_to(world)),x=chunk['xPos'],z=chunk['zPos']))
        for n in es:entities.append(dict(region=str(region.relative_to(world)),nbt=n))
(area/'entities.json').write_text(json.dumps(entities,ensure_ascii=False),'utf8')
(area/'chunks.json').write_text(json.dumps(chunks,ensure_ascii=False),'utf8')
print('Entities',len(entities),collections.Counter(e['nbt']['id'] for e in entities).most_common(12))
for e in entities:
    n=e['nbt'];txt=json.dumps(n)
    if 'cosmic_neutron_plasma_cell' in txt:
        print('CELL',e['region'],n['id'],[n.get(k) for k in ['x','y','z']],len(txt))
with zipfile.ZipFile(pack/'mods/gtlcore-1.2.3.2-fix3.jar') as old,zipfile.ZipFile(root/'build/libs/gtlcore-1.2.3.2-fix3.jar') as current:
    names=[n for n in current.namelist() if '/ae2/graph/' in n and n.endswith('.class')]
    changed=[n for n in names if n not in old.namelist() or old.read(n)!=current.read(n)]
    print('Graph classes differ from current',len(changed),'/',len(names))
    (area/'class-diff.json').write_text(json.dumps(changed,indent=2),'utf8')
