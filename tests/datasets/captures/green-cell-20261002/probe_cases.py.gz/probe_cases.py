from pathlib import Path
import json,time,shutil
area=Path(__file__).resolve().parent
bridge=area/'server/local/ae-probe'
network=json.loads((area/'runtime-network.json').read_text('utf8'))
cases=[('empty229','kubejs:plasma_containment_cell','229'),('sphere56','kubejs:neutronium_sphere','56'),('proton2845000','gtceu:free_proton_gas','2845000')]
for name,item,amount in cases:
    snbt=next(o['key']['snbt'] for r in network['patterns'] for o in r['outputs'] if o['key']['id']==item)
    (bridge/'request.json').write_text(json.dumps(dict(id=name,op='preview',snbt=snbt,amount=amount)),'utf8')
    with (area/'commands.txt').open('a',encoding='utf8') as out:out.write('execute in kubejs:flat run gc_probe\n')
    start=time.monotonic()
    while time.monotonic()-start<180:
        try:d=json.loads((bridge/'response.json').read_text('utf8'))
        except (OSError,ValueError):d={}
        if d.get('id')==name:
            shutil.copy2(bridge/'response.json',area/(name+'.json'))
            print(name,d,flush=True);break
        time.sleep(.2)
    else:raise TimeoutError(name)
