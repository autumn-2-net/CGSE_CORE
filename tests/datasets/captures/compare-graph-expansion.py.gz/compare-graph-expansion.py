from pathlib import Path
import re, json, statistics, sys

def parse(path):
    raw=Path(path).read_bytes()
    text=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig', errors='replace')
    latest={}
    records={}
    for line in text.splitlines():
        if '[Graph Crafting] plan result=' in line:
            latest=dict(re.findall(r'(\w+)=([^ ]+)',line))
        if '[Graph Stress] label=' in line:
            values=dict(re.findall(r'(\w+)=([^ ]*)',line))
            label=values['label']; sample=int(values['sample'])
            record={k:float(v) for k,v in {**latest,**values}.items() if k.endswith('_ms')}
            record.update(sample=sample,graph_valid=values['graph_valid']=='true',cache_hit=latest.get('cache_hit'),
                          old_valid=values['old_valid']=='true',graph_raw=int(values['graph_raw']),graph_bytes=int(values['graph_bytes']),
                          parallel_batches=int(latest.get('catalog_parallel_batches','0')))
            records.setdefault(label,[]).append(record)
    return records

before=parse(sys.argv[1]); after=parse(sys.argv[2])
out={'before':before,'after':after}
Path(sys.argv[3]).write_text(json.dumps(out,indent=2),encoding='utf-8')
for label,rows in after.items():
    a=rows[0]; b=before.get(label,[None])[0]
    if b is None: continue
    print(label, 'valid=',all(x['graph_valid'] for x in rows),'raw/bytes=',(a['graph_raw'],a['graph_bytes'])==(b['graph_raw'],b['graph_bytes']))
    for k in ['graph_wall_ms','snapshot_ms','snapshot_elapsed_ms','snapshot_wait_ms','catalog_prepare_ms','catalog_elapsed_ms']:
        print(' ',k,round(b.get(k,0),3),'->',round(a.get(k,0),3))
