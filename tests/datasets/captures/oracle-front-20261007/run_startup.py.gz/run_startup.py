from pathlib import Path
import subprocess,sys
root=Path.cwd().resolve();area=root/'.local/oracle-front-20261007';stage=root/'.local/mixed-jei-fix-20261007'/sys.argv[1]
cp=(stage/'classpath.txt').read_text('utf8');classes=area/('startup-'+stage.name);classes.mkdir(exist_ok=True);java='C:/Users/autumn/.jdks/corretto-20.0.2.1/bin/'
subprocess.run([java+'javac.exe','--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(classes),str(area/'StartupCutProbe.java')],check=True)
command=[java+'java.exe','-Xmx2g','-cp',str(classes)+';'+cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.StartupCutProbe',str(area/'finite-cases.json'),str(classes/'startup.cgproof')]
run=subprocess.run(command,capture_output=True,text=True);(classes/'result.log').write_text(run.stdout+run.stderr,'utf8');print(run.stdout+run.stderr,flush=True);raise SystemExit(run.returncode)
