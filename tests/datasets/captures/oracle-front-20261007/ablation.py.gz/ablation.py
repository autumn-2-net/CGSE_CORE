from pathlib import Path
import json,hashlib,subprocess,sys,shutil
root=Path.cwd().resolve();area=root/'.local/mixed-jei-fix-20261007';base=area/sys.argv[1];stage=area/sys.argv[2]
shutil.copytree(base/'core',stage/'core');core=stage/'core'
for mode in sys.argv[3:]:
 if mode=='no-quantity':
  p=core/'GraphStockViewPortfolio.java';s=p.read_text('utf8').replace('0, 4, 5, 3, 2, 1, 8, 9','0, 4, 5, 3, 2, 1').replace('if (quantitativeAdded) return false;', 'if (views.size() >= 0) return false;');p.write_text(s,'utf8')
 elif mode=='no-ratio':
  p=core/'RegionSelection.java';s=p.read_text('utf8').replace('region.cyclic() && recipes.size() <= 6 && !ratioCanAdvance()','false && !ratioCanAdvance()');p.write_text(s,'utf8')
 elif mode=='combined-account':
  p=core/'PlanningBudget.java';s=p.read_text('utf8').replace('chargeTicks(WORK_SCALE, true);','chargeTicks(WORK_SCALE, false);').replace('chargeTicks(Operation.SCAN.ticks, true);','chargeTicks(Operation.SCAN.ticks, false);').replace('chargeTicks(units * WORK_SCALE, true);','chargeTicks(units * WORK_SCALE, false);');p.write_text(s,'utf8')
 elif mode=='no-topology':
  p=core/'GraphCompilation.java';s=p.read_text('utf8').replace('recipes.size() >= 2 && recipes.size() <= 16384','false');p.write_text(s,'utf8')
 elif mode=='no-neighborhood':
  p=core/'GraphStockViewWork.java';s=p.read_text('utf8').replace('if (neighborhood != null) neighborhood.offer(graph, candidate);','');p.write_text(s,'utf8')
 elif mode=='profile-families':
  p=core/'GraphStockViewPortfolio.java';s=p.read_text('utf8').replace('for (var view : views) view.close();','System.out.println("PORT_CLOSE work=" + work + " original=" + original.work + " quantity=" + quantitative.work + " live=" + original.live + "," + quantitative.live); for (var view : views) view.close();');p.write_text(s,'utf8')
  p=core/'GraphStockViewWork.java';s=p.read_text('utf8').replace('if (fork != null) fork.close();','System.out.println("VIEW_CLOSE " + target + " variant=" + variant + " work=" + work + " rounds=" + rounds + " missing=" + missingKeys + " estimate=" + estimatedRepairCost()); if (fork != null) fork.close();');p.write_text(s,'utf8')
 else: raise ValueError(mode)
gson=root/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'
for name in ['MixedSweep.java','MinimizeStress.java','ReducedOrderProbe.java']:shutil.copy2(base/name,stage/name)
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',str(gson),'-d',str(stage/'classes'),*[str(p) for p in core.glob('*.java')],*[str(p) for p in stage.glob('*.java')]]
(stage/'javac.args').write_text('\n'.join('"'+s.replace('\\','/')+'"' for s in args),'utf8')
subprocess.run(['C:/Users/autumn/.jdks/corretto-20.0.2.1/bin/javac.exe','@'+str(stage/'javac.args')],check=True)
(stage/'classpath.txt').write_text(str(stage/'classes')+';'+str(gson),'utf8')
(stage/'source-hashes.json').write_text(json.dumps([dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(core.glob('*.java'))],indent=2),'utf8')
print('compiled ablation',stage.name,sys.argv[3:],flush=True)
