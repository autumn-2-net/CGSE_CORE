from pathlib import Path
import subprocess, sys
root=Path.cwd().resolve();area=root/'.local/oracle-front-20261007'
stage=root/'.local/mixed-jei-fix-20261007'/sys.argv[1]
cp=(stage/'classpath.txt').read_text('utf8')
classes=area/('probe-'+stage.name);classes.mkdir(exist_ok=True)
java=Path('C:/Users/autumn/.jdks/corretto-20.0.2.1/bin')
subprocess.run([str(java/'javac.exe'),'--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(classes),str(area/'WorkAccountingProbe.java')],check=True)
subprocess.run([str(java/'java.exe'),'-cp',str(classes)+';'+cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.WorkAccountingProbe',*sys.argv[2:]],check=True)
