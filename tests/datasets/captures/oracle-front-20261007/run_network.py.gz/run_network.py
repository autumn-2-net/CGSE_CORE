from pathlib import Path
import subprocess,sys
root=Path.cwd().resolve();area=root/'.local/oracle-front-20261007';label=sys.argv[1]
family=sys.argv[2] if len(sys.argv)>2 else 'finite'
stage=root/'.local/mixed-jei-fix-20261007'/label;cp=(stage/'classpath.txt').read_text('utf8')
classes=area/('network-'+label);classes.mkdir(exist_ok=True)
java=Path('C:/Users/autumn/.jdks/corretto-20.0.2.1/bin')
subprocess.run([str(java/'javac.exe'),'--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(classes),str(area/'NetworkOracleProbe.java')],check=True)
output=area/(family+'-'+label+'.jsonl')
if output.exists():raise FileExistsError(output)
subprocess.run([str(java/'java.exe'),'-Xmx2G','-XX:ActiveProcessorCount=2','-cp',str(classes)+';'+cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.NetworkOracleProbe',str(area/(family+'-cases.json')),str(output)],check=True)
