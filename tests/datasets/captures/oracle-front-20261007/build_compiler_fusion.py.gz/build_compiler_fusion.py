from pathlib import Path
import os, subprocess

root = Path.cwd().resolve()
paths = subprocess.check_output(['git', 'diff', '--name-only', '--', 'src/main/java'], text=True).splitlines()
paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'src/main/java'], text=True).splitlines()
(root / '.local/graph-format-targets.txt').write_text('\n'.join(sorted(set(paths))) + '\n', 'utf8')
env = os.environ.copy()
env['JAVA_HOME'] = 'C:/Users/autumn/.jdks/corretto-20.0.2.1'
log = root / '.local/oracle-front-20261007/compiler-fusion-delivery-build.log'
with log.open('w', encoding='utf8') as output:
    result = subprocess.run([str(root / 'gradlew.bat'), '--offline', '--no-daemon',
                             '--gradle-user-home', '../core/.gradle-user-home',
                             '-I', '.local/use-cached-mappings.init.gradle', '-I', 'tools/graph-tests.init.gradle',
                             'spotlessApply', 'graphCoreTest', 'graphIntegrationTest', 'build'],
                            cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT)
print('Build exit', result.returncode, 'log', log, flush=True)
raise SystemExit(result.returncode)
