from pathlib import Path
import subprocess,sys
root=Path.cwd();area=root/'.local/oracle-front-20261007';stage=root/'.local/mixed-jei-fix-20261007'/sys.argv[1]
cp=(stage/'classpath.txt').read_text('utf8');out=area/('fusion-'+stage.name);out.mkdir(exist_ok=True)
java='C:/Users/autumn/.jdks/corretto-20.0.2.1/bin/'
subprocess.run([java+'javac.exe','--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(out),str(area/'CompilerFusionProbe.java')],check=True)
run=subprocess.run([java+'java.exe','-ea','-Xmx2g','-cp',str(out)+';'+cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.CompilerFusionProbe'],capture_output=True,text=True)
(out/'result.log').write_text(run.stdout+run.stderr,'utf8');print(run.stdout+run.stderr,flush=True);raise SystemExit(run.returncode)
