from pathlib import Path
import sys,shutil,subprocess,json,hashlib
root=Path.cwd(); area=root/'.local/mixed-jei-fix-20261007'
stage=area/sys.argv[1]; mode=sys.argv[2]
baseline='oracle-stable-v27' if mode=='lazy-prune' else 'oracle-prune-v24'
shutil.copytree(area/baseline/'core',stage/'core')
core=stage/'core'
if mode=='no-prune':
 p=core/'GraphPlanningWork.java';s=p.read_text('utf8')
 a=s.index('            if (!startupPruned) {');b=s.index('            // A cheap ordinary alternative',a)
 s=s[:a]+s[b:];p.write_text(s,'utf8')
elif mode=='original-labels':
 p=core/'GraphCompiler.java';s=p.read_text('utf8');at=s.index('\n',s.index('public final class GraphCompiler'))
 s=s[:at]+ '\n    GraphCompiler<K> rankingCompiler = this;\n' +s[at:];p.write_text(s,'utf8')
 p=core/'GraphStartupPruning.java';s=p.read_text('utf8').replace('        complete = true;\n        budget.note("startup_pruning", "recipes="','        result.rankingCompiler = original;\n        complete = true;\n        budget.note("startup_pruning", "recipes="');p.write_text(s,'utf8')
 p=core/'GraphSourceRanking.java';s=p.read_text('utf8').replace('GraphSourceIndex.create(compiler, budget','GraphSourceIndex.create(compiler.rankingCompiler, budget')
 # The backward ranking is also only a heuristic label calculation.
 a=s.index('    private void prepare()');b=s.index('    List<GraphRecipe<K>>',a)
 s=s[:a]+s[a:b].replace('compiler.producers(key)','compiler.rankingCompiler.producers(key)')+s[b:];p.write_text(s,'utf8')
elif mode=='lazy-prune':
 p=core/'GraphPlanningWork.java';s=p.read_text('utf8')
 a=s.index('            if (!startupPruned) {');b=s.index('            // A cheap ordinary alternative',a)
 s=s[:a]+s[b:]
 marker='''                    solving.close();
                    solving = null;
                    if (!candidate.feasible() && !stockViewTried'''
 replacement='''                    solving.close();
                    solving = null;
                    if (!startupPruned && !candidate.feasible() && nesting == 0 && compiler.catalog().size() > 8192) {
                        startupPruned = true;
                        startupPruning = new GraphStartupPruning<>(compiler, target, stock, external, requiredSeeds.keySet(), excluded, budget);
                        phase = 20;
                    } else phase = 21;
                    return false;
                }
                case 20 -> {
                    if (!startupPruning.step()) return false;
                    var reduced = startupPruning.result();
                    if (reduced == compiler) phase = 21;
                    else {
                        compiler = reduced;
                        budget.release(graphMemory);
                        graphMemory = 0;
                        graph = null;
                        candidate = null;
                        seen.clear();
                        sourceAttempts = 0;
                        choices = Map.of();
                        pending.add(Map.of());
                        phase = 0;
                    }
                    return false;
                }
                case 21 -> {
                    if (!candidate.feasible() && !stockViewTried'''
 assert marker in s;s=s.replace(marker,replacement,1);p.write_text(s,'utf8')
else:raise ValueError(mode)
gson=root/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'
for name in ['MixedSweep.java','MinimizeStress.java','ReducedOrderProbe.java']:
 shutil.copy2(area/'oracle-prune-v24'/name,stage/name)
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',str(gson),'-d',str(stage/'classes'),*[str(p) for p in core.glob('*.java')],*[str(p) for p in stage.glob('*.java')]]
(stage/'javac.args').write_text('\n'.join('"'+x.replace('\\','/')+'"' for x in args),'utf8')
subprocess.run(['C:/Users/autumn/.jdks/corretto-20.0.2.1/bin/javac.exe','@'+str(stage/'javac.args')],check=True)
(stage/'classpath.txt').write_text(str((stage/'classes').resolve())+';'+str(gson.resolve()),'utf8')
(stage/'source-hashes.json').write_text(json.dumps([dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(core.glob('*.java'))],indent=2),'utf8')
print('compiled',stage,mode,flush=True)
