from pathlib import Path
import concurrent.futures, json, random, subprocess, sys, time

root = Path.cwd().resolve()
area = root / '.local/mixed-jei-fix-20261007'
stage = area / sys.argv[1]
fixtures = root / '.local/mixed-jei-stress-20261007'
java = 'C:/Users/autumn/.jdks/corretto-20.0.2.1/bin/'
classpath = (stage / 'classpath.txt').read_text('utf8')
runs = stage / 'cache-orders'
runs.mkdir(exist_ok=True)
source = (area / 'SubsetSweep.java').read_text('utf8').replace('class SubsetSweep', 'class CacheOrderSweep')
source = source.replace('var row=MixedSweep.solve',
    'if(config.has("cold") && config.get("cold").getAsBoolean()) compiler=new GraphCompiler<>(catalog,producers); var row=MixedSweep.solve')
source_path = stage / 'CacheOrderSweep.java'
source_path.write_text(source, 'utf8')
subprocess.run([java + 'javac.exe', '--release', '17', '-proc:none', '-encoding', 'UTF-8',
                '-cp', classpath, '-d', str(stage / 'classes'), str(source_path)], check=True)
cases = []
for label in ['interleave-0p25-s73', 'interleave-0p9-s73']:
    source_config = stage / 'subset-cases' / (label + '.json')
    if not source_config.exists(): source_config = area / 'subset-cases' / (label + '.json')
    original = json.loads(source_config.read_text('utf8'))
    for order in ['reverse', 'shuffle', 'cold']:
        config = json.loads(json.dumps(original))
        if order == 'reverse':
            config['requests'].reverse()
        elif order == 'shuffle':
            random.Random(20261007).shuffle(config['requests'])
        else:
            config['cold'] = True
            ids = {'focus-' + str(i) for i in [26, 29, 46, 47, 49, 55, 60]}
            config['requests'] = [r for r in config['requests'] if r['id'] in ids]
        name = label + '-' + order
        path = runs / (name + '.config.json')
        path.write_text(json.dumps(config), 'utf8')
        cases.append((name, path))

def run(case):
    name, config = case
    output, log = runs / (name + '.jsonl'), runs / (name + '.log')
    assert not output.exists(), name
    started = time.monotonic()
    with log.open('w', encoding='utf8') as stream:
        result = subprocess.run([java + 'java.exe', '-Xmx3G', '-XX:ActiveProcessorCount=2',
                                 '-cp', classpath, 'org.gtlcore.gtlcore.integration.ae2.graph.core.CacheOrderSweep',
                                 str(fixtures), str(config), str(output)],
                                stdout=stream, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    rows = [json.loads(line) for line in output.read_text('utf8').splitlines()]
    info = dict(label=name, exit=result.returncode, seconds=round(time.monotonic() - started, 3),
                cases=len(rows), feasible=sum(r['feasible'] for r in rows))
    (runs / (name + '-run.json')).write_text(json.dumps(info, indent=2), 'utf8')
    print(info, flush=True)
    return info

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    results = list(executor.map(run, cases))
assert all(r['exit'] == 0 for r in results), results
