from collections import Counter
from pathlib import Path
import hashlib, json, shutil, subprocess

root = Path.cwd().resolve()
area = root / '.local/mixed-jei-fix-20261007'
oracle = root / '.local/oracle-front-20261007'
stage = area / 'compiler-fusion-boundary-v49'
formatted = area / 'compiler-fusion-checked-v50'
baseline = area / 'oracle-backend-final-v31'
source = root / 'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core'
delivery = oracle / 'compiler-fusion-delivery'
delivery.mkdir(exist_ok=True)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return [json.loads(line) for line in path.read_text('utf8').splitlines()]

def summary(rows):
    return dict(requests=len(rows), feasible=sum(r['feasible'] for r in rows),
                results=dict(Counter(r['result'] for r in rows)), work=sum(r['work'] for r in rows),
                search_work=sum(r.get('search_work', r.get('metrics', {}).get('searchWork', 0)) for r in rows),
                compilation_work=sum(r.get('compilation_work', r.get('metrics', {}).get('compilationWork', 0)) for r in rows),
                peak_bytes=max(r['peak_bytes'] for r in rows))

def compare(folder, labels, expected_count=None):
    current, old, gains, losses, groups = [], [], [], [], {}
    for label in labels:
        rows = read(stage / folder / (label + '.jsonl'))
        previous = read(baseline / folder / (label + '.jsonl'))
        assert len(rows) == len(previous), label
        if expected_count is not None:
            assert len(rows) == expected_count, label
        key = lambda r: (r['id'], r['mode'], r['seed'], r.get('fraction'))
        previous_by_id = {key(r): r for r in previous}
        assert len(previous_by_id) == len(rows)
        for r in rows:
            before = previous_by_id[key(r)]
            for field in ('target', 'amount', 'catalog_sha256', 'sources_sha256', 'work_limit', 'memory_limit'):
                if field in r:
                    assert r[field] == before[field], (label, r['id'], field)
            assert r['result'] != 'ERROR' and r.get('reserved_after_close', 0) == 0, (label, r)
            assert not r['feasible'] or r.get('verified') is True, (label, r)
            if r['feasible'] and not before['feasible']:
                gains.append(dict(label=label, id=r['id'], previous=before['result']))
            if before['feasible'] and not r['feasible']:
                losses.append(dict(label=label, id=r['id'], result=r['result']))
        groups[label] = dict(current=summary(rows), baseline=summary(previous))
        current.extend(rows)
        old.extend(previous)
    # Every catalog in these matrices retains all handwritten patterns.
    known = {r['target'] + ':' + str(r['amount']) for r in current + old if r['mode'] == 'manual' and r['feasible']}
    contradictions = [r for r in current if r['target'] + ':' + str(r['amount']) in known and
                      r['result'] in ('INFEASIBLE', 'MISSING_INPUT', 'MISSING_SEED')]
    assert not contradictions, contradictions
    return dict(current=summary(current), baseline=summary(old), gained=gains, lost=losses, groups=groups,
                known_feasible_false_negatives=len(contradictions))

manifest = json.loads((formatted / 'source-hashes.json').read_text('utf8'))
assert {p.name for p in source.glob('*.java')} == {r['file'] for r in manifest}
for row in manifest:
    assert sha(source / row['file']) == row['sha256'], row['file']
    assert ''.join((stage / 'core' / row['file']).read_text('utf8').split()) == ''.join((source / row['file']).read_text('utf8').split()), row['file']
changed = [p.name for p in sorted((stage / 'core').glob('*.java')) if
           not (baseline / 'core' / p.name).exists() or p.read_text('utf8') != (baseline / 'core' / p.name).read_text('utf8')]
for name in ['GraphFallback.java', 'GraphFallbackSearch.java', 'GraphFallbackSources.java']:
    assert (source / name).read_text('utf8') == (baseline / 'core' / name).read_text('utf8'), name
assert not (source / 'GraphStartupPruning.java').exists()
assert sha(root / 'build.gradle') == 'a17e1b46f2642be5c470eb3c130e02606b194574fefe08c5cccf229af8b8f9c0'

primary = compare('runs', ['manual-default', 'virtual-manual-first', 'virtual-extra-first', 'virtual-random'], 192)
labels = json.loads((area / 'subset-cases/manifest.json').read_text('utf8'))['labels']
subsets = compare('subsets', labels, 128)
parallel = compare('parallel', ['w1-fixed', 'w2-fixed', 'w4-fixed', 'w2-expanded', 'w4-expanded'], 60)
cache_orders = compare('cache-orders', [label + '-' + order for label in ['interleave-0p25-s73', 'interleave-0p9-s73']
                                      for order in ['reverse', 'shuffle', 'cold']])
for name, data in [('primary', primary), ('subsets', subsets), ('parallel', parallel), ('cache_orders', cache_orders)]:
    assert not data['lost'], (name, data['lost'])

subprocess.run(['python', str(area / 'final_parallel_report.py'), stage.name], check=True)
parallel_detail = json.loads((stage / 'final-parallel-report.json').read_text('utf8'))
assert len(parallel_detail['reduced']) == 10 and all(r['result'] == 'FEASIBLE' for r in parallel_detail['reduced'])

native = {}
native_stage = stage.name
for p in (stage / 'core').glob('*.java'):
    # Spotless was the only change between the native matrix and final freeze.
    assert ''.join(p.read_text('utf8').split()) == ''.join((area / native_stage / 'core' / p.name).read_text('utf8').split()), p.name
for name, count in [('finite', 3072), ('cover', 1152)]:
    rows = read(oracle / (name + '-' + native_stage + '.jsonl'))
    assert len(rows) == count and all(r['result'].startswith('FEASIBLE') == r['expected'] for r in rows)
    assert all(r['result'] in ('FEASIBLE', 'FEASIBLE_NOT_PROVEN_OPTIMAL', 'INFEASIBLE', 'MISSING_INPUT', 'MISSING_SEED') for r in rows)
    native[name] = dict(cases=count, results=dict(Counter(r['result'] for r in rows)),
                        oracle=json.loads((oracle / (name + '-oracle-summary.json')).read_text('utf8')))

startup = (oracle / ('startup-' + stage.name) / 'result.log').read_text('utf8')
fusion = (oracle / ('fusion-' + stage.name) / 'result.log').read_text('utf8')
assert 'PASS supports=8192 learned_cuts=6651 independently_explored_states=12649' in startup
assert 'PASS compiler-fusion' in fusion
buildlog = oracle / 'compiler-fusion-delivery-build.log'
assert 'BUILD SUCCESSFUL' in buildlog.read_text('utf8', errors='replace')
live = json.loads((root / '.local/review-completion-20261004/compiler-fusion-v50-live-result.json').read_text('utf8'))
assert live['passed'] and live['exit'] == 0, live
installed = json.loads((oracle / 'live-core-v50.json').read_text('utf8'))
jar = root / 'build/libs/gtlcore-1.2.3.2-fix3.jar'
assert sha(jar) == installed['sha256']
jar_out = delivery / 'gtlcore-1.2.3.2-fix3-cgse-compiler-fusion-20261007.jar'
shutil.copy2(jar, jar_out)
(delivery / (jar_out.name + '.sha256')).write_text(sha(jar_out) + '  ' + jar_out.name + '\n', 'utf8')

report = dict(
    stage=stage.name, formatted_build=formatted.name, baseline=baseline.name,
    scope=dict(frontend='Bounded immutable SCC topology reuse, no recipe pruning.',
               budgets='Structural capture/compilation and search each receive the configured limit. Memory, time and cancellation remain shared.',
               backend='Quantitative source ordering, exact positive support fusion, early rejection of zero-progress small-loop ratios.',
               scheduling='Independent family cursors and bounded exploration; search-only continuation clocks; resumable bootstrap preemption; complete region candidates before handoff; residual-aware shrinking tail wait.',
               modified_core_files=changed, source_manifest=manifest, build_gradle_preserved=True,
               fallback_unchanged_this_batch=True, not_committed_or_pushed=True),
    inputs=dict(handwritten_patterns=5903, jei_virtual_patterns=62284, total_patterns=68187, stock_keys=2670),
    primary=primary, subsets=subsets, parallel=parallel, parallel_detail=parallel_detail, cache_orders=cache_orders,
    native_differential=native, startup_validation=startup, compiler_fusion_validation=fusion,
    build=dict(status='SUCCESS', log=str(buildlog), sha256=sha(buildlog)), live=live,
    artifact=dict(file=str(jar_out), sha256=sha(jar_out), bytes=jar_out.stat().st_size),
    limitations=[
        'The configured search allowance is unchanged, but compilation now has an additional separate allowance. Total actual work is reported and may increase.',
        'Finite budgets and heuristic ordering can still yield SEARCH_LIMIT. No claim of order-invariant completeness or CP-SAT/SCIP parity.',
        'Native differential uses finite executable oracles and exact integer cover instances; external relaxed SAT alone is not an executable witness.',
        'Parallel timing is one unwarmed pass under local machine load; no speedup claim.',
        'Live tests use an isolated Forge server with native AE providers, crafting CPU and storage events; no original user save was modified.',
    ])
(delivery / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), 'utf8')
for name in ['primary', 'subsets', 'parallel', 'cache_orders']:
    value = report[name]
    print(name, json.dumps(dict(current=value['current'], baseline=value['baseline'], gained=len(value['gained']), lost=value['lost'])))
print('ARTIFACT', json.dumps(report['artifact']))
