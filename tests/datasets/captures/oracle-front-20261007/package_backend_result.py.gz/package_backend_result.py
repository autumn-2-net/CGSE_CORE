from collections import Counter
from pathlib import Path
import hashlib
import json
import shutil
import subprocess


root = Path.cwd().resolve()
area = root / '.local/mixed-jei-fix-20261007'
oracle = root / '.local/oracle-front-20261007'
stage = area / 'oracle-backend-final-v31'
baseline = area / 'final-v22'
source = root / 'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core'
delivery = oracle / 'delivery'
delivery.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return [json.loads(line) for line in path.read_text('utf8').splitlines()]


def summary(rows):
    return {
        'requests': len(rows),
        'feasible': sum(row['feasible'] for row in rows),
        'results': dict(Counter(row['result'] for row in rows)),
        'work': sum(row['work'] for row in rows),
        'peak_bytes': max(row['peak_bytes'] for row in rows),
    }


def compare(folder, labels, count, identity):
    groups = {}
    all_rows = []
    old_rows = []
    gained, lost = [], []
    for label in labels:
        rows = read(stage / folder / (label + '.jsonl'))
        previous = read(baseline / folder / (label + '.jsonl'))
        assert len(rows) == len(previous) == count, label
        old = {row['id']: row for row in previous}
        for row in rows:
            before = old[row['id']]
            for key in identity:
                assert row[key] == before[key], (label, row['id'], key)
            assert row['result'] != 'ERROR', (label, row)
            assert not row['feasible'] or row.get('verified') is True, (label, row)
            if row['feasible'] and not before['feasible']:
                gained.append({'label': label, 'id': row['id'], 'previous': before['result']})
            if before['feasible'] and not row['feasible']:
                lost.append({'label': label, 'id': row['id'], 'result': row['result']})
        groups[label] = {'current': summary(rows), 'baseline': summary(previous)}
        all_rows.extend(rows)
        old_rows.extend(previous)
    known = {row['id'] for row in all_rows + old_rows if row['mode'] == 'manual' and row['feasible']}
    contradictions = [row for row in all_rows if row['id'] in known and row['result'] in
                      ('INFEASIBLE', 'MISSING_INPUT', 'MISSING_SEED')]
    assert not contradictions, contradictions
    assert not lost, lost
    return {'current': summary(all_rows), 'baseline': summary(old_rows),
            'gained': gained, 'lost': lost, 'known_feasible_false_negatives': len(contradictions),
            'groups': groups}


manifest = json.loads((stage / 'source-hashes.json').read_text('utf8'))
assert {p.name for p in source.glob('*.java')} == {row['file'] for row in manifest}
for row in manifest:
    assert sha(source / row['file']) == row['sha256'], row
changed = [p.name for p in sorted((stage / 'core').glob('*.java')) if
           not (baseline / 'core' / p.name).exists() or
           p.read_text('utf8') != (baseline / 'core' / p.name).read_text('utf8')]
restored = ['GraphCompiler.java', 'GraphSourceRanking.java', 'GraphFallback.java',
            'GraphFallbackSearch.java', 'GraphFallbackSources.java']
for name in restored:
    assert (source / name).read_text('utf8') == (baseline / 'core' / name).read_text('utf8'), name
assert not (source / 'GraphStartupPruning.java').exists()
assert sha(root / 'build.gradle') == 'a17e1b46f2642be5c470eb3c130e02606b194574fefe08c5cccf229af8b8f9c0'

primary = compare('runs', ['manual-default', 'virtual-manual-first', 'virtual-extra-first',
                          'virtual-random'], 192, ['target', 'amount', 'mode', 'seed'])
labels = json.loads((area / 'subset-cases/manifest.json').read_text('utf8'))['labels']
subsets = compare('subsets', labels, 128,
                  ['target', 'amount', 'catalog_sha256', 'sources_sha256'])

subprocess.run(['python', str(area / 'final_parallel_report.py'), stage.name], check=True)
parallel = json.loads((stage / 'final-parallel-report.json').read_text('utf8'))
for label in parallel['matrix']:
    rows = read(stage / 'parallel' / (label + '.jsonl'))
    previous = read(baseline / 'parallel' / (label + '.jsonl'))
    key = lambda row: (row['mode'], row['fraction'], row['seed'], row['id'])
    old = {key(row): row for row in previous}
    lost = []
    for row in rows:
        before = old[key(row)]
        assert row['catalog_sha256'] == before['catalog_sha256']
        assert row['work_limit'] == before['work_limit']
        if before['feasible'] and not row['feasible']:
            lost.append(key(row))
    assert not lost, (label, lost)
    parallel['matrix'][label]['lost_vs_final_v22'] = lost
assert len(parallel['reduced']) == 10 and all(r['result'] == 'FEASIBLE' for r in parallel['reduced'])

networks = {}
for name, count in [('finite', 3072), ('cover', 1152)]:
    rows = read(oracle / (name + '-' + stage.name + '.jsonl'))
    assert len(rows) == count
    assert all(r['result'].startswith('FEASIBLE') == r['expected'] for r in rows)
    assert all(r['result'] in ('FEASIBLE', 'FEASIBLE_NOT_PROVEN_OPTIMAL', 'INFEASIBLE', 'MISSING_INPUT', 'MISSING_SEED') for r in rows)
    networks[name] = {'cgse_cases': len(rows), 'results': dict(Counter(r['result'] for r in rows)),
                      'oracle_summary': json.loads((oracle / (name + '-oracle-summary.json')).read_text('utf8'))}

startup = (oracle / ('startup-' + stage.name) / 'result.log').read_text('utf8')
assert 'PASS supports=8192 learned_cuts=6651 independently_explored_states=12649' in startup
buildlog = root / '.local/structural-stage-20261004/oraclebackendfinal-build.log'
assert 'BUILD SUCCESSFUL' in buildlog.read_text('utf8', errors='replace')

native = read(oracle / 'manual-all-v3.jsonl')
assert len(native) == 192
native_summary = {}
for solver in ('cp_sat', 'scip', 'z3'):
    values = [row[solver] for row in native]
    native_summary[solver] = {
        'status': dict(Counter(v['status'] for v in values)),
        'exact_balance': sum(v.get('exact_balance') is True for v in values),
        'invalid_exact_balance': sum(v.get('exact_balance') is False for v in values),
        'independently_executable': sum(v.get('execution', {}).get('status') == 'EXECUTABLE' for v in values),
    }
negatives = read(oracle / 'manual-negative-v1.jsonl')
manual_failed = {r['id'] for r in read(stage / 'runs/manual-default.jsonl') if not r['feasible']}
assert len(negatives) == 13 and {r['id'] for r in negatives} == manual_failed
assert all(r['z3']['status'] == 'unsat' and r['z3']['unbounded_exact_integer'] for r in negatives)

jar = root / 'build/libs/gtlcore-1.2.3.2-fix3.jar'
jar_out = delivery / 'gtlcore-1.2.3.2-fix3-cgse-backend-20261007.jar'
shutil.copy2(jar, jar_out)
assert sha(jar) == sha(jar_out)
(delivery / (jar_out.name + '.sha256')).write_text(sha(jar_out) + '  ' + jar_out.name + '\n', 'ascii')
report = {
    'stage': stage.name, 'baseline': baseline.name,
    'scope': {
        'frontend_pruning': 'Removed experimental frontend pruning at user request; no upfront recipe deletion added.',
        'backend': 'Quantitative optimistic startup analysis; demand-driven, independently verified startup implications.',
        'accounting': 'Local strategy quotas use their own active work, not unrelated global request work.',
        'changed_this_turn': changed, 'baseline_equal_files': restored,
        'build_gradle_preserved': True, 'source_manifest': manifest,
        'not_committed_or_pushed': True,
    },
    'primary': primary, 'subsets': subsets, 'parallel': parallel,
    'exact_differential': networks, 'startup_cut_validation': startup,
    'native_comparison': {
        'versions_and_model': json.loads((oracle / 'manual-all-v3-model.json').read_text('utf8')),
        'manual_192': native_summary, 'manual_failures_z3_exact_unsat': len(negatives),
        'scip_precision_counterexample': json.loads((oracle / 'scip-numeric-recheck.json').read_text('utf8')),
        'limitations': [
            'The external model is a necessary all-provider integer balance relaxation; SAT alone does not prove an executable plan.',
            'CP-SAT uses a bounded domain to avoid int64 overflow; its INFEASIBLE means bounded infeasible only, not a global proof.',
            'SCIP default floating-point solutions require exact replay; numerical statuses are advisory.',
            'Large full-catalog native runs reached limits or produced numerically invalid candidates; no parity or speedup claim.',
            'Mixed-catalog SEARCH_LIMIT cases remain unresolved, not proven infeasible.',
            'Saved stock/catalog replay is not a live Minecraft interaction test.',
        ],
    },
    'build': {'log': str(buildlog), 'sha256': sha(buildlog), 'status': 'SUCCESS',
              'checks': ['spotlessApply', 'graphCoreTest', 'graphIntegrationTest', 'build including upstream tests']},
    'artifact': {'file': str(jar_out), 'sha256': sha(jar_out), 'bytes': jar_out.stat().st_size},
}
(delivery / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), 'utf8')
print('SOURCE_CHANGED', changed)
print('PRIMARY', json.dumps(primary['current']))
print('SUBSETS', json.dumps(subsets['current']))
print('PRIMARY_WORK_BEFORE_AFTER', primary['baseline']['work'], primary['current']['work'])
print('SUBSET_WORK_BEFORE_AFTER', subsets['baseline']['work'], subsets['current']['work'])
print('NATIVE', json.dumps(native_summary))
print('ARTIFACT', json.dumps(report['artifact']))
