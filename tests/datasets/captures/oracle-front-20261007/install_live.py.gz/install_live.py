from pathlib import Path
import hashlib, json, shutil, socket, sys

tag = sys.argv[1]
assert tag.isalnum()
root = Path.cwd().resolve()
server = root / '.local/review-completion-20261004/server'
area = root / '.local/oracle-front-20261007'
source = root / 'build/libs/gtlcore-1.2.3.2-fix3.jar'
assert server.is_relative_to(root) and source.is_file()
connection = socket.socket()
connection.settimeout(.4)
busy = connection.connect_ex(('127.0.0.1', 25584)) == 0
connection.close()
assert not busy, 'Isolated test server is already running'
active = list((server / 'mods').glob('gtlcore*.jar'))
assert len(active) == 1, active
backup = area / ('server-core-before-' + tag + '.jar.backup')
assert not backup.exists()
shutil.copy2(active[0], backup)
new = server / 'mods' / ('gtlcore-1.2.3.2-fix3-cgse-compiler-fusion-' + tag + '-test.jar')
assert not new.exists()
shutil.copy2(source, new)
archived = active[0].with_name(active[0].name + '.pre-' + tag)
assert not archived.exists()
active[0].rename(archived)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source) == sha(new)
manifest = dict(source=str(source), installed=str(new), sha256=sha(new), previous_backup=str(backup), port=25584)
(area / ('live-core-' + tag + '.json')).write_text(json.dumps(manifest, indent=2), 'utf8')
print(json.dumps(manifest), flush=True)
