from pathlib import Path
import hashlib
import json
import shutil
import zipfile

source = Path('build/libs/gtlcore-1.2.3.2-fix2.jar')
target = source.with_name('gtlcore-1.2.3.2-fix2-graph-test.jar')
with zipfile.ZipFile(source) as jar:
    names = set(jar.namelist())
    graph = [name for name in names if '/integration/ae2/graph/' in name and name.endswith('.class')]
    assert len(graph) > 30
    config = json.loads(jar.read('gtlcore.mixin.json'))
    assert 'ae2.logic.GraphCraftingCpuMixin' in config['mixins']
    for required in ('core/GraphPlanner', 'core/GraphJobRuntime', 'GraphCpuController', 'GraphJobCodec', 'GtlExecutionAdapter'):
        name = 'org/gtlcore/gtlcore/integration/ae2/graph/' + required + '.class'
        data = jar.read(name)
        assert int.from_bytes(data[6:8], 'big') == 61, name
    assert not any(name.endswith(('GraphCoreTest.class', 'GraphAeAdapterTest.class')) for name in names)
    mods = jar.read('META-INF/mods.toml').decode('utf-8')
    assert '1.2.3.2-fix2' in mods
    print('Packaged graph classes:', len(graph))
    print('Mixin registration, Java 17 bytecode, mod version and test exclusion: PASS')
shutil.copy2(source, target)
sha = hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.jar.sha256').write_text(sha + '  ' + target.name + '\n', encoding='utf-8')
print('Artifact:', target.resolve())
print('Bytes:', target.stat().st_size)
print('SHA256:', sha)
