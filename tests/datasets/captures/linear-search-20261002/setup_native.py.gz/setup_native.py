from pathlib import Path
import json,random
root=Path.cwd().resolve();p=root/'.local/linear-search-20261002';old=root/'.local/miracle-cycle-20261002'
network=(old/'NetworkAudit.java').read_text('utf8').replace('package local.cgseprobe;','package local.linearaudit;')
network=network.replace('1024L<<20','128L<<20')
(p/'NetworkAudit.java').write_text(network,'utf8')
source=(old/'RandomOrderAudit.java').read_text('utf8').replace('package local.cgseprobe;','package local.linearaudit;')
source=source.replace('Path.of("local/random-order")','Path.of("local/linear-search-20261002")')
source=source.replace('var go = cgse(target, amount, catalog, 3_000_000L);','var go = cgse(target, amount, catalog, 20_000_000L);')
source=source.replace('if (go.get("result").getAsString().endsWith("LIMIT")) { row.add("cgse_screen", go); go = cgse(target, amount, catalog, 2_000_000_000L); }','')
source=source.replace('2_000_000_000L','20_000_000L')
source=source.replace('private static String order;','private static String order;\n    private static volatile CraftingCalculation tickingLegacy;\n    private static volatile Future<?> tickingFuture;\n    public static void tickLegacy() { var f=tickingFuture; var c=tickingLegacy; if(c!=null && f!=null && !f.isDone()) c.simulateFor(10000); }')
source=source.replace('var lf = LEGACY.submit(legacy::run);','tickingLegacy=legacy; var lf = LEGACY.submit(legacy::run); tickingFuture=lf;')
source=source.replace('lo.addProperty("ms",','tickingFuture=null; tickingLegacy=null; lo.addProperty("ms",')
source=source.replace('out.addProperty("work", b.nodes());','out.addProperty("diagnostics",b.diagnostics()); out.addProperty("work", b.nodes());')
(p/'RandomOrderAudit.java').write_text(source,'utf8')
template=(root/'.local/pattern-change-20261002/PatternChangeProbe.java').read_text('utf8')
imports=template[template.index('import '):template.index('@Mod(')]
tail=template[template.index('    static class Fixture {'):]
driver='''package local.linearaudit;
'''+imports+'''
@Mod("locallinearaudit")
public class NativeDriver {
    static boolean started;
    public NativeDriver(){
        MinecraftForge.EVENT_BUS.addListener(this::commands);
        MinecraftForge.EVENT_BUS.addListener(this::tick);
    }
    void tick(TickEvent.ServerTickEvent e){if(e.phase==TickEvent.Phase.END)RandomOrderAudit.tickLegacy();}
    void commands(RegisterCommandsEvent e){
        e.getDispatcher().register(Commands.m_82127_("linear_search_audit").requires(s->s.m_6761_(4)).executes(c->{
            if(started)throw new IllegalStateException("Already running");started=true;
            try{
                ConfigHolder.INSTANCE.ae2CalculationMode=AE2CalculationMode.MAX_FAST;
                ConfigHolder.INSTANCE.ae2GraphFallback=false;
                var f=new Fixture(c.getSource().m_81372_());
                String spec=java.nio.file.Files.readString(java.nio.file.Path.of(System.getProperty("local.linear.spec")));
                RandomOrderAudit.load(f.level,f.grid,f.source,"logs/ae-dump/ae-dump-muqjcnc6-60.zip")
                    .thenCompose(loaded->{System.out.println("[Linear Search] LOADED "+loaded);return RandomOrderAudit.batch(spec,"paired.jsonl");})
                    .whenComplete((result,error)->{if(error!=null){error.printStackTrace();System.out.println("[Linear Search] ABORT "+error);}else System.out.println("[Linear Search] DONE "+result);});
            }catch(Throwable ex){ex.printStackTrace();System.out.println("[Linear Search] ABORT "+ex);}
            return 1;
        }));
    }
'''+tail
(p/'NativeDriver.java').write_text(driver,'utf8')

linear=json.loads((p/'all-linear.json').read_text('utf8'));rng=random.Random(911421)
# Prefer multiple producers and deeper ordinary DAGs, plus a random tail.
ranked=sorted(linear,key=lambda g:(sum(len(v)>1 for v in g['catalog']['producers'].values()),len(g['catalog']['recipes'])),reverse=True)
sample=ranked[:48]+rng.sample(ranked[48:],48)
cases=[]
for i,g in enumerate(sample):
    maximum=int(g['known_feasible_max'])
    for n in sorted({1,maximum}):cases.append(dict(id=g['id']+'-'+str(n),target=g['target'],amount=str(n),stock=g['stock'],verify_cache=i<6))
    # A one-unit stock loss is not assumed infeasible: substitutes/byproducts may repair it.
    stock=dict(g['stock']);k=max(stock,key=lambda k:int(stock[k]));stock[k]=str(int(stock[k])-1)
    cases.append(dict(id=g['id']+'-stock-minus-one',target=g['target'],amount=str(maximum),stock=stock))
orders=[dict(name='baseline',seed=0),dict(name='reversed',seed=-1),dict(name='random-911421',seed=911421),dict(name='random-390713',seed=390713),dict(name='restored',seed=0)]
(p/'native-spec.json').write_text(json.dumps(dict(orders=orders,cases=cases)),'utf8')
print('native cases',len(cases),'orders',len(orders),'paired comparisons',len(cases)*len(orders))
run=(root/'.local/pattern-change-20261002/run.py').read_text('utf8')
run=run.replace("area=root/'.local/pattern-change-20261002'","area=root/'.local/linear-search-20261002'")
run=run.replace("str(area/'PatternChangeProbe.java')","*[str(area/name) for name in ['NativeDriver.java','NetworkAudit.java','RandomOrderAudit.java']]")
run=run.replace('local-pattern-change-probe','local-linear-search-probe').replace('localpatternchangeprobe','locallinearaudit')
run=run.replace('Local pattern change regression','Local linear search regression')
run=run.replace("'-Dlocal.pattern-change.fixed='+str(len(sys.argv)>1 and 'fixed' in sys.argv[1]).lower()","'-Dlocal.linear.spec='+str(area/'native-spec.json')")
run=run.replace('pattern_change_probe','linear_search_audit').replace('[Pattern Change]','[Linear Search]')
run=run.replace("['START','SLICE','SLOT','GUI','DONE','FAIL','ABORT']","['LOADED','DONE','ABORT']")
run=run.replace("if any('[Linear Search] '+key in line for key in ['LOADED','DONE','ABORT']):","if '[Random Order] completed ' in line or any('[Linear Search] '+key in line for key in ['LOADED','DONE','ABORT']):")
run=run.replace('time.monotonic()-begin>600','time.monotonic()-begin>1800')
(p/'run_native.py').write_text(run,'utf8')
