import copy
import json
import pathlib
import random

p = pathlib.Path(__file__).resolve().parent
base = {g['id']: g for g in json.loads((p / 'random-dag.json').read_text('utf8'))}
groups = []
for sample in [212, 374, 358]:
    source = base[f'dag-{sample}-order-0']
    maximum = int(source['known_feasible_max'])
    values = {1, 2, 3, maximum, maximum-1, maximum//2, maximum//3, maximum//2+1}
    n = 1
    while n <= maximum:
        for multiplier in (1, 2, 5):
            for delta in (-1, 0, 1):
                value = n * multiplier + delta
                if 1 <= value <= maximum:
                    values.add(value)
        n *= 10
    for order in range(8):
        g = copy.deepcopy(source)
        g['id'] = f'boundary-{sample}-order-{order}'
        g['kind'] = 'funded-dag-quantity-order-boundaries'
        rng = random.Random(4017213 + sample * 101 + order)
        rng.shuffle(g['catalog']['recipes'])
        for choices in g['catalog']['producers'].values():
            rng.shuffle(choices)
        g['requests'] = [dict(amount=str(n), phase='funded-boundary', cold=True) for n in sorted(values)]
        groups.append(g)
(p / 'hard-boundaries.json').write_text(json.dumps(groups), 'utf8')
print('groups', len(groups), 'requests', sum(len(g['requests']) for g in groups))
