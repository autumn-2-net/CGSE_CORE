"""Keep every alternative of the tested targets; omit unrelated obsolete registrations."""
import json
import pathlib
import zipfile

p = pathlib.Path(__file__).resolve().parent
source = p.parent / 'miracle-cycle-20261002/server/logs/ae-dump/ae-dump-muqjcnc6-60.zip'
spec = json.loads((p / 'native-spec.json').read_text('utf8'))
with zipfile.ZipFile(source) as src:
    resources = {r['id']: r for r in map(json.loads, src.read('resources.jsonl').decode().splitlines())}
    patterns = {r['id']: r for r in map(json.loads, src.read('patterns.jsonl').decode().splitlines())}
    network = json.loads(src.read('network.json'))
    snbt_ids = {r['snbt']: r['id'] for r in resources.values()}
    pending = [snbt_ids[c['target']] for c in spec['cases']]
    seen, used = set(), set()
    while pending:
        key = pending.pop()
        if key in seen:
            continue
        seen.add(key)
        for rid in network['producer_order'].get(key, []):
            if rid in used:
                continue
            used.add(rid)
            for slot in patterns[rid]['inputs']:
                pending.extend(s['key'] for s in slot['possible'])
                pending.extend(c['key'] for c in slot['candidate_checks'] if c['valid'])
    keep_keys = set(seen)
    for case in spec['cases']:
        keep_keys.update(snbt_ids[k] for k in case['stock'])
    for rid in used:
        rec = patterns[rid]
        keep_keys.add(rec['definition'])
        keep_keys.update(s['key'] for s in rec['outputs'])
        for slot in rec['inputs']:
            keep_keys.update(s['key'] for s in slot['possible'])
            for check in slot['candidate_checks']:
                keep_keys.add(check['key'])
                if check['remaining'] is not None:
                    keep_keys.add(check['remaining'])
    scoped = dict(network)
    scoped['scope'] = 'Complete producer closure of 96 tested linear targets, not the entire original network'
    scoped['extractable_inventory'] = {k: v for k, v in network['extractable_inventory'].items() if k in keep_keys}
    scoped['producer_order'] = {k: v for k, v in network['producer_order'].items() if k in seen}
    scoped['registered_pattern_order'] = [rid for rid in network['registered_pattern_order'] if rid in used]
    scoped['emitable'] = [k for k in network['emitable'] if k in keep_keys]
    assert all(rid in used for choices in scoped['producer_order'].values() for rid in choices)
    for k, choices in scoped['producer_order'].items():
        assert choices == network['producer_order'][k]
    with zipfile.ZipFile(p / 'target-closure.zip', 'w', zipfile.ZIP_DEFLATED) as dst:
        dst.writestr('network.json', json.dumps(scoped))
        dst.writestr('resources.jsonl', '\n'.join(json.dumps(r) for k, r in resources.items() if k in keep_keys))
        dst.writestr('patterns.jsonl', '\n'.join(json.dumps(r) for k, r in patterns.items() if k in used))
    report = dict(targets=len({c['target'] for c in spec['cases']}), patterns=len(used), resources=len(keep_keys),
                  scope=scoped['scope'], original_archive=str(source), omitted_resources=len(resources)-len(keep_keys))
    (p / 'native-scope.json').write_text(json.dumps(report, indent=2), 'utf8')
    print(json.dumps(report))
