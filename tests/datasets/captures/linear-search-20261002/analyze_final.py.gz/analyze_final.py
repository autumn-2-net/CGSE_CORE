import collections
import datetime
import hashlib
import json
import pathlib
import subprocess

p = pathlib.Path(__file__).resolve().parent
root = p.parent.parent
old = p.parent / 'quantity-regression-20261002'

def read(name):
    return [json.loads(line) for line in pathlib.Path(name).read_text('utf8').splitlines()]

def summary(rows):
    return dict(requests=len(rows), groups=len({r['group'] for r in rows}),
                results=dict(collections.Counter(r['result'] for r in rows)),
                maximum_work=max(r['work'] for r in rows), maximum_bytes=max(r['peak_bytes'] for r in rows))

def key(row):
    return row['group'], json.dumps(row['request'], sort_keys=True)

report = dict(parent_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
              generated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              default_work=20_000_000, default_memory_MiB=128, suites={})
for file, count in [('stable-linear', 19337), ('stable-dag', 2073), ('stable-boundaries', 648)]:
    rows = read(p / (file + '-results.jsonl'))
    assert len(rows) == count, (file, len(rows), count)
    assert not any(r['result'] == 'ERROR' for r in rows)
    funded = [r for r in rows if int(r['request']['amount']) <= int(r['known_feasible_max'])]
    assert all(r['feasible'] and r.get('verified') for r in funded), [(r['group'], r['request']) for r in funded if not r['feasible']]
    info = summary(rows)
    info['known_funded_requests'] = len(funded)
    info['known_funded_failures'] = 0
    if file == 'stable-linear':
        by_group = collections.defaultdict(list)
        for row in rows:
            by_group[row['group']].append(row)
        for values in by_group.values():
            cold = next(r for r in values if r['request']['phase'] == 'cold')
            warm = next(r for r in values if r['request']['phase'] == 'funded' and r['request']['amount'] == cold['request']['amount'])
            assert (cold['result'], cold['missing']) == (warm['result'], warm['missing'])
        info['warm_cold_equal'] = len(by_group)
    report['suites'][file] = info

reference = {}
for prefix, file in dict(**{'deep-native': 'final-deep-native', 'cycles-production': 'fixed-cycles-production',
                           'constructive': 'fixed-constructive', 'focused': 'focused-after'}).items():
    for row in read(old / (file + '-results.jsonl')):
        row['group'] = prefix + ':' + row['group']
        reference[key(row)] = row
rows = read(p / 'stable-prior-results.jsonl')
assert len(rows) == len(reference) == 4322
regressed, changes = [], []
for row in rows:
    before = reference[key(row)]
    assert row['result'] != 'ERROR'
    if before['feasible'] and not row['feasible']:
        regressed.append(row)
    if before['result'] != row['result']:
        changes.append(dict(group=row['group'], request=row['request'], before=before['result'], after=row['result']))
assert not regressed, regressed
report['suites']['prior'] = dict(**summary(rows), feasible_regressions=0, category_changes=changes)

native_path = p.parent / 'miracle-cycle-20261002/server/local/linear-search-20261002/paired-stable.jsonl'
native = read(native_path)
assert len(native) == 1435
for row in native:
    assert row['cgse']['result'] != 'ERROR' and row['maxfast']['result'] not in ['ERROR', 'TIMEOUT']
    assert row['maxfast']['result'] != 'FEASIBLE' or row['cgse']['result'].startswith('FEASIBLE'), row
    assert row.get('cache_equal', True), row
grouped = collections.defaultdict(list)
for row in native:
    grouped[row['id']].append(row)
assert all(len({r['cgse']['result'].startswith('FEASIBLE') for r in group}) == 1 for group in grouped.values())
report['native'] = dict(paired_requests=len(native), scope=json.loads((p / 'native-scope.json').read_text()),
                       result_pairs={a+' / '+b: n for (a,b),n in collections.Counter((r['maxfast']['result'], r['cgse']['result']) for r in native).items()},
                       cgse_worse=0, cgse_order_feasibility_changes=0, cache_equal_checks=sum('cache_equal' in r for r in native),
                       limitations='Real Forge/AE2 native pattern decoding and both planners, read-only frozen stock; planning only, no machine execution.')

failures = [r for r in read(p / 'hard-boundaries-results.jsonl') if not r['feasible']]
fixed = {key(r): r for r in read(p / 'stable-boundaries-results.jsonl')}
head = {key(r): r for r in read(p / 'head-failures-results.jsonl')}
report['counterexamples'] = []
for row in failures:
    after = fixed[key(row)]
    report['counterexamples'].append(dict(group=row['group'], amount=row['request']['amount'],
        committed_version=head[key(row)]['result'], first_local_fix=row['result'], after=after['result'],
        work_before=row['work'], work_after=after['work'], bytes_before=row['peak_bytes'], bytes_after=after['peak_bytes']))
restarts = [read(p / f'production-counterexamples-{i}.jsonl') for i in range(3)]
assert all(len(run) == 3 and all(r['feasible'] and r.get('verified') for r in run) for run in restarts)
assert all([(r['result'], r['work'], r['peak_bytes']) for r in run] ==
           [(r['result'], r['work'], r['peak_bytes']) for r in restarts[0]] for run in restarts)
report['independent_jvm_restarts'] = dict(processes=3, requests_each=3, outcomes_work_and_peak_bytes_identical=True)
refresh_log = (p.parent / 'pattern-change-20261002/linear-refresh-fixed.log').read_text('utf8')
assert '[Pattern Change] DONE passes=200 failures=0' in refresh_log
assert '[Pattern Change] SLICE PASS scenarios=288' in refresh_log
report['pattern_refresh'] = dict(paired_planner_checks=200, failures=0, snapshot_edit_timings=288,
    scope='Real AE2 provider revision and real GTL terminal replace/remove/restore notifications; cold, warm, missing then restored, changed intermediate input/amount/path; both engines, byproduct discovery on and off.',
    lifetime='OrderProofs belongs to one GraphPlanningWork. Each new calculation constructs a fresh instance. GtlPatternCatalog checks provider generation and dependency signatures before reusing structure.')
report['changes'] = [
    'Retain allocation and count frontiers but periodically resume queued source alternatives.',
    'Only compiled source solves consume the initial source-attempt quota; conflict-proven skips do not.',
    'Preserve conflict decision iteration order rather than Map.copyOf randomized JVM order.',
    'Retain the earlier exact-deficit source ordering fix and original global budget limits.'
]
report['production_sources'] = {}
for name in ['GraphPlanningWork.java', 'SourceExplanation.java', 'OrderProofs.java']:
    file = root / 'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core' / name
    report['production_sources'][str(file.relative_to(root))] = hashlib.sha256(file.read_bytes()).hexdigest()
jar = root / 'build/libs/gtlcore-1.2.3.2-fix3.jar'
report['jar'] = dict(path=str(jar), bytes=jar.stat().st_size, sha256=hashlib.sha256(jar.read_bytes()).hexdigest())
data = (p / 'stable-build.log').read_bytes()
log = data.decode('utf-16' if data.startswith(b'\xff\xfe') else 'utf8', errors='replace')
assert 'BUILD SUCCESSFUL' in log
report['build'] = dict(success=True, tasks=['spotlessJavaApply', 'build', 'graphIntegrationTest', 'graphCoreTest'],
                       checks=[line.strip() for line in log.splitlines() if 'assertions' in line or 'checks passed' in line or 'BUILD SUCCESSFUL' in line])
assert hashlib.sha256((root / 'build.gradle').read_bytes()).hexdigest() == 'a17e1b46f2642be5c470eb3c130e02606b194574fefe08c5cccf229af8b8f9c0'
report['original_report_attribution'] = 'Unknown: the original failing linear recipe/network was not supplied. These are independently reproduced causes, not proof of that report\'s cause.'
(p / 'validation.json').write_text(json.dumps(report, indent=2), 'utf8')
print(json.dumps(dict(suites=report['suites'], native=report['native'], counterexamples=report['counterexamples'], jar=report['jar']), indent=2))
