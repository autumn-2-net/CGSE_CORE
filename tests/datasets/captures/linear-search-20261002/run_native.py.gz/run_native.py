from pathlib import Path
import subprocess,zipfile,os,shutil,socket,threading,time,sys
sys.stdout.reconfigure(encoding='utf8',errors='replace')
root=Path.cwd().resolve();area=root/'.local/linear-search-20261002';server=root/'.local/miracle-cycle-20261002/server'
assert server.is_relative_to(root)
with socket.socket() as sock:assert sock.connect_ex(('127.0.0.1',25580))!=0,'Port occupied'
backup=area/'runtime-backup';backup.mkdir(exist_ok=True)
cp=[root/'build/libs/gtlcore-1.2.3.2-fix3.jar']+[p for p in (server/'mods').glob('*.jar') if not p.name.startswith(('gtlcore-','local-pattern-change'))]+list((server/'libraries').rglob('*.jar'))
classes=area/'classes';classes.mkdir(exist_ok=True)
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',os.pathsep.join(str(p) for p in cp),'-d',str(classes),*[str(area/name) for name in ['NativeDriver.java','NetworkAudit.java','RandomOrderAudit.java']]]
(area/'javac.args').write_text('\n'.join('"'+str(x).replace('\\','/')+'"' for x in args),'utf8')
subprocess.run([r'C:\Users\autumn\.jdks\corretto-20.0.2.1\bin\javac.exe','@'+str(area/'javac.args')],check=True)
probe=server/'mods/local-linear-search-probe.jar'
with zipfile.ZipFile(probe,'w',zipfile.ZIP_DEFLATED) as z:
 for path in classes.rglob('*.class'):z.write(path,path.relative_to(classes).as_posix())
 z.writestr('META-INF/mods.toml','modLoader="javafml"\nloaderVersion="[47,)"\nlicense="MIT"\n[[mods]]\nmodId="locallinearaudit"\nversion="1"\ndisplayName="Local linear search regression"\n')
saved=[];installed=[];properties=server/'server.properties';original_properties=properties.read_bytes()
process=None
try:
 for old in (server/'mods').glob('*.jar'):
  if old.name.startswith(('gtlcore-','kotlinforforge-','[Custom-')) or old.name=='gtladditions-3.3-fix1.jar':
   assert old.resolve().is_relative_to(server);dest=backup/old.name;assert not dest.exists();shutil.move(old,dest);saved.append((dest,old))
 for new in [root/'build/libs/gtlcore-1.2.3.2-fix3.jar',*(root/'.local/upstream-skyblock-20261002/smoke-runtime').glob('*.jar')]:
  dest=server/'mods'/new.name;shutil.copy2(new,dest);installed.append(dest)
 properties.write_text(properties.read_text('utf8').replace('level-name=world','level-name=merge_smoke_20261002'),'utf8')
 ready=threading.Event();done=threading.Event();out=(area/(sys.argv[1] if len(sys.argv)>1 else 'baseline.log')).open('w',encoding='utf8')
 java=r'C:\Users\autumn\AppData\Roaming\.hmcl\java\windows-x86_64\mojang-java-runtime-delta\bin\java.exe'
 process=subprocess.Popen([java,'-Xms512M','-Xmx6G','-Dfile.encoding=UTF-8','-Dlocal.linear.spec='+str(area/'native-spec.json'),'@libraries/net/minecraftforge/forge/1.20.1-47.4.16/win_args.txt','nogui'],cwd=server,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
 print('Isolated server PID',process.pid,flush=True)
 def reader():
  for line in process.stdout:
   out.write(line);out.flush()
   if 'Done (' in line:ready.set();print(line.rstrip(),flush=True)
   if '[Random Order] completed ' in line or any('[Linear Search] '+key in line for key in ['LOADED','DONE','ABORT']):print(line.rstrip(),flush=True)
   if '[Linear Search] DONE' in line or '[Linear Search] ABORT' in line:done.set()
 thread=threading.Thread(target=reader,daemon=True);thread.start();begin=time.monotonic()
 while not ready.wait(.5):
  if process.poll() is not None or time.monotonic()-begin>240:raise RuntimeError('Startup failed')
 process.stdin.write('linear_search_audit\n');process.stdin.flush()
 while not done.wait(.5):
  if process.poll() is not None or time.monotonic()-begin>1800:raise RuntimeError('Probe failed/timed out')
 process.stdin.write('stop\n');process.stdin.flush();process.wait(timeout=45);thread.join(timeout=5);out.close()
 print('Probe finished',process.returncode,flush=True)
finally:
 if process and process.poll() is None:process.terminate();process.wait(timeout=15)
 for path in installed+[probe]:
  assert path.resolve().is_relative_to(server)
  if path.exists():path.unlink()
 for src,dst in saved:shutil.move(src,dst)
 properties.write_bytes(original_properties)
