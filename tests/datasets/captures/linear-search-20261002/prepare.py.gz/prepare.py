import json,pathlib,collections,random

P=pathlib.Path(__file__).resolve().parent
OLD=P.parent/'miracle-cycle-20261002'
catalog=json.loads((OLD/'audit-original-catalog.json').read_text(encoding='utf-8'))
recipes={r['id']:r for r in catalog['recipes']}
def subtree(target):
    pending=[target];seen=set();included=set();producers={}
    while pending:
        key=pending.pop()
        if key in seen:continue
        seen.add(key)
        choices=catalog['producers'].get(key,[])
        if choices:producers[key]=choices
        for rid in choices:
            if rid not in included:
                included.add(rid)
                pending.extend(s['key'] for s in recipes[rid]['slots'])
    return dict(recipes=[r for r in catalog['recipes'] if r['id'] in included],producers=producers,
                external=catalog['external'],parallelism=catalog['parallelism'],max_extra_copies=catalog['max_extra_copies'])

rows=[json.loads(s) for s in (OLD/'server/local/ae-audit/linear-initial.jsonl').read_text(encoding='utf-8').splitlines()]
by_target={}
for row in rows:
    if row['maxfast']['result']!='FEASIBLE':continue
    target=row['target']
    if target not in by_target or int(row['amount'])>int(by_target[target]['amount']):by_target[target]=row
groups=[]
for i,row in enumerate(by_target.values()):
    amount=int(row['amount']);values=sorted({1,max(1,amount//1000),max(1,amount//2),max(1,amount-1),amount})
    requests=[dict(amount=str(2**63-1),phase='prime-long')]+[dict(amount=str(n),phase='funded',cold=False) for n in values]+[dict(amount=str(amount),phase='cold',cold=True)]
    groups.append(dict(id=f'native-linear-{i}',kind='native-maxfast-funded',target=row['target'],
        known_feasible_max=str(amount),stock=row['maxfast']['initial'],catalog=subtree(row['target']),requests=requests,
        work=20_000_000,memory=128<<20,native_reference_id=row['id']))
(P/'all-linear.json').write_text(json.dumps(groups),encoding='utf-8')
print('linear targets',len(groups),'requests',sum(len(g['requests']) for g in groups),'max recipes',max(len(g['catalog']['recipes']) for g in groups))

# Supply a constructive witness for random DAGs independently of either planner.
# Witness funding expands a chosen producer per key with exact integer batches.
# The solver sees these and cheaper-looking but unfunded alternatives in shuffled order.
def r(name,inputs,outputs):
    return dict(id=name,slots=[dict(key=k,amount=str(n)) for k,n in inputs.items()],outputs={k:str(n) for k,n in outputs.items()})
def fund(target,amount,chosen):
    need=collections.defaultdict(int,{target:amount});stock={}
    for key in sorted(chosen,key=lambda k:int(k[1:]),reverse=True):
        n=need[key]
        if not n:continue
        rec=chosen[key];runs=(n+int(rec['outputs'][key])-1)//int(rec['outputs'][key])
        for slot in rec['slots']:need[slot['key']]+=int(slot['amount'])*runs
    for key,n in need.items():
        if n and key not in chosen:stock[key]=str(n)
    return stock

synthetic=[]
for sample in range(384):
    rng=random.Random(1743812+sample);width=4+sample%20;recipes_local=[];good={};prod={}
    for i in range(width):
        key=f'N{i}';inputs={f'R{rng.randrange(6)}':rng.randint(1,5)}
        if i:
            for j in rng.sample(range(i),min(i,rng.randint(1,3))):inputs[f'N{j}']=rng.randint(1,4)
        good[key]=r(f'good-{i}',inputs,{key:rng.randint(1,4)})
        alternatives=[good[key],r(f'absent-{i}',{f'ABSENT{i}':1},{key:rng.randint(1,6)})]
        if i>1:alternatives.append(r(f'other-{i}',{f'R{rng.randrange(6)}':rng.randint(1,5),f'N{rng.randrange(i)}':rng.randint(1,4)},{key:rng.randint(1,5)}))
        rng.shuffle(alternatives);prod[key]=[a['id'] for a in alternatives];recipes_local+=alternatives
    target=f'N{width-1}';amount=10**(sample%5);stock=fund(target,amount,good)
    assert max(map(int,stock.values()))<2**63
    for order in range(3):
        recipes_order=list(recipes_local);rng.shuffle(recipes_order)
        producers={k:list(v) for k,v in prod.items()}
        if order==1:
            for values in producers.values():values.reverse()
        elif order==2:
            for values in producers.values():rng.shuffle(values)
        synthetic.append(dict(id=f'dag-{sample}-order-{order}',kind='independently-funded-dag',target=target,
            stock=stock,known_feasible_max=str(amount),requests=[dict(amount=str(n),phase=f'amount-{n}',cold=True) for n in sorted({1,amount})],
            work=20_000_000,memory=128<<20,catalog=dict(recipes=recipes_order,producers=producers)))
(P/'random-dag.json').write_text(json.dumps(synthetic),encoding='utf-8')
print('constructive DAG groups',len(synthetic),'requests',sum(len(g['requests']) for g in synthetic))
