from pathlib import Path

root = Path.cwd()
p = root / '.local/linear-search-20261002'
src = root / 'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core/GraphPlanningWork.java'
s = src.read_text('utf8')
(p / 'GraphPlanningWork.before-fairness.java').write_text(s, 'utf8')
s = s.replace('private int phase;', 'private int phase;\n    private int allocationAfterSources = 8;\n    private long allocationTurnStarted, allocationTurnAllowance;')
s = s.replace('seen.size() >= 8', 'seen.size() >= allocationAfterSources')
s = s.replace('''if (allocating != null && (pending.isEmpty() || seen.size() >= allocationAfterSources)) {
                        phase = 6;''', '''if (allocating != null && (pending.isEmpty() || seen.size() >= allocationAfterSources)) {
                        beginAllocationTurn();''')
s = s.replace('''preserve, forceCraft, excluded, budget, started).proofs(proofs);
                        phase = 6;''', '''preserve, forceCraft, excluded, budget, started).proofs(proofs);
                        beginAllocationTurn();''')
s = s.replace('''case 6 -> {
                    if (!allocating.step())''', '''case 6 -> {
                    if (!pending.isEmpty() && budget.nodes() - allocationTurnStarted >= allocationTurnAllowance) {
                        budget.note("allocation_handoff", "pending_sources=" + pending.size() + "; seen=" + seen.size());
                        phase = 0;
                        return false;
                    }
                    if (!allocating.step())''')
s = s.replace('''    private void startCountSearch() {''', '''    private void beginAllocationTurn() {
        allocationAfterSources = seen.size() + 8;
        allocationTurnStarted = budget.nodes();
        allocationTurnAllowance = Math.min(1_048_576, budget.remainingWork() / 8);
        phase = 6;
    }

    private void startCountSearch() {''')
(p / 'experiment/GraphPlanningWork.java').write_text(s, 'utf8')
