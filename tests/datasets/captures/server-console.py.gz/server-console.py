import ctypes
import sys
from ctypes import wintypes

class KeyEvent(ctypes.Structure):
    _fields_ = [('down', wintypes.BOOL), ('repeat', wintypes.WORD),
                ('vkey', wintypes.WORD), ('scan', wintypes.WORD),
                ('char', wintypes.WCHAR), ('control', wintypes.DWORD)]

class Event(ctypes.Union):
    _fields_ = [('key', KeyEvent), ('pad', ctypes.c_byte * 16)]

class InputRecord(ctypes.Structure):
    _fields_ = [('kind', wintypes.WORD), ('event', Event)]

k = ctypes.WinDLL('kernel32', use_last_error=True)
k.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                         ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
k.CreateFileW.restype = wintypes.HANDLE
k.WriteConsoleInputW.argtypes = [wintypes.HANDLE, ctypes.POINTER(InputRecord),
                               wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
k.FreeConsole()
if not k.AttachConsole(int(sys.argv[1])):
    raise ctypes.WinError(ctypes.get_last_error())
try:
    handle = k.CreateFileW('CONIN$', 0xC0000000, 3, None, 3, 0, None)
    if handle == wintypes.HANDLE(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        command = sys.argv[2] + '\r'
        records = (InputRecord * len(command))()
        for record, char in zip(records, command):
            record.kind = 1
            record.event.key = KeyEvent(True, 1, ord(char.upper()), 0, char, 0)
        written = wintypes.DWORD()
        if not k.WriteConsoleInputW(handle, records, len(records), ctypes.byref(written)):
            raise ctypes.WinError(ctypes.get_last_error())
    finally:
        k.CloseHandle(handle)
finally:
    k.FreeConsole()
print('Console command sent:', sys.argv[2])
