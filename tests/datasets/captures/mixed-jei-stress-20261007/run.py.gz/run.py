from pathlib import Path
import concurrent.futures,json,subprocess,sys,time
root=Path.cwd().resolve();area=root/'.local/mixed-jei-stress-20261007';(area/'runs').mkdir(exist_ok=True)
cp=(area/'classpath.txt').read_text('utf8');java='C:/Users/autumn/.jdks/corretto-20.0.2.1/bin/java.exe'
def run(label):
    config=area/'cases'/f'{label}.json';output=area/'runs'/f'{label}.jsonl';log=area/'runs'/f'{label}.log'
    if output.exists() or log.exists():raise FileExistsError(label)
    start=time.monotonic()
    with log.open('w',encoding='utf8') as out:
        p=subprocess.Popen([java,'-Xmx3G','-XX:ActiveProcessorCount=2','-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.MixedSweep',str(area),str(config),str(output)],cwd=root,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        print('START',label,'pid',p.pid,flush=True);last=0
        while p.poll() is None:
            elapsed=time.monotonic()-start
            if elapsed-last>=25:
                tail=log.read_text('utf8',errors='replace').splitlines();print('PROGRESS',label,round(elapsed),tail[-1] if tail else '',flush=True);last=elapsed
            time.sleep(.5)
    result=dict(label=label,exit=p.returncode,seconds=round(time.monotonic()-start,3))
    (area/'runs'/f'{label}-run.json').write_text(json.dumps(result,indent=2),'utf8');print('FINISH',result,flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(run,sys.argv[1:]))
if any(r['exit']!=0 for r in results):raise SystemExit(1)
