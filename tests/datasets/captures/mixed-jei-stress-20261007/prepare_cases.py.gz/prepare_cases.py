from pathlib import Path
import json,random,shutil
root=Path.cwd().resolve();area=root/'.local/mixed-jei-stress-20261007'
source=root/'.local/miracle-cycle-20261002/audit-original-catalog.json';shutil.copy2(source,area/'manual.json')
if not (area/'extra.json').exists():(area/'extra.json').write_text('{"recipes":[]}','utf8')
manual=json.loads(source.read_text(encoding='utf8'));targets=sorted(manual['targets']);rng=random.Random(20261007)
priority=[t for t in targets if any(k in t for k in ['miracle','stargate','hypercube','eternity_catalyst','supracausal_mainframe','cosmic_neutronium','quantum_anomaly','biomass','infinity_ingot','gravi_star','uv_voltage_coil','wetware_processor'])]
focus=sorted(set(priority+rng.sample(targets,48)))
def write(label,mode,requests,seed=0,work=4_000_000,memory=256<<20,timeout=1000):
    config=dict(mode=mode,seed=seed,work=work,memory=memory,timeout=timeout,requests=requests)
    (area/'cases').mkdir(exist_ok=True);(area/'cases'/f'{label}.json').write_text(json.dumps(config,ensure_ascii=False),'utf8')
def requests(keys,amounts):return [dict(id=f'{targets.index(t)}-{a}',target=t,amount=str(a)) for t in keys for a in amounts]
for mode in ['manual','manual-first','extra-first','random']:
    write(mode+'-focus',mode,requests(focus,[1,1000,10**12]),seed=73 if mode=='random' else 0)
for shard in range(2):
    write('manual-all-'+str(shard),'manual',requests(targets[shard::2],[1,1000]))
    write('mixed-all-'+str(shard),'manual-first',requests(targets[shard::2],[1,1000]))
(area/'targets.json').write_text(json.dumps(dict(all=targets,focus=focus),ensure_ascii=False),'utf8')
print('Prepared manual targets',len(targets),'focus',len(focus),flush=True)
