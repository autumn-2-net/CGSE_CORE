from pathlib import Path
import collections,json,sys
area=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.local/mixed-jei-stress-20261007');w=json.loads((area/('known-witness.json' if (area/'known-witness.json').exists() else 'known-hpca-witness.json')).read_text('utf8'))
manual=json.loads((area/'manual.json').read_text('utf8'));extra=json.loads((area/'reduced-extra.json').read_text('utf8'))
all_recipes={r['id']:r for r in manual['recipes']+extra['recipes']};recipes={r['id']:r for r in w['recipes']}
def norm(r):return (r['binding'],[(s['key'],int(s['amount']),s['input_slot'],s['configuration'],s['reusable']) for s in r['slots']],{k:int(v) for k,v in r['outputs'].items()})
for rid,r in recipes.items():assert norm(r)==norm(all_recipes[rid]),rid
def composition(a,b):
    ar,ad=a;br,bd=b;keys=set(ar)|set(ad)|set(br)|set(bd)
    return ({k:max(ar.get(k,0),br.get(k,0)-ad.get(k,0),0) for k in keys},{k:ad.get(k,0)+bd.get(k,0) for k in keys})
def repeat(summary,n):
    need,change=summary
    if n==0:return ({},{})
    keys=set(need)|set(change)
    return ({k:need.get(k,0)+max(0,-change.get(k,0))*(n-1) for k in keys},{k:change.get(k,0)*n for k in keys})
def fold(step):
    if 'recipe' in step:
        r=recipes[step['recipe']];need=collections.Counter()
        for s in r['slots']:need[s['key']]+=int(s['amount'])
        keys=set(need)|set(r['outputs']);delta={k:int(r['outputs'].get(k,0))-need[k] for k in keys}
        return repeat((dict(need),delta),int(step['runs']))
    if 'body' in step:return repeat(fold(step['body']),int(step['times']))
    result=({}, {})
    for child in step['children']:result=composition(result,fold(child))
    return result
need,delta=fold(w['steps']);initial={k:int(v) for k,v in w['initial'].items()};stock={k:int(v) for k,v in w['stock'].items()}
for k,v in need.items():assert initial.get(k,0)>=v,(k,'prefix',v,initial.get(k,0))
for k,v in initial.items():assert stock.get(k,0)>=v,(k,'inventory',v,stock.get(k,0))
target=w['request']['target'];amount=int(w['request']['amount']);delivered=initial.get(target,0)+delta.get(target,0)
assert delivered>=amount,(delivered,amount)
assert initial.get(target,0)==0,'This witness must produce, not withdraw, the target'
report=dict(passed=True,arithmetic='Python arbitrary precision integers; independent of CGSE PlanVerifier',recipe_values_unchanged=True,witness_recipes=len(recipes),added_patterns=len(extra['recipes']),request=w['request'],required_resources=len([k for k in need if need[k]>0]),initial_resources=len(initial),delivered=str(delivered),target_initial=str(initial.get(target,0)))
(area/'independent-witness.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),'utf8');print(json.dumps(report,ensure_ascii=False))
