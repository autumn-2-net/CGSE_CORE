from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,zipfile

root=Path.cwd().resolve(); area=root/'.local/mixed-jei-stress-20261007'; server=area/'server'
source=root/'.local/miracle-cycle-20261002/server'
server.mkdir(exist_ok=True); assert server.is_relative_to(root)
def link(src,dst):
    try: os.link(src,dst)
    except OSError: shutil.copy2(src,dst)
    return dst
for name in ['libraries','mods','config','defaultconfigs','kubejs','skyblockbuilder']:
    if not (source/name).exists() or (server/name).exists():continue
    ignores=shutil.ignore_patterns('local-*.jar','graph-server-probe.jar','zz_local*','logs','client_scripts','exported','probe*')
    shutil.copytree(source/name,server/name,copy_function=link if name=='libraries' else shutil.copy2,ignore=ignores)
core=list((server/'mods').glob('gtlcore-*.jar'));assert len(core)==1
artifact=root/'.local/next-boundary-20261004/solver-stage-20261007-final/gtlcore-1.2.3.2-fix3-cgse-20261007-test.jar'
shutil.copy2(artifact,core[0])
props=(source/'server.properties').read_text('utf8')
for k,v in {'server-port':'25589','level-name':'recipe_export_empty_world','server-ip':'127.0.0.1','motd':'Local recipe extraction only','max-players':'0','spawn-animals':'false','spawn-monsters':'false','spawn-npcs':'false'}.items():
    props=re.sub(r'(?m)^'+re.escape(k)+r'=.*$',k+'='+v,props)
(server/'server.properties').write_text(props,'utf8');(server/'eula.txt').write_text('eula=true\n','utf8')
(server/'tmp').mkdir(exist_ok=True)
shutil.copy2(area/'export.js',server/'kubejs/server_scripts/zz_local_recipe_export.js')
libraries=list((server/'libraries').rglob('*.jar'))
libraries.sort(key=lambda p: (0 if p.name=='forge-1.20.1-47.4.16-server.jar' else 1 if p.name.endswith('-srg.jar') else 2, str(p)))
cp=list((server/'mods').glob('*.jar'))+libraries
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',';'.join(str(p) for p in cp),'-d',str(area/'export-classes'),str(area/'RecipeExport.java')]
(area/'export-javac.args').write_text('\n'.join('"'+a.replace('\\','/')+'"' for a in args),'utf8')
subprocess.run(['C:/Users/autumn/.jdks/corretto-20.0.2.1/bin/javac.exe','@'+str(area/'export-javac.args')],check=True)
with zipfile.ZipFile(server/'mods/local-recipe-dump.jar','w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('META-INF/mods.toml','modLoader="javafml"\nloaderVersion="[47,)"\nlicense="All Rights Reserved"\n[[mods]]\nmodId="localrecipedump"\nversion="0.0.0"\ndisplayName="Local recipe exporter"\n')
    for p in (area/'export-classes').rglob('*.class'):z.write(p,p.relative_to(area/'export-classes').as_posix())
manifest=[]
for name in ['mods','kubejs','config']:
    for p in sorted((server/name).rglob('*')):
        if p.is_file():manifest.append({'file':p.relative_to(server).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(area/'environment.json').write_text(json.dumps({'server_source':str(source),'inventory_source':'.local/miracle-cycle-20261002/audit-original-catalog.json','world':'fresh empty world; no saved player world','files':manifest},indent=2,ensure_ascii=False),'utf8')
print('Export helper compiled. Isolated pack ready:',server,flush=True)
