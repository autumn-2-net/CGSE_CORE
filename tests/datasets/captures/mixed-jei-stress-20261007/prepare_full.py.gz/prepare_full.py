from pathlib import Path
import json,random
area=Path('.local/mixed-jei-stress-20261007')
targets=json.loads((area/'targets.json').read_text('utf8'));rng=random.Random(144)
sample=sorted(set(targets['focus']+rng.sample(targets['all'],192)))
def write(label,mode,keys,amounts,**options):
    config=dict(mode=mode,seed=17,work=20_000_000,memory=128<<20,timeout=0,fallback=True)
    config.update(options);config['requests']=[dict(id=str(targets['all'].index(t))+'-'+str(a),target=t,amount=str(a)) for t in keys for a in amounts]
    (area/'cases'/f'{label}.json').write_text(json.dumps(config,ensure_ascii=False),'utf8')
for mode in ['manual','manual-first','extra-first','random']:
    write(mode+'-fallback',''+mode,targets['focus'],[1,1000,10**12],fallback_only=True,seed=73 if mode=='random' else 0)
for mode in ['manual-first','extra-first','random']:
    write(mode+'-default',mode,targets['focus'],[1,1000,10**12],seed=73 if mode=='random' else 0)
for shard in range(2):
    write('mixed-sample-'+str(shard),'manual-first',sample[shard::2],[1,1000],work=4_000_000,timeout=1000,memory=256<<20)
(area/'sample.json').write_text(json.dumps(sample,ensure_ascii=False),'utf8')
print('Default-budget focus',len(targets['focus']),'independent sample',len(sample))
