from pathlib import Path
import json,socket,subprocess,time
root=Path.cwd().resolve();area=root/'.local/mixed-jei-stress-20261007';server=area/'server'
assert server.is_relative_to(root)
with socket.socket() as sock:assert sock.connect_ex(('127.0.0.1',25589))!=0,'Port occupied'
log=area/'export-server.log';result={'passed':False,'server':str(server)}
java='C:/Users/autumn/AppData/Roaming/.hmcl/java/windows-x86_64/mojang-java-runtime-delta/bin/java.exe'
with log.open('w',encoding='utf8') as out:
    p=subprocess.Popen([java,'-Xms512M','-Xmx6G','-Dfile.encoding=UTF-8','-Djava.io.tmpdir='+str(server/'tmp'),'@libraries/net/minecraftforge/forge/1.20.1-47.4.16/win_args.txt','nogui'],cwd=server,stdin=subprocess.PIPE,stdout=out,stderr=subprocess.STDOUT,text=True,encoding='utf8',creationflags=subprocess.CREATE_NO_WINDOW)
    print('Recipe-only server PID',p.pid,flush=True)
    def cmd(s):p.stdin.write(s+'\n');p.stdin.flush()
    start=time.monotonic();sent=False;last=0
    try:
        while p.poll() is None:
            content=log.read_text('utf8',errors='replace');elapsed=time.monotonic()-start
            if '[Recipe Export] FAIL' in content:raise RuntimeError('Export failed; see log')
            if '[Recipe Export] COMPLETE' in content:result['passed']=True;break
            if not sent and 'Done (' in content:cmd('local_recipe_export');sent=True;print('Exporting loaded recipe manager',flush=True)
            if elapsed-last>25:print('elapsed',round(elapsed),'export_requested',sent,flush=True);last=elapsed
            if elapsed>600:raise TimeoutError('Server/export timeout')
            time.sleep(.5)
        if not result['passed']:raise RuntimeError('Server ended without exporting')
    finally:
        if p.poll() is None:
            try:cmd('stop');p.wait(timeout=45)
            except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=15)
        result.update(exit=p.returncode,elapsed=round(time.monotonic()-start,3))
        (area/'export-result.json').write_text(json.dumps(result,indent=2),'utf8')
        print(json.dumps(result),flush=True)
