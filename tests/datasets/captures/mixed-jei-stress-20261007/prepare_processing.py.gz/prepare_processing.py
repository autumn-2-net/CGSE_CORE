from pathlib import Path
import copy,hashlib,json
area=Path('.local/mixed-jei-stress-20261007');d=json.loads((area/'extra.json').read_text('utf8'))
profiles={}
for profile in ['configured','physical']:
    data=copy.deepcopy(d)
    for r in data['recipes']:
        if profile=='configured':
            for s in r['slots']:
                if s['reusable']:
                    left=int(r['outputs'][s['key']])-int(s['amount'])
                    if left:r['outputs'][s['key']]=str(left)
                    else:del r['outputs'][s['key']]
            r['slots']=[s for s in r['slots'] if not s['reusable']]
        else:
            for s in r['slots']:s['configuration']=False;s['reusable']=False
    path=area/f'extra-{profile}.json';path.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),'utf8')
    profiles[profile]=dict(patterns=len(data['recipes']),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),meaning='GT nonconsumables are preinstalled in the machine; only actual consumed ingredients enter AE patterns' if profile=='configured' else 'Nonconsumables are ordinary input/output catalyst loops without special reusable slot flags')
    for mode in ['manual-first','extra-first','random']:
        config=json.loads((area/'cases'/f'{mode}-default.json').read_text('utf8'));config['extra_catalog']=path.name
        (area/'cases'/f'{profile}-{mode}.json').write_text(json.dumps(config,ensure_ascii=False),'utf8')
(area/'processing-profiles.json').write_text(json.dumps(profiles,indent=2),'utf8');print(profiles)
