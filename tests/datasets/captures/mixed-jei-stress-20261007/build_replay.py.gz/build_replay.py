from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path.cwd().resolve();area=root/'.local/mixed-jei-stress-20261007';frozen=area/'core'
source=root/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core'
frozen.mkdir(exist_ok=True);manifest=[]
for src in source.glob('*.java'):
    dst=frozen/src.name;shutil.copy2(src,dst);manifest.append({'file':src.name,'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
(area/'source-hashes.json').write_text(json.dumps(manifest,indent=2),'utf8')
gson=root/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'
classes=area/(sys.argv[1] if len(sys.argv)>1 else 'classes')
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',str(gson),'-d',str(classes),*[str(p) for p in sorted(frozen.glob('*.java'))],str(area/'MixedSweep.java')]
(area/'replay-javac.args').write_text('\n'.join('"'+s.replace('\\','/')+'"' for s in args),'utf8')
subprocess.run(['C:/Users/autumn/.jdks/corretto-20.0.2.1/bin/javac.exe','@'+str(area/'replay-javac.args')],check=True)
(area/'classpath.txt').write_text(str(classes)+';'+str(gson),'utf8');print('Compiled current core snapshot',len(manifest),'files',flush=True)
