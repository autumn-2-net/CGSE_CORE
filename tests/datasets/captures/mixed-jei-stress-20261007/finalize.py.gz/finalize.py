from pathlib import Path
import collections,gzip,hashlib,json,subprocess,zipfile

root=Path.cwd().resolve();area=root/'.local/mixed-jei-stress-20261007';runs=area/'runs'
def read(p):return json.loads(p.read_text('utf8'))
def rows(p):return [json.loads(l) for l in p.read_text('utf8').splitlines() if l.strip()]
baseline={r['id']:r for r in rows(runs/'manual-default.jsonl')}
all_results={p.stem:rows(p) for p in sorted(runs.glob('*.jsonl'))}
run_reports=[read(p) for p in runs.glob('*-run.json')]
assert len(run_reports)==33 and all(r['exit']==0 for r in run_reports),run_reports
for run in run_reports:
    label=run['label'];assert len(all_results[label])==len(read(area/'cases'/f'{label}.json')['requests']),label
errors=[]
for label,rs in all_results.items():
    for r in rs:
        if r['result']=='ERROR' or r.get('fallback',{}).get('result')=='ERROR':errors.append({'label':label,'row':r})
        if r.get('feasible'):assert r.get('verified'),(label,r['id'])
        if r.get('fallback',{}).get('feasible'):assert r['fallback'].get('verified'),(label,r['id'])
assert not errors,errors
def summarize(label):
    rs=all_results[label];ms=sorted(r['ms'] for r in rs)
    return dict(requests=len(rs),main_feasible=sum(r.get('feasible',False) for r in rs),
        effective_feasible=sum(r.get('effective_feasible',r.get('feasible',False)) for r in rs),
        main_statuses=dict(collections.Counter(r['result'] for r in rs)),
        effective_statuses=dict(collections.Counter(r.get('effective_result',r['result']) for r in rs)),
        regressions_from_verified_baseline=sum(r['id'] in baseline and baseline[r['id']]['effective_feasible'] and not r.get('effective_feasible',r.get('feasible',False)) for r in rs),
        gains_from_baseline=sum(r['id'] in baseline and not baseline[r['id']]['effective_feasible'] and r.get('effective_feasible',r.get('feasible',False)) for r in rs),
        main_total_work=sum(r['work'] for r in rs),main_ms_sum=sum(ms),main_ms_p95=ms[min(len(ms)-1,int(len(ms)*.95))],
        peak_budget_bytes=max(r['peak_bytes'] for r in rs))
conversion=read(area/'conversion-virtual.json');old_conversion=read(area/'conversion.json')
current_source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core').glob('*.java')}
frozen_source={entry['file']:entry['sha256'] for entry in read(area/'source-hashes.json')};assert current_source==frozen_source
production_dirty=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert len(production_dirty)==12,production_dirty
assert hashlib.sha256((root/'build.gradle').read_bytes()).hexdigest()=='a17e1b46f2642be5c470eb3c130e02606b194574fefe08c5cccf229af8b8f9c0'
report={
 'date':'2026-10-07','task':'Full loaded server recipe catalog plus frozen real AE stock/manual patterns, offline CGSE stress replay',
 'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'solver':'Current workspace, including the prior uncommitted 11 production files; no production solver changes in this task',
 'source_files':len(current_source),'source_manifest':'source-hashes.json','production_files_unchanged_during_task':True,
 'server':read(area/'export-result.json'),
 'data':{'primary_export':'server/local/recipe-export-virtual/recipes.jsonl','primary_loaded_recipes':conversion['raw_count'],
     'primary_converted_source_recipes':conversion['included_source_count'],'primary_concrete_patterns':conversion['pattern_count'],
     'manual_patterns':5903,'combined_patterns':conversion['combined_pattern_count'],'inventory_keys':len(read(area/'manual.json')['stock']),
     'excluded_source_recipes':len(conversion['excluded']),'excluded_reasons':conversion['excluded_reasons'],
     'concretization':'Displayed option and stock-preferred option; does not enumerate every Cartesian combination of tags',
     'virtual_inputs':'Produced by actual Core VirtualIngredientBehavior.wrap on the isolated server, then serialized as AE keys',
     'initial_export_recipes':old_conversion['raw_count'],'initial_export':'server/local/recipe-export/recipes.jsonl',
     'reload_difference':'The second load lacks gtceu:extractor/extract_glass_lens. Each input snapshot is immutable within its comparisons. Raw toString condition addresses are not semantic recipe differences.'},
 'coverage':{'broad_manual_requests':len(all_results['manual-all-0'])+len(all_results['manual-all-1']),
     'broad_manual_targets':5733,'focused_targets':64,'focused_amounts':['1','1000','1000000000000'],
     'primary_default_work':20000000,'primary_default_memory_bytes':128<<20,'primary_timeout_ms':0,
     'fallback_work':131072,'fallback_memory_bytes':16<<20,'fallback_timeout_ms':250,
     'all_recorded_replay_rows':sum(map(len,all_results.values())),'completed_run_processes':len(run_reports),
     'verification_failures':len(errors),'parallelism':'Independent replay processes; each individual request uses synchronous production core state machines',
     'random_order':'Seed 73 for the full primary catalog; additional seeds 11/29/997 in the abstract stress profile; all six source orders of the reduced real three-pattern case'},
 'primary_default_comparison':{label:summarize(label) for label in ['manual-default','virtual-manual-first','virtual-extra-first','virtual-random']},
 'configured_machine_comparison':{label:summarize(label) for label in ['configured-manual-first','configured-extra-first','configured-random']},
 'physical_catalyst_comparison':{label:summarize(label) for label in ['physical-manual-first','physical-extra-first','physical-random']},
 'all_runs':{label:summarize(label) for label in all_results},
 'confirmed_counterexample':{
     'folder':'configured-repro','target':'gtceu:miracle','amount_mB':1,
     'additional_patterns':[r['id'] for r in read(area/'configured-repro/reduced-extra.json')['recipes']],
     'added_patterns':3,'one_minimal_among_added_patterns':read(area/'configured-repro/reduced-extra.json')['one_minimal'],
     'material_semantics':'Ordinary consumed ingredients and guaranteed outputs; no synthetic resources, virtual flags, or nonconsumables in these three patterns',
     'known_witness':read(area/'configured-repro/independent-witness.json'),
     'failure':{'main':'SEARCH_LIMIT','work':20000001,'fallback':'MISSING_INPUT'},
     'all_six_orders':{'manual_first_effective':dict(collections.Counter(r['effective_result'] for r in rows(area/'configured-repro/order-matrix.jsonl') if r['mode']=='manual-first')),
         'new_first_effective':dict(collections.Counter(r['effective_result'] for r in rows(area/'configured-repro/order-matrix.jsonl') if r['mode']=='extra-first'))},
     'selected_graphs':read(area/'configured-repro/selected-graphs.json')},
 'diagnostic_only':{
     'initial_profile':'Physical material keys marked as reusable read arcs. This is an abstract stress model, NOT a literal AE virtual ingredient encoding. Its two-pattern counterexample is retained separately.',
     'stock_boundary_prototype':'Local positive-only restricted graph, not installed in production. Rescued zero previously failing default-budget focused requests; not accepted as a fix.',
     'high_budget_probe':'Ten known-feasible regressions in the abstract profile remained unresolved after 80M work / 1024 MiB; do not equate this with a full primary-profile budget sweep.'},
 'next_work':[
     'Use the three ordinary disassembly patterns as the primary regression fixture; preserve its original executable witness as the oracle.',
     'Improve recovery from poor source choices and positive witness scheduling; final diagnostics retain thousands of alternatives while original/reduced/normalized LCG views repeat hundreds of slices with zero progress.',
     'Make target-relevant preprocessing and fallback admission budget-aware. GraphFallbackSources.create currently disables ordering by TOTAL catalog size > 2048; the full count closure also stops above 8192 recipes.',
     'Keep budget exhaustion distinct from infeasibility: the fallback missing-material preview here describes a failed chosen route even though the original plan remains executable.',
     'Re-run these exact immutable catalogs, quantities, and source orders after changes, with positive plans checked for execution inventory and output counts.'
 ],
 'limitations':[
     'The dump is the server RecipeManager, not client-only JEI information pages, multiblock diagrams, or synthetic display recipes.',
     'Probability-only or unadapted dynamic serializers were exported but not misrepresented as guaranteed material production.',
     'Machine, energy and recipe environmental/research conditions are assumed available, as with abstract encoded AE processing patterns.',
     'This validates offline solver behavior and independently verifies witnesses; it does not execute machines or submit jobs in a player save.',
     'Full-catalog capture and JSON parsing costs are outside the per-request solve budget; this is not an end-to-end GUI timing benchmark.',
     'The mixed catalog was sampled across the 64-target focused matrix and a supplementary 254-target sample; only the original manual catalog received the complete 5733-target sweep.',
     'No maxfast comparison was run in this turn. Baseline feasibility is established by current CGSE and preserved exact executable plans.'
 ]
}
(area/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
# Record hashes of the actual final extraction environment, including the corrected exporter script.
environment=read(area/'environment.json')
for entry in environment['files']:
    p=area/'server'/entry['file'];entry['bytes']=p.stat().st_size;entry['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
(area/'environment.json').write_text(json.dumps(environment,ensure_ascii=False,indent=2),'utf8')
for folder in ['recipe-export','recipe-export-virtual']:
    p=area/'server/local'/folder/'recipes.jsonl';output=area/(folder+'.jsonl.gz')
    with p.open('rb') as src,output.open('wb') as dst,gzip.GzipFile(fileobj=dst,mode='wb',mtime=0) as zipped:
        while chunk:=src.read(1024*1024):zipped.write(chunk)
with zipfile.ZipFile(area/'reduced-miracle-repro.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for name in ['manual.json','reduced-extra.json','known-witness.json','independent-witness.json','order-matrix.jsonl','selected-graphs.json','minimize.jsonl']:
        p=area/'configured-repro'/name;archive.write(p,'repro/'+name)
    for name in ['source-hashes.json','report.json','MinimizeStress.java','ReducedOrderProbe.java','MixedSweep.java','verify_witness.py']:
        archive.write(area/name,name)
print(json.dumps({'report':str(area/'report.json'),'recorded_rows':report['coverage']['all_recorded_replay_rows'],'verification_failures':len(errors),'primary':{k:[v['main_feasible'],v['effective_feasible'],v['regressions_from_verified_baseline']] for k,v in report['primary_default_comparison'].items()}},ensure_ascii=False,indent=2))
