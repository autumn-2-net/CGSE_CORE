from pathlib import Path
import collections,hashlib,json,sys

root=Path.cwd().resolve();area=root/'.local/mixed-jei-stress-20261007'
manual=json.loads((area/'manual.json').read_text('utf8'));stock={k:int(v) for k,v in manual['stock'].items()}
virtual='--virtual' in sys.argv
raw=area/('server/local/recipe-export-virtual/recipes.jsonl' if virtual else 'server/local/recipe-export/recipes.jsonl')
# Only static, understood serializers. Unknown adapters remain in the full raw export.
static_classes={
 'net.minecraft.world.item.crafting.ShapedRecipe','net.minecraft.world.item.crafting.ShapelessRecipe',
 'net.minecraft.world.item.crafting.SmeltingRecipe','net.minecraft.world.item.crafting.BlastingRecipe',
 'net.minecraft.world.item.crafting.SmokingRecipe','net.minecraft.world.item.crafting.CampfireCookingRecipe',
 'net.minecraft.world.item.crafting.StonecutterRecipe','com.gregtechceu.gtceu.api.recipe.StrictShapedRecipe',
 'committee.nova.mods.avaritia.common.crafting.recipe.ShapedExtremeCraftingRecipe',
 'committee.nova.mods.avaritia.common.crafting.recipe.ShapelessExtremeCraftingRecipe',
}
recipes=[];report={'raw_count':0,'included_source_count':0,'excluded':[],'assumptions':[
 'Every represented recipe has its machine, power and environmental/research conditions available.',
 'Each JEI recipe is encoded with concrete input choices: displayed first and stock-preferred; all tag combinations are not enumerated.',
 'Only guaranteed outputs are promised. Chance inputs, if any, are charged at their full count.',
 'Nonconsumables are exact read arcs requiring a seed; fluids use integer mB; NBT uses AE generic keys.',
 'Unadapted dynamic serializers remain in the full raw dump and are excluded from the deterministic catalog.'
], 'random_outputs_omitted':0,'nonconsumable_slots':0,'empty_consumed_inputs':0,'alternative_slots':0,'free_output_recipes':0}
counts=collections.Counter()
for line in raw.open(encoding='utf8'):
 r=json.loads(line);report['raw_count']+=1
 try:
  if 'error' in r:raise ValueError('export_error:'+r['error'])
  if not r.get('gt') and r['class'] not in static_classes:raise ValueError('unadapted_serializer:'+r['class'])
  out=collections.Counter();inputs=[]
  if r.get('gt'):
   if r.get('ingredient_actions')!='[]':raise ValueError('dynamic_ingredient_action')
   for part in ['outputs','tick_outputs']:
    for content in r.get(part,[]):
     if content['capability'] not in ['item','fluid']:
      if content['capability'] not in ['eu','cwu']:raise ValueError('unsupported_output_capability:'+content['capability'])
      continue
     if content.get('random_amount'):raise ValueError('random_output_count')
     if content['chance']<content['max_chance']:
      report['random_outputs_omitted']+=1;continue
     choices=content['alternatives']
     if len(choices)!=1:raise ValueError('non_fixed_output')
     a=choices[0];out[a['key']]+=int(a['amount'])*(r['duration'] if part=='tick_outputs' else 1)
   for part in ['inputs','tick_inputs']:
    for content in r.get(part,[]):
     if content['capability'] not in ['item','fluid']:
      if content['capability'] not in ['eu','cwu']:raise ValueError('unsupported_input_capability:'+content['capability'])
      continue
     if content.get('random_amount'):raise ValueError('random_input_count')
     choices=content['alternatives']
     if not choices:raise ValueError('empty_ingredient')
     inputs.append((choices,content['chance']==0,r['duration'] if part=='tick_inputs' and content['chance']>0 else 1))
  else:
   for a in r['outputs']:out[a['key']]+=int(a['amount'])
   for content in r['inputs']:
    if not content['alternatives']:raise ValueError('empty_ingredient')
    inputs.append((content['alternatives'],False,1))
  out={k:v for k,v in out.items() if v>0}
  if not out:raise ValueError('no_guaranteed_material_output')
  if any(v>2**63-1 for v in out.values()):raise ValueError('output_amount_overflow')
  if not inputs:report['free_output_recipes']+=1
  variants=[]
  for mode in ['displayed','stock']:
   slots=[];outputs=dict(out)
   for i,(choices,reusable,multiplier) in enumerate(inputs):
    a=choices[0] if mode=='displayed' else min(choices,key=lambda a:(-min(stock.get(a['virtual_key'] if virtual and reusable else a['key'],0),1 if virtual and reusable else int(a['amount'])),a['key']))
    amount=1 if virtual and reusable else int(a['amount'])*multiplier
    if amount<=0 or amount>2**63-1:raise ValueError('invalid_input_amount')
    key=a['virtual_key'] if virtual and reusable else a['key'];slots.append(dict(key=key,amount=str(amount),input_slot=i,configuration=reusable,reusable=reusable))
    if reusable:outputs[key]=outputs.get(key,0)+amount
    if 'remaining_key' in a:outputs[a['remaining_key']]=outputs.get(a['remaining_key'],0)+int(a['remaining_amount'])*amount
   if any(v>2**63-1 for v in outputs.values()):raise ValueError('return_amount_overflow')
   signature=(slots,outputs)
   if signature in variants:continue
   variants.append(signature)
   recipes.append(dict(id='jei:'+r['id']+':'+mode,binding='jei:'+r['id'],slots=slots,outputs={k:str(v) for k,v in outputs.items()}))
  report['included_source_count']+=1;counts[r['type']]+=1
  report['nonconsumable_slots']+=sum(reusable for _,reusable,_ in inputs)
  report['alternative_slots']+=sum(len(a)>1 for a,_,_ in inputs)
 except ValueError as e:report['excluded'].append(dict(id=r['id'],reason=str(e)))
report.update(pattern_count=len(recipes),manual_pattern_count=len(manual['recipes']),combined_pattern_count=len(recipes)+len(manual['recipes']),types=dict(counts),excluded_reasons=dict(collections.Counter(e['reason'] for e in report['excluded'])))
output=area/('extra-virtual.json' if virtual else 'extra.json')
output.write_text(json.dumps({'recipes':recipes},ensure_ascii=False,separators=(',',':')),'utf8')
report['profile']='Actual Core VirtualIngredientBehavior.wrap keys for Ctrl transfer, sealed reusable supply tokens' if virtual else 'Abstract read arcs on physical materials (stress model, not encoded AE virtual stacks)'
report['sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [raw,area/'manual.json',output]}
(area/('conversion-virtual.json' if virtual else 'conversion.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({k:v for k,v in report.items() if k not in ['excluded','types','sha256','assumptions']},ensure_ascii=False,indent=2))
