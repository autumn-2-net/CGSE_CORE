import json,pathlib,collections
ROOT=pathlib.Path(__file__).resolve().parent

def load(name):
    result=[]
    path=ROOT/f'{name}-results.jsonl'
    if not path.exists(): return result
    for line in path.read_text(encoding='utf-8').splitlines():
        try: result.append(json.loads(line))
        except json.JSONDecodeError: pass  # A concurrently written final row may not be complete yet.
    return result

def analyze(name,verbose=True):
    rows=load(name)
    groups=collections.defaultdict(list)
    for row in rows: groups[row['group']].append(row)
    suspects=[]
    repeat_changes=[]
    for group, entries in groups.items():
        feasible=[int(x['request']['amount']) for x in entries if x['feasible']]
        verified_max=max(feasible,default=0)
        expected_max=int(entries[0].get('known_feasible_max',0))
        for row in entries:
            if not row['feasible'] and int(row['request']['amount'])<=max(verified_max,expected_max):
                suspects.append(dict(row,larger_verified=verified_max))
        by_amount=collections.defaultdict(list)
        for row in entries: by_amount[row['request']['amount']].append(row)
        for amount, variants in by_amount.items():
            outcomes=set('FEASIBLE' if x['feasible'] else x['result'] for x in variants)
            if len(outcomes)>1:
                repeat_changes.append(dict(group=group,target=variants[0]['target'],amount=amount,
                    results=[dict(phase=x['request']['phase'],result=x['result'],work=x['work']) for x in variants]))
    summary=dict(requests=len(rows),groups=len(groups),results=dict(collections.Counter(x['result'] for x in rows)),
                 suspected_non_monotonic=len(suspects),repeat_changes=repeat_changes,
                 suspect_groups=sorted(set(x['group'] for x in suspects)),
                 total_work=sum(x['work'] for x in rows),total_ms=sum(x['ms'] for x in rows),
                 exceptions=[x for x in rows if x['result']=='ERROR'])
    (ROOT/f'{name}-analysis.json').write_text(json.dumps(dict(summary=summary,suspects=suspects),indent=2,ensure_ascii=False),encoding='utf-8')
    if verbose:
        print(name,json.dumps(summary,ensure_ascii=False))
        for row in suspects[:12]:
            print('SUSPECT',row['target'],row['request'],row['result'],'larger_verified',row['larger_verified'],
                  'work',row['work'],'ms',round(row['ms']))
    return summary,suspects

if __name__=='__main__':
    import sys
    for name in sys.argv[1:] or ['linear','cycles']: analyze(name)
