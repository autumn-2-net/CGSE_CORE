import json, pathlib, hashlib, random

ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'miracle-cycle-20261002'
MAX = 2**63-1
catalog = json.loads((SOURCE/'audit-original-catalog.json').read_text(encoding='utf-8'))
quantities = {10**i for i in range(19)} | {MAX, 64, 144, 999, 1001}
for boundary in [2**31, 2**32, 2**53]:
    quantities.update([boundary-1,boundary,boundary+1])

def requests(values):
    # A maximal failed order must not poison subsequent smaller orders.
    return ([{'amount':str(MAX),'phase':'prime-long'}] +
            [{'amount':str(n),'phase':'ascending'} for n in sorted(values)] +
            [{'amount':str(n),'phase':'cold-check','cold':True} for n in [1,1000,MAX]] +
            [{'amount':str(n),'phase':'warm-recheck'} for n in [1000,1]])

cycles = {}
for case in json.loads((SOURCE/'audit-cycle-cases.json').read_text(encoding='utf-8')):
    cycles.setdefault(case['target'], set()).add(int(case['amount']))
for target in catalog['producers']:
    if 'miracle' in target:
        cycles.setdefault(target,set()).update([1000,2000000])
cycle_groups = []
for i,(target, baseline) in enumerate(cycles.items()):
    values = quantities | baseline
    available = int(catalog['stock'].get(target,0))
    if available>0:
        values |= {n for n in [available-1,available,available+1] if 0<n<=MAX}
    cycle_groups.append(dict(id=f'cycle-{i}',kind='saved-cycle',target=target,
        requests=requests(values),work=3_000_000,timeout=0))

funded = [c for c in json.loads((SOURCE/'audit-tight-cases.json').read_text(encoding='utf-8')) if c['id'].endswith('-funded')]
linear_groups = [dict(id=c['id'],kind='funded-linear',target=c['target'],stock=c['stock'],
                     known_feasible_max=c['amount'],requests=requests(quantities),work=20_000_000,timeout=0) for c in funded]
for name, groups in [('cycles',cycle_groups),('linear',linear_groups)]:
    (ROOT/f'{name}.json').write_text(json.dumps(groups,ensure_ascii=False),encoding='utf-8')
    print(name,'groups',len(groups),'requests',sum(len(g['requests']) for g in groups))
(ROOT/'inputs.json').write_text(json.dumps(dict(commit='58ade8c560fc63df1151f6585cef0015bb202263',
    catalog_sha256=hashlib.sha256((SOURCE/'audit-original-catalog.json').read_bytes()).hexdigest(),
    recipes=len(catalog['recipes']),inventory_keys=len(catalog['stock']),quantities=sorted(quantities)),indent=2),encoding='utf-8')
