import json,pathlib,random,subprocess
P=pathlib.Path(__file__).resolve().parent
MAX=2**63-1
groups=[]
def recipe(name,inputs,outputs):
    return dict(id=name,slots=[dict(key=k,amount=str(n)) for k,n in inputs.items()],outputs={k:str(n) for k,n in outputs.items()})
for sample in range(24):
    rng=random.Random(803220+sample)
    n=128+(sample%3)*64
    critical=1+sample%3
    recipes=[];stock={};inputs={};producers={}
    for i in range(n):
        key=f'B{i}';inputs[key]=1;stock[f'R{i}']=str(MAX);stock[f'S{i}']=str(MAX)
        entries=[recipe(f'normal-{i}',{f'R{i}':1},{key:1}),recipe(f'unrelated-{i}',{f'S{i}':1},{key:1})]
        if sample%2:rng.shuffle(entries)
        producers[key]=[r['id'] for r in entries];recipes+=entries
    for i in range(critical):
        key=f'C{i}';inputs[key]=1;stock[f'T{i}']=str(MAX)
        entries=[recipe(f'bad-{i}-a',{f'absent-{i}-a':1},{key:1}),recipe(f'bad-{i}-b',{f'absent-{i}-b':1},{key:1}),recipe(f'good-{i}',{f'T{i}':1},{key:1})]
        producers[key]=[r['id'] for r in entries];recipes+=entries
    if sample%3==1:inputs=dict(reversed(list(inputs.items())))
    elif sample%3==2:
        items=list(inputs.items());rng.shuffle(items);inputs=dict(items)
    recipes.append(recipe('finish',inputs,{'P':1}));producers['P']=['finish'];rng.shuffle(recipes)
    requests=[dict(amount=str(n),phase=f'seq-{i}',cold=(i==2)) for i,n in enumerate([MAX,1,1000,2**31,2**53+1,1])]
    groups.append(dict(id=f'wide-{sample}',kind='unrelated-source-regression',target='P',stock=stock,
        known_feasible_max=str(MAX),work=1_000_000,memory=128<<20,requests=requests,dump=True,
        catalog=dict(recipes=recipes,producers=producers,parallelism=4096,max_extra_copies=64)))

# Switching an unrelated branch's producer may supply a deficit as a byproduct.
for sample in range(12):
    recipes=[recipe('blocked-B',{'ABSENT':1},{'B':1}),recipe('blocked-B2',{'ABSENT2':1},{'B':1}),
        recipe('regular-C',{'R':1},{'C':1}),recipe('byproduct-C',{'S':1},{'C':1,'B':1}),
        recipe('finish',{'B':1,'C':1},{'P':1})]
    producers={'P':['finish'],'B':['blocked-B','blocked-B2'],'C':['regular-C','byproduct-C']}
    if sample%2:producers['B'].reverse()
    random.Random(444+sample).shuffle(recipes)
    groups.append(dict(id=f'byproduct-{sample}',kind='retain-unrelated-alternatives',target='P',stock={'R':str(MAX),'S':str(MAX)},
        known_feasible_max=str(MAX),work=1_000_000,requests=[dict(amount=str(q),phase='cold',cold=True) for q in [1,1000,MAX]],
        catalog=dict(recipes=recipes,producers=producers)))

(P/'focused.json').write_text(json.dumps(groups),encoding='utf-8')
source=subprocess.check_output(['git','show','HEAD:src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core/GraphPlanningWork.java'])
(P/'baseline-src').mkdir(exist_ok=True)
(P/'baseline-src/GraphPlanningWork.java').write_bytes(source)
print('focused groups',len(groups),'requests',sum(len(g['requests']) for g in groups))
