from pathlib import Path
import subprocess
import zipfile

root = Path.cwd()
java = Path(r'C:/Users/autumn/.jdks/corretto-20.0.2.1/bin')
server = root / '.local/graph-server'
output = root / '.local/graph-probe-classes'
output.mkdir(exist_ok=True)
cp = [root / 'build/libs/gtlcore-1.2.3.2-fix2.jar']
cp += list(server.glob('mods/*.jar'))
cp += list(server.glob('libraries/**/*.jar'))
args = root / '.local/graph-probe-javac.args'
args.write_text('--release 17\n-proc:none\n-encoding UTF-8\n-cp\n"' + ';'.join(p.as_posix() for p in cp) + '"\n-d\n"' + output.as_posix() + '"\n' + '\n'.join('"'+p.as_posix()+'"' for p in (root/'tools/graph-server-probe').glob('*.java')) + '\n', encoding='utf-8')
subprocess.run([str(java/'javac.exe'), '@'+str(args)], check=True)
with zipfile.ZipFile(server/'mods/graph-server-probe.jar', 'w') as jar:
    for f in output.rglob('*.class'):
        jar.write(f, f.relative_to(output).as_posix())
    jar.writestr('META-INF/mods.toml', 'modLoader="javafml"\nloaderVersion="[47,)"\nlicense="MIT"\n[[mods]]\nmodId="gtlgraphprobe"\nversion="1"\ndisplayName="Local graph validation fixture"\n')
    jar.writestr('META-INF/MANIFEST.MF', 'Manifest-Version: 1.0\nMixinConfigs: graph-probe.mixins.json\n\n')
    jar.writestr('graph-probe.mixins.json', '{"required":true,"minVersion":"0.8","package":"org.gtlcore.test.mixin","compatibilityLevel":"JAVA_17","mixins":["LegacyPlannerProbe","LegacyExecutorProbe","MaxFastProbe"],"injectors":{"defaultRequire":1}}')
print('Local server probe compiled. This test mod must never be shipped.')
