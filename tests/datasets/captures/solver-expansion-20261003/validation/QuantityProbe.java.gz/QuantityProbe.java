package org.gtlcore.gtlcore.integration.ae2.graph.core;
import java.util.*;
public final class QuantityProbe {public static void main(String[]args){for(boolean dead:new boolean[]{false,true})OrderProbe.solve(OrderProbe.recipes(dead),9,Map.of("A",1L,"B",14L,"C",1L),true);}}
