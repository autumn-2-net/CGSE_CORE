from pathlib import Path
import json,hashlib
a=Path(__file__).resolve().parent;r=a.parents[2]
report={
 'baseline_head':json.loads((a/'baseline-manifest.json').read_text())['head'],
 'scope':'Pure actual CGSE core/API harnesses; no native server or user world touched in this task.',
 'production_owned':['GraphFallbackSearch.java','GraphFallbackSources.java'],
 'fallback':json.loads((a/'fallback-comparison.json').read_text()),
 'fallback_total':{'old_feasible':18896,'new_feasible':18917,'total_known_feasible':18917,'regressions':0,'false_feasible':0,'errors':0,'limits':0},
 'independent_dag_oracle':{'cases':600,'reachable':372,'found':372,'false_feasible':0,'memory_leaks':0},
 'fallback_edge_cases':9,
 'fallback_restart_safety_assertions':28,
 'diving_exhaustive_oracle':{'systems':700,'integer_feasible':245,'found':245,'LP_infeasible':450,'fractional_LP':120,'early_close_cases':1000,'false_feasible':0,'memory_leaks':0},
 'ratio_macro_oracle':{'systems':720,'exact_expanded_batches':2160,'overflow_skip':1,'false_witness':0,'memory_leaks':0},
 'order_regression':{'cases':1130,'serially_verified':586,'oracle_possible_unknown':6,'oracle_possible_missing':0,'baseline_verified':577,'baseline_unknown':15,'new_witnesses':9,'status':'strict whole-path first; rejected witness retains allocation/count frontiers; zero baseline feasible regressions'},
 'baseline_remaining_force':json.loads((a/'force-remaining.json').read_text()),
 'remaining_force':{'rows':[x for x in (a/'frontier-order/OrderRegression.log').read_text().splitlines() if x.startswith('CASE ') and ' UNKNOWN ' in x],'status':'6 reachable requests remain UNKNOWN, not material shortages or infeasibility proofs'},
 'mixed_force_bug':{'present_on_frozen_HEAD':True,'present_before_safety_fix':True,'force_target':'C','force_amount':3,'stock':{'C':100,'raw':1,'fuel':100},'returned_counts':{'out':1,'make':1,'turn':1},'physical_C_produced':2,'C_consumed':1,'C_net':1,'runtime_inventory_verifier_passed':True,'root_owns_safety_fix':True,'post_fix_result':'SEARCH_LIMIT','safety_matrix_cases':14,'quota_cases':60,'initial_safety_guard_oracle_regressions':18,'final_v3_oracle_regressions':0},
 'research':'official-strategies.txt',
 'oracle_limits':'Large corpus has constructive known feasible requests; finite BFS/exhaustive tests independently establish reachable/unreachable only in their domains. No claim that MAX_FAST is optimal or always sound.',
}
report['production_sha256']={n:hashlib.sha256((r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core'/n).read_bytes()).hexdigest() for n in report['production_owned']}
snapshot=json.loads((a/'frontier-quota/source-hashes.json').read_text())
report['final_tested_core_sha256']=snapshot
current={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core').glob('*.java')}
report['post_test_source_differences']=[n for n in sorted(set(snapshot)|set(current)) if snapshot.get(n)!=current.get(n)]
order_snapshot=json.loads((a/'frontier-order/source-hashes.json').read_text())
order_diff=[n for n in sorted(set(order_snapshot)|set(current)) if order_snapshot.get(n)!=current.get(n)]
report['order_to_final_formatting_changes']=order_diff
report['order_to_final_semantic_text_differences']=[n for n in order_diff if ''.join((a/'frontier-order/core'/n).read_text().split())!=''.join((r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core'/n).read_text().split())]
if (a/'archive-recheck-report.json').exists():
 archive=json.loads((a/'archive-recheck-report.json').read_text())
 report['archive_release_recheck']={k:v for k,v in archive.items() if k!='cases'}
 report['archive_release_recheck']['detail']='archive-recheck-report.json'
 report['archive_release_recheck']['scope_note']='Previously successful strict paths were verified before the final rejected-witness frontier retention change; not rerun as requested.'
for folder,main in [('mixed-safety-v3','MixedDetail'),('frontier-safety','ForceSafetyMatrix'),('frontier-quota','ForceProofQuota'),('frontier-order','OrderRegression'),('region-loops-v4','LoopProbe')]:
 p=a/folder/(main+'.log')
 if p.exists():report.setdefault('post_safety_logs',{})[folder]=p.read_text(errors='replace')[-12000:]
(a/'report.json').write_text(json.dumps(report,indent=2))
print(a/'report.json')
