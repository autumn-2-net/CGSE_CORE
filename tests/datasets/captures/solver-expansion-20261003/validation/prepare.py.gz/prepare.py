from pathlib import Path
import subprocess,json,hashlib,shutil

area=Path(__file__).resolve().parent
root=area.parents[2]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
prefix='src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core/'
src=area/'head-core';src.mkdir(parents=True,exist_ok=True)
manifest={}
for path in subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--',prefix],cwd=root,text=True).splitlines():
    if not path.endswith('.java'):continue
    data=subprocess.check_output(['git','show',head+':'+path],cwd=root)
    target=src/Path(path).name
    if target.exists() and target.read_bytes()!=data:raise RuntimeError('Baseline changed '+str(target))
    target.write_bytes(data);manifest[path]=hashlib.sha256(data).hexdigest()
(area/'baseline-manifest.json').write_text(json.dumps({'head':head,'sources':manifest},indent=2))
old=root/'.local/cgse-feedback-fixes-20261003'
for name in ['OrderProbe.java','OrderRegression.java','FallbackOracleProbe.java','ProofOracleProbe.java']:
    shutil.copy2(old/'order'/name,area/name)
shutil.copy2(root/'.local/quantity-regression-20261002/QuantitySweep.java',area/'QuantitySweep.java')
shutil.copy2(old/'fallback/FallbackSweep.java',area/'FallbackSweep.java')
groups=[]
for suite in json.loads((old/'fallback/comparison-v3.json').read_text()):
    wanted={}
    for row in suite['remaining']:wanted.setdefault(row['group'],set()).add(row['amount'])
    if not wanted:continue
    for group in json.loads((root/'.local/linear-search-20261002'/(suite['suite']+'.json')).read_text()):
        if group['id'] in wanted:
            group['requests']=[r for r in group['requests'] if int(r['amount']) in wanted[group['id']]]
            group['suite']=suite['suite'];groups.append(group)
(area/'remaining-fallback.json').write_text(json.dumps(groups,indent=2))
print('Frozen',head,'core files',len(manifest),'remaining groups',len(groups),'requests',sum(len(g['requests']) for g in groups))
