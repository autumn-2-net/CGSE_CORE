from pathlib import Path
import json,copy
a=Path(__file__).resolve().parent;r=a.parents[2];base=r/'.local/solver-expansion-20261003'
groups=[];old=[];verified=[]
for name in ['archive-cuts-3','archive-cuts-4']:
 rows=[json.loads(x) for x in (base/'corpus-release'/(name+'.jsonl')).read_text().splitlines()]
 failures=[x for x in rows if x['result']=='ERROR' or 'known_feasible_max' in x and int(x['request']['amount'])<=int(x['known_feasible_max']) and not x['feasible']]
 want={(x['group'],json.dumps(x['request'],sort_keys=True)) for x in failures}
 previous=[json.loads(x) for x in (base/'corpus-verified'/(name+'.jsonl')).read_text().splitlines()]
 verified.extend(x for x in previous if (x['group'],json.dumps(x['request'],sort_keys=True)) in want)
 old.extend(failures)
 for g in json.loads((r/'.local/pruned-search-20261002'/(name+'.json')).read_text()):
  requests=[req for req in g['requests'] if (g['id'],json.dumps(req,sort_keys=True)) in want]
  if requests:
   g=copy.deepcopy(g);g['requests']=requests;g['dump']=True;groups.append(g)
 print(name,'failures',len(failures),flush=True)
(a/'archive-failures-fixtures.json').write_text(json.dumps(groups,indent=2))
(a/'archive-failures-release.json').write_text(json.dumps(old,indent=2))
(a/'archive-failures-verified.json').write_text(json.dumps(verified,indent=2))
for x in old:print(x['group'],x['request'],x['result'],'work',x['work'],flush=True)
