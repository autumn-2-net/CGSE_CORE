from pathlib import Path
import json,hashlib,sys
a=Path(__file__).resolve().parent;r=a.parents[2]
variant=sys.argv[1] if len(sys.argv)>1 else 'archive-final-recheck'
key=lambda x:(x['group'],json.dumps(x['request'],sort_keys=True))
old={key(x):x for x in json.loads((a/'archive-failures-release.json').read_text())}
verified={key(x):x for x in json.loads((a/'archive-failures-verified.json').read_text())}
current=[json.loads(x) for x in (a/variant/'results.jsonl').read_text().splitlines()]
rows=[]
for now in current:
 before=verified[key(now)];release=old[key(now)]
 rows.append({'group':now['group'],'request':now['request'],'target':now['target'],
  'release_result':release['result'],'verified_result':before['result'],'current_result':now['result'],
  'release_work':release['work'],'verified_work':before['work'],'current_work':now['work'],
  'same_diagnostics':now['diagnostics']==before['diagnostics'],'same_recipe_count':now['recipes']==before['recipes'],'same_seed_type_count':now['seed_types']==before['seed_types'],
  'verified_path':before['diagnostics'],'current_path':now['diagnostics'],'current_counts':now['counts'],'current_initial':now['initial'],'current_seeds':now['seeds'],'resource_verified':now.get('verified',False)})
snapshot=json.loads((a/variant/'source-hashes.json').read_text())
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core').glob('*.java')}
report={'source_directory':variant,'requests':len(rows),'recovered':sum(x['current_result'].startswith('FEASIBLE') for x in rows),'remaining_failures':sum(not x['current_result'].startswith('FEASIBLE') for x in rows),'same_diagnostics':sum(x['same_diagnostics'] for x in rows),'source_differences':[n for n in sorted(set(actual)|set(snapshot)) if actual.get(n)!=snapshot.get(n)],'cases':rows,'limitation':'corpus-verified did not dump full plan/counts; comparison uses exact recorded diagnostic path, recipe and seed counts. Current plans additionally dump exact counts, initial inventory and seeds.'}
(a/'archive-recheck-report.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='cases'}))
