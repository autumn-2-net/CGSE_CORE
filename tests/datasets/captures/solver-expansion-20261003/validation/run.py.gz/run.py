from pathlib import Path
import subprocess,sys,os,shutil,json,hashlib
area=Path(__file__).resolve().parent;root=area.parents[2]
jdk=Path('C:/Users/autumn/.jdks/corretto-20.0.2.1/bin')
variant=sys.argv[1];main=sys.argv[2]
out=area/variant;out.mkdir(exist_ok=True)
classes=out/'classes';classes.mkdir(exist_ok=True)
gson=root/'.local/miracle-cycle-20261002/server/libraries/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar'
source=area/'head-core'
if variant!='head':
    source=out/'core';source.mkdir(exist_ok=True)
    for p in (root/'src/main/java/org/gtlcore/gtlcore/integration/ae2/graph/core').glob('*.java'):shutil.copy2(p,source/p.name)
    (out/'source-hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.java')},indent=2))
cp=os.pathsep.join(map(str,[classes,gson]))
sources=list(source.glob('*.java'))+[p for p in area.glob('*.java') if (p.name!='DivingOracle.java' or (source/'CountDiving.java').exists()) and (p.name!='RestartSafety.java' or (source/'GraphFallbackSources.java').exists()) and (p.name!='ForceProofQuota.java' or (source/'ForceCraftProof.java').exists()) and (p.name!='MacroOracle.java' or variant!='head')]
args=['--release','17','-proc:none','-encoding','UTF-8','-cp',cp,'-d',str(classes)]+list(map(str,sources))
argfile=out/'javac.args';argfile.write_text('\n'.join('"'+s.replace('\\','/')+'"' for s in args))
subprocess.run([str(jdk/'javac.exe'),'@'+str(argfile)],check=True)
extra=sys.argv[3:]
if main=='FallbackSweep' and not extra:extra=[str(area/'remaining-fallback.json'),str(out/'fallback-remaining.jsonl')]
with (out/(main+'.log')).open('wb') as log:
    result=subprocess.run([str(jdk/'java.exe'),'-ea','-Xmx1g','-cp',cp,'org.gtlcore.gtlcore.integration.ae2.graph.core.'+main]+extra,stdout=log,stderr=subprocess.STDOUT)
print((out/(main+'.log')).read_text(errors='replace')[-6000:],flush=True)
raise SystemExit(result.returncode)
